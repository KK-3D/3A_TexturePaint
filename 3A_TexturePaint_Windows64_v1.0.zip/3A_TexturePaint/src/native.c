#define UNICODE
#define _UNICODE
#define COBJMACROS
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <shlobj.h>
#include <objbase.h>
#include <wincodec.h>
#include <GL/gl.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <lwserver.h>
#include <lwmodule.h>
#include <lwmodtool.h>
#include <lwviewportinfo.h>
#include <lwhost.h>
#include <lwimage.h>
#include <lwpanel.h>
#include "tp_core.h"
#include "tp_history.h"
#include "capture.inc"
#include "wic.inc"
/* Native Numeric UI and viewports; private message-only dispatcher has no visible UI. */
enum {ID_PREP=0x8200,ID_LAYER,ID_NAME,ID_VISIBLE,ID_OPACITY,ID_UP,ID_DOWN,ID_CLEAR,ID_PALETTE,ID_COLOR,ID_MODE,ID_HARD,ID_RADIUS,ID_STRENGTH,ID_PREVIEW,ID_PROJECT,ID_OPEN,ID_SAVE,ID_PNG,ID_EXPORT,ID_IMPORT_FILE,ID_IMPORT,ID_UNDO,ID_REDO,ID_STATUS,ID_OPEN_FILE,ID_RESOLUTION,ID_ALPHA,ID_CREATE,ID_LINKED,ID_WRITE_IMAGE,ID_CURRENT,ID_READY,ID_TEXTURE_STATUS,ID_FAST_PREVIEW,ID_SAVE_TIMING,ID_AUTO_IMAGE,ID_IMPORT_TEXTURE,ID_LOAD_STAMP,ID_STAMP_IMAGE,ID_STAMP_SHOW,ID_STAMP_OPACITY,ID_STAMP_X,ID_STAMP_Y,ID_STAMP_SCALE,ID_CENTER_STAMP,ID_STAMP_ROTATION,ID_UNDO_LEVELS,ID_PROJECT_IMAGES,ID_REFRESH_IMAGES,ID_ALPHA_PRESETS,ID_ALPHA_IMPORT,ID_ALPHA_REMOVE,ID_ALPHA_NAME,ID_ALPHA_INVERT,ID_ALPHA_DIRECTORY,ID_ALPHA_REFRESH,ID_ALPHA_SELECT,ID_ALPHA_PREV,ID_ALPHA_NEXT,ID_ALPHA_PAGE,ID_ALPHA_SIZE,ID_ALPHA_SCROLL,ID_MIRROR_X,ID_MIRROR_Y,ID_MIRROR_Z,ID_AXIS_ROW,ID_COPY_NEG,ID_COPY_POS,ID_WIREFRAME,ID_NO_DEPTH,ID_WIRE_CUSTOM,ID_WIRE_COLOR};
typedef struct {
 TPDoc doc,undo;TPMirror mirror;TPHistory history;int history_pending;TPMesh mesh;TPView cache;unsigned char*composite,*preview_rgb;float*coverage;
 char object[1024],layer_key[256],project[1024],png[1024],import_path[1024],open_path[1024];
 int valid,canundo,canredo,modified,image_modified,preview_size;unsigned undo_dirty;TPRect coverage_rect;ULONGLONG last_save;
} Session;
typedef struct Tool {
 struct Tool*next;
 GlobalFunc*global;LWXPanelFuncs*xp;LWViewportInfo*vp;LWStateQueryFuncs*state;LWMessageFuncs*messages;LWImageList*images;LWXPanelID panel;
 Session*s;TPBrush brush;double rgb[3],radius,strength,opacity;int layer,visible,hard,mode,palette,preview;
 LWImageID*image_ids;ULONGLONG image_list_poll;int project_image,image_count;char **image_names,**image_paths;
 int stamp_show;double stamp_opacity,stamp_x,stamp_y,stamp_scale,stamp_rotation;
 double ink_start_scale,ink_start_rotation,ink_center[2],ink_start_distance,ink_start_angle,ink_start_x,ink_start_y,ink_pointer[2];
 double wire_color[3]; int wire_custom,no_depth,wireframe,fast_preview,save_timing,adjusting,adjust_dx;double adjust_radius,adjust_strength;
 int resolution,alpha,ready,ui_pending,ui_refreshing,ui_depth,queued_action,busy;
 int line_mode;int axis_width,axis_height,axis_value,mirror_axis[3],alpha_gallery_value;
 int alpha_gallery_w,alpha_gallery_h,alpha_scroll_target;char alpha_directory[1024];
 int update,dirty,painting,pending,released,frameview,cache_valid,cache_type,nav_suspended;
 double mouse[2],last[2],start_mouse[2];LWDMatrix4 last_mv,last_proj;double cursor_xy[2];int cursor_view;
 char name[64],status[512],texture_info[128];
} Tool;
typedef struct {unsigned char*rgba,*display_rgba;int width,height;char path[1024],info[128];} StampAsset;
static StampAsset stamp_asset;
typedef struct {TPAlpha mask;unsigned char*data;unsigned char cursor[128*128*4];int cursor_valid,cursor_invert;char name[128];} BrushAlpha;
static BrushAlpha brush_alpha;
static Session session;
/* This preference survives tool reactivation, but not a Modeler restart. */
static int auto_save_image=1;
static int undo_levels=32;
static Tool*live_tools;
/* Host Numeric userdata may be replaced. Only accept panels owned by a live tool. */
static Tool*find_panel(LWXPanelID panel){Tool*t;for(t=live_tools;t;t=t->next)if(t->panel==panel)return t;return NULL;}
static int is_live(Tool*t){Tool*p;for(p=live_tools;p;p=p->next)if(p==t)return 1;return 0;}
static void run_action(Tool*t,int id);
static int commit_history(Tool*t);
static void composite(Tool*t);
static void trace(const char*event,Tool*t){wchar_t enabled[2];wchar_t path[MAX_PATH];if(!GetEnvironmentVariableW(L"TPN_DIAGNOSTICS",enabled,2))return;FILE*f;DWORD n=GetTempPathW(MAX_PATH,path);if(!n||n>MAX_PATH-50)return;wcscat(path,L"TexturePaintNative2026_diagnostic.log");f=_wfopen(path,L"a");if(!f)return;fprintf(f,"v0.39 %lu %s valid=%d size=%d busy=%d\n",(unsigned long)GetTickCount(),event,t&&t->s?t->s->valid:0,t&&t->s?t->s->doc.size:0,t?t->busy:0);fclose(f);}
static void alpha_dispatch_wake(Tool*t);
static void request_ui(Tool*t){t->dirty=1;t->ui_pending=1;alpha_dispatch_wake(t);}
/* Never refresh XPanels synchronously from a button or value-change callback. */
static void flush_ui(Tool*t){if(!t->panel||!t->ui_pending||t->ui_depth||t->ui_refreshing||t->busy)return;t->ui_pending=0;t->ui_refreshing=1;trace("refresh.begin",t);t->xp->viewRefresh(t->panel);if(is_live(t)){t->ui_refreshing=0;trace("refresh.end",t);}}

static const char*layer_names[]={"01 - Base","02","03","04","05","06","07","08 - Top",NULL};
static const double colors[][3]={{0,0,0},{1,1,1},{0,0,0},{.86,.12,.12},{1,.5,.08},{.98,.86,.08},{.12,.67,.27},{.08,.75,.82},{.14,.33,.86},{.49,.2,.75},{.92,.31,.59},{.43,.25,.14},{.84,.63,.47}};
static const char*resolutions[]={"1024x1024","2048x2048","4096x4096","8192x8192",NULL};
static const char*save_timings[]={"Every stroke","At stroke end - 30s minimum",NULL};
static const char*modes[]={"Paint","Eraser","Fill","Ink / Stamp",NULL};
static double bound(double x){return !isfinite(x)?0:x<0?0:x>1?1:x;}
static void status(Tool*t,const char*s){snprintf(t->status,sizeof(t->status),"%s",s);request_ui(t);}
static void sync_ui(Tool*t){Session*s=t->s;t->ready=s->valid;snprintf(t->texture_info,sizeof(t->texture_info),"%d x %d | %s",s->doc.size,s->doc.size,s->doc.alpha?"PNG RGBA (alpha)":"PNG RGB (white background)");if(!s->valid)snprintf(t->texture_info,sizeof(t->texture_info),"Not prepared - click Prepare on the Brush tab");if(s->valid){t->layer=s->doc.active;t->visible=s->doc.layer[t->layer].visible;t->opacity=s->doc.layer[t->layer].opacity;snprintf(t->name,64,"%s",s->doc.layer[t->layer].name);}request_ui(t);}
/* Validate one query at a time. Host-owned strings are copied before another call. */
static int query_target(Tool*t,char object[1024],char key[256],char uv[256]){const char*p;LWID type=0;
 trace("query.object.begin",t);p=t->state->object();trace("query.object.end",t);
 if(!p||!*p||strlen(p)>=1024){status(t,"No active object. Open a mesh before preparing the texture.");trace("prepare.no_object",t);return 0;}strcpy(object,p);
 trace("query.layers.begin",t);p=t->state->layerList(OPLYR_PRIMARY,NULL);trace("query.layers.end",t);
 if(!p||!*p||strlen(p)>=256){status(t,"No primary layer. Select a foreground mesh layer.");trace("prepare.no_layer",t);return 0;}strcpy(key,p);
 trace("query.uv.begin",t);p=t->state->vmap(LWM_VMAP_TEXTURE,&type);trace("query.uv.end",t);
 if(!p||!*p||strlen(p)>=256||type!=LWVMAP_TXUV){status(t,"Select a texture UV map (T) before clicking Prepare.");trace("prepare.no_uv",t);return 0;}strcpy(uv,p);return 1;
}
static int matches(Tool*t){const char*p;char object[1024];
 if(!t||!t->s||!t->s->valid)return 0;
 p=t->state->object();if(!p||strlen(p)>=sizeof(object))return 0;strcpy(object,p);
 if(strcmp(object,t->s->object))return 0;
 p=t->state->layerList(OPLYR_PRIMARY,NULL);return p&&!strcmp(p,t->s->layer_key);
}
static void free_session(Session*s){tp_mirror_free(&s->mirror);tp_history_free(&s->history);tp_doc_free(&s->doc);tp_doc_free(&s->undo);tp_view_free(&s->cache);free(s->mesh.tri);free(s->composite);free(s->preview_rgb);free(s->coverage);memset(s,0,sizeof(*s));}
static int to_wide(const char*s,wchar_t*out){return MultiByteToWideChar(CP_UTF8,0,s,-1,out,MAX_PATH)>0;}
static int atomic_file(Session*s,const char*name,int project){wchar_t path[MAX_PATH],dir[MAX_PATH],temp[MAX_PATH],*p;FILE*f;int ok;if(!to_wide(name,path))return 0;wcscpy(dir,path);p=wcsrchr(dir,L'\\');if(!p)return 0;*p=0;if(!GetTempFileNameW(dir,L"tpu",0,temp))return 0;f=_wfopen(temp,L"wb");if(!f){DeleteFileW(temp);return 0;}ok=project?tp_project_write(f,&s->doc):tp_png_mode(f,s->composite,s->doc.size,s->doc.size,s->doc.alpha);if(fflush(f)||ferror(f))ok=0;if(fclose(f))ok=0;if(ok)ok=MoveFileExW(temp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;if(!ok)DeleteFileW(temp);return ok;}
/* Resolve by filename each time: an Image Editor deletion must not leave a stale ID. */
static int refresh_image(Tool*t){LWImageID id;const char*path=t->s->doc.texture_path;if(!*path)return 1;if(!t->images)return 0;
 for(id=t->images->first();id;id=t->images->next(id)){const char*name=t->images->filename(id,0);if(name&&!_stricmp(name,path))return t->images->replace(id,path)!=0;}
 return t->images->load(path)!=NULL;
}
static int save_texture(Tool*t){Session*s=t->s;if(!s->doc.texture_path[0])return 1;
 if(!atomic_file(s,s->doc.texture_path,0)){status(t,"ERROR saving the PNG texture. Painting is still in memory; fix the destination before closing.");return 0;}
 if(!refresh_image(t)){status(t,"PNG saved, but the Image Editor update failed. Reload the image in LightWave.");return 0;}s->image_modified=0;return 1;
}
/* Project safety saves and linked PNG writes have independent dirty flags. */
static int autosave(Tool*t){Session*s=t->s;if(!commit_history(t))return 0;int wrote=0;if(!s->valid)return 1;
 if(s->modified){if(!atomic_file(s,s->project,1)){status(t,"ERROR saving the project. Choose a valid path in Numeric and click Save Project.");return 0;}s->modified=0;wrote=1;}
 if(auto_save_image&&s->image_modified){if(!save_texture(t))return 0;wrote=1;}
 if(wrote)s->last_save=GetTickCount64();
 return 1;
}
static void finish_stroke(Tool*t){if(!commit_history(t))return;if(t->save_timing==1&&(t->s->modified||(auto_save_image&&t->s->image_modified))&&GetTickCount64()-t->s->last_save<30000){status(t,"Painting updated in memory. Save Project to save now; timed saving runs at a later stroke end.");return;}if(autosave(t)&&!auto_save_image&&t->s->image_modified)status(t,"Project saved. PNG auto-save is OFF; use Save Texture Now to update the image.");}
static int default_paths(Session*s){wchar_t folder[MAX_PATH],path[MAX_PATH];SYSTEMTIME now;if(FAILED(SHGetFolderPathW(NULL,CSIDL_PERSONAL,NULL,SHGFP_TYPE_CURRENT,folder)))return 0;if(wcslen(folder)>150)return 0;wcscat(folder,L"\\LightWaveTexturePaint");if(!CreateDirectoryW(folder,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return 0;GetLocalTime(&now);swprintf(path,MAX_PATH,L"%ls\\Paint_%04d%02d%02d_%02d%02d%02d_%lu.tpaint",folder,now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,(unsigned long)GetTickCount());if(!WideCharToMultiByte(CP_UTF8,0,path,-1,s->project,1024,NULL,NULL))return 0;snprintf(s->png,1024,"%s",s->project);s->png[strlen(s->png)-7]=0;strcat(s->png,".png");return 1;}
static int checkpoint(Tool*t){TPDoc d={0};Session*s=t->s;int l;if(!commit_history(t))return 0;
 /* Reuse the existing snapshot to avoid a third complete 8K document. */
 if(s->undo.size==s->doc.size){for(l=0;l<TP_LAYERS;l++){unsigned char*p=s->undo.layer[l].rgba;s->undo.layer[l]=s->doc.layer[l];s->undo.layer[l].rgba=p;if(s->undo_dirty&(1u<<l))memcpy(p,s->doc.layer[l].rgba,(size_t)s->doc.size*s->doc.size*4);}s->undo.active=s->doc.active;s->undo.alpha=s->doc.alpha;memcpy(s->undo.texture_path,s->doc.texture_path,1024);}
 else{if(!tp_doc_clone(&d,&s->doc)){status(t,"Not enough memory for Undo. Operation cancelled.");return 0;}tp_doc_free(&s->undo);s->undo=d;}
 s->undo_dirty=0;s->history_pending=1;s->canundo=1;return 1;
}
static int commit_history(Tool*t){Session*s=t->s;int result;if(!s->history_pending)return 1;
 result=tp_history_commit(&s->history,&s->undo,&s->doc,s->undo_dirty,undo_levels);
 if(result<0){TPDoc tmp=s->doc;s->doc=s->undo;s->undo=tmp;s->history_pending=0;s->undo_dirty=255;
 s->modified=1;s->image_modified=s->doc.texture_path[0]!=0;t->dirty=1;
 composite(t);status(t,"Undo storage failed. Latest operation was cancelled; free temporary disk space and retry.");return 0;}
 s->history_pending=0;s->canundo=s->history.cursor>0;s->canredo=s->history.cursor<s->history.count;return 1;
}
static void composite_region(Tool*t,const TPRect*r){Session*s=t->s;int size=s->doc.size,p=size,x,y,k,x0=0,y0=0,x1,y1;
 if(t->fast_preview&&p>1024)p=1024;
 if(p!=s->preview_size)r=NULL;
 s->preview_size=p;x1=y1=p-1;tp_composite_region(&s->doc,s->composite,r);
 if(r){if(!r->valid)return;x0=r->x0*p/size;y0=r->y0*p/size;x1=r->x1*p/size;y1=r->y1*p/size;}
 for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){int sx=(int)(((double)x+.5)*size/p),sy=(int)(((double)y+.5)*size/p);size_t src=((size_t)sy*size+sx)*4,dst=((size_t)y*p+x)*3;double a=s->composite[src+3]/255.0;for(k=0;k<3;k++)s->preview_rgb[dst+k]=(unsigned char)(s->composite[src+k]*a+255*(1-a)+.5);}
 t->dirty=1;
}
static void composite(Tool*t){composite_region(t,NULL);}
static void changed(Tool*t){t->s->undo_dirty=255;t->s->modified=1;t->s->image_modified=t->s->doc.texture_path[0]!=0;composite(t);sync_ui(t);if(autosave(t))status(t,"Project saved. Paint in the viewports; use Modeler controls to navigate.");}
static int texture_buffers(Session*s,int size){size_t n=(size_t)size*size;
 s->composite=malloc(n*4);s->preview_rgb=malloc(n*3);s->coverage=calloc(n,sizeof(float));
 return s->composite&&s->preview_rgb&&s->coverage;
}
#include "brush_alpha.inc"
#include "alpha_dispatch.inc"
#include "alpha_wheel.inc"
#include "stamp.inc"
#include "project_images.inc"
#include "import.inc"
static void create_texture(Tool*t){Session*s=t->s,fresh={0};wchar_t path[MAX_PATH];int size;size_t len=strlen(s->png);trace("create.begin",t);if(t->resolution<0||t->resolution>3){status(t,"Invalid resolution. Select 1K, 2K, 4K or 8K.");return;}size=1024<<t->resolution;
 if(!s->valid||!matches(t)){status(t,"Click Prepare for the current object and UV map before creating a texture.");return;}
 if(len<5||_stricmp(s->png+len-4,".png")||!to_wide(s->png,path)){status(t,"Choose a full path ending in .png in an existing folder.");return;}
 if(GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES&&!t->messages->yesNo("Replace Texture?",s->png,"This file already exists. Replace it with the new blank image?"))return;
 if(!t->messages->yesNo("Create Texture", "Start a blank texture for the prepared mesh and UV map?", "The current project will be saved. Creating a texture starts new layers and clears Undo."))return;
 if(!autosave(t))return;
 trace("create.allocate",t);
 if(!tp_doc_init(&fresh.doc,size,s->mesh.hash,s->mesh.uvname)||!texture_buffers(&fresh,size)||!default_paths(&fresh)){
  free_session(&fresh);status(t,"Memory or destination unavailable. The current project has been preserved.");return;
 }
 fresh.doc.alpha=t->alpha;snprintf(fresh.doc.texture_path,1024,"%s",s->png);snprintf(fresh.png,1024,"%s",s->png);
 tp_composite(&fresh.doc,fresh.composite);
 trace("create.write",t);
 if(!atomic_file(&fresh,fresh.project,1)||!atomic_file(&fresh,fresh.doc.texture_path,0)){
  free_session(&fresh);status(t,"Could not create files. Previous session preserved; check the folder, free space and permissions.");return;
 }
 fresh.mesh=s->mesh;memset(&s->mesh,0,sizeof(s->mesh));snprintf(fresh.object,1024,"%s",s->object);snprintf(fresh.layer_key,256,"%s",s->layer_key);
 fresh.valid=1;fresh.last_save=GetTickCount64();free_session(s);*s=fresh;t->cache_valid=0;composite(t);sync_ui(t);
 trace("create.reload",t);
 if(refresh_image(t))status(t,"Texture created. Assign this image to the material using the prepared UV map. Use Auto-save Texture Image or Save Texture Now to update the PNG.");
 else status(t,"Texture created on disk. Load the PNG in the Image Editor; automatic host update failed.");
 trace("create.end",t);
}
static void undo_action(Tool*t,int redo){Session*s=t->s;if(t->adjusting||t->painting||t->pending||!s->valid)return;
 if(!commit_history(t))return;
 if(!tp_history_step(&s->history,&s->doc,redo)){status(t,redo?"No further painting Redo available.":"No further painting Undo available.");return;}
 s->canundo=s->history.cursor>0;s->canredo=s->history.cursor<s->history.count;s->undo_dirty=255;
 changed(t);
}

/* Event, brush and cursor all use viewport-local pixels from the same sample. */
static int paint_view(Tool*t,int n){int type;if(n<0||n>=t->vp->numViewports)return 0;type=t->vp->type(n);return (type>=LVVIEWT_TOP&&type<=LVVIEWT_PERSPECTIVE)||type==LVVIEWT_UV;}
/* Matrices are read from the active Modeler viewport on every new stroke. */
static int native_frame(Tool*t,int n){Session*s=t->s;TPView*v=&s->cache;v->no_depth=t->no_depth;LWDMatrix4 mv,p;int left,top,w,h,j,k,r;size_t i;if(!paint_view(t,n))return 0;if(!t->vp->modelview(n,mv,NULL)||!t->vp->projection(n,p,NULL))return 0;t->vp->rect(n,&left,&top,&w,&h);(void)left;(void)top;if(w<1||h<1||w>4096||h>4096)return 0;if(t->cache_valid&&t->cache_type==t->vp->type(n)&&t->frameview==n&&v->w==w&&v->h==h&&!memcmp(mv,t->last_mv,sizeof(mv))&&!memcmp(p,t->last_proj,sizeof(p)))return 1;memcpy(t->last_mv,mv,sizeof(mv));memcpy(t->last_proj,p,sizeof(p));if((v->w!=w||v->h!=h)&&!tp_view_resize(v,w,h))return 0;if(v->project_count!=s->mesh.count){TPProjected*q=realloc(v->projected,s->mesh.count*3*sizeof(*q));if(!q)return 0;v->projected=q;v->project_count=s->mesh.count;}
 for(i=0;i<s->mesh.count;i++)for(j=0;j<3;j++){double uvpoint[3]={s->mesh.tri[i].v[j].uv[0],s->mesh.tri[i].v[j].uv[1],0};const double*point=t->vp->type(n)==LVVIEWT_UV?uvpoint:s->mesh.tri[i].v[j].p;double in[4]={point[0],point[1],point[2],1},eye[4]={0},clip[4]={0},winz;TPProjected*q=&v->projected[i*3+j];for(r=0;r<4;r++)for(k=0;k<4;k++)eye[r]+=mv[k][r]*in[k];for(r=0;r<4;r++)for(k=0;k<4;k++)clip[r]+=p[k][r]*eye[k];q->w=clip[3];q->z=-eye[2];q->x=q->y=0;if(q->w<=1e-10||clip[2]<-q->w||clip[2]>q->w||!t->vp->project(n,(double*)point,&q->x,&q->y,&winz))q->w=-1;}
 v->uv_mode=0;t->frameview=n;t->cache_type=t->vp->type(n);t->cache_valid=tp_render_projected(v,&s->mesh,&s->doc,NULL);return t->cache_valid;}
static int capture_mesh(Tool*t,MeshEditOp*op){Capture c={0};char uv[256],object[1024],key[256];Session fresh={0};int err;c.op=op;
 trace("capture.begin",t);
 if(!query_target(t,object,key,uv))return EDERR_BADARGS;
 if(!op||!op->pointVSet||!op->vMapGetDimension||!op->polyScan||!op->pointInfo||!op->pointVEval){status(t,"Required mesh callbacks are unavailable.");return EDERR_BADARGS;}
 trace("capture.select_uv.begin",t);
strcpy(c.mesh.uvname,uv);if(!op->pointVSet(op->state,NULL,LWVMAP_TXUV,uv)){status(t,"The selected UV map does not exist in the primary layer.");return EDERR_BADVMAP;}trace("capture.select_uv.end",t);trace("capture.dimension.begin",t);
 if(op->vMapGetDimension(op->state)!=2){status(t,"The selected UV map must have two dimensions.");return EDERR_BADVMAP;}
 trace("capture.dimension.end",t);trace("capture.scan.begin",t);
 err=op->polyScan(op->state,scan_polygon,&c,OPLYR_PRIMARY);trace("capture.scan.end",t);if(err||!tp_mesh_finish(&c.mesh)){free(c.mesh.tri);status(t,c.reason==2?"Triangulate concave polygons before painting.":"Incomplete UVs, UVs outside 0-1, invalid mesh, or the 2,000,000-triangle limit was exceeded.");return err?err:EDERR_BADARGS;}
 if(t->s->valid&&t->s->mesh.hash==c.mesh.hash&&!strcmp(t->s->mesh.uvname,uv)&&!strcmp(t->s->object,object)&&!strcmp(t->s->layer_key,key)){free(t->s->mesh.tri);t->s->mesh=c.mesh;return EDERR_NONE;}
 if(t->s->valid&&!autosave(t)){free(c.mesh.tri);return EDERR_USERABORT;}
 trace("capture.allocate.begin",t);fresh.mesh=c.mesh;strcpy(fresh.object,object);strcpy(fresh.layer_key,key);if(!tp_doc_init(&fresh.doc,1024,c.mesh.hash,uv)){free_session(&fresh);return EDERR_NOMEMORY;}fresh.composite=malloc(1024*1024*4);fresh.preview_rgb=malloc(1024*1024*3);fresh.coverage=calloc(1024*1024,sizeof(float));if(!fresh.composite||!fresh.preview_rgb||!fresh.coverage||!default_paths(&fresh)){free_session(&fresh);status(t,"Could not allocate memory or prepare the Documents/LightWaveTexturePaint folder.");return EDERR_NOMEMORY;}fresh.valid=1;fresh.modified=1;tp_composite(&fresh.doc,fresh.composite);free_session(t->s);*t->s=fresh;composite(t);sync_ui(t);trace("capture.complete",t);return EDERR_NONE;}
static int sample_position(Tool*t,LWToolEvent*e,double out[2]){int n,left,top,w,h;double z;
 if(t->vp->hoverIndex)n=t->vp->hoverIndex(out);
 else{n=e->viewNumber;if(!paint_view(t,n)||!t->vp->project(n,e->posRaw,&out[0],&out[1],&z))return -1;}
 if(!paint_view(t,n)||!isfinite(out[0])||!isfinite(out[1]))return -1;
 t->vp->rect(n,&left,&top,&w,&h);
 return out[0]>=0&&out[1]>=0&&out[0]<w&&out[1]<h?n:-1;
}
static int update_cursor(Tool*t,LWToolEvent*e,double xy[2]){int n;if(t->adjusting||t->line_mode){memcpy(xy,t->cursor_xy,sizeof(t->cursor_xy));t->dirty=1;return t->cursor_view;}n=sample_position(t,e,xy);t->cursor_view=n;if(n>=0)memcpy(t->cursor_xy,xy,sizeof(t->cursor_xy));t->dirty=1;return n;}
#include "stamp_controls.inc"
static void stamp_to(Tool*t,double x,double y){if(t->mode==TP_MODE_FILL)return;TPRect region={0};TPStencil stencil;const TPStencil*ink=NULL;if(t->mode==TP_MODE_INK){if(!stencil_layout(t,t->s->cache.w,t->s->cache.h,&stencil))return;ink=&stencil;}double dx=x-t->last[0],dy=y-t->last[1];int i,n=(int)ceil(hypot(dx,dy)/fmax(1,t->radius*.2)),modified=0;if(n<1)n=1;if(n>8192)n=8192;for(i=1;i<=n;i++)modified|=tp_stamp_mirror(&t->s->mesh,&t->s->cache,&t->s->doc,&t->s->undo,t->s->coverage,&t->brush,t->last[0]+dx*i/n,t->last[1]+dy*i/n,&region,ink,brush_alpha.data?&brush_alpha.mask:NULL,&t->s->mirror);t->last[0]=x;t->last[1]=y;if(modified){t->s->modified=1;t->s->image_modified=t->s->doc.texture_path[0]!=0;t->s->undo_dirty|=1u<<t->s->doc.active;tp_rect_add(&t->s->coverage_rect,region.x0,region.y0);tp_rect_add(&t->s->coverage_rect,region.x1,region.y1);composite_region(t,&region);}}
static void begin_stroke(Tool*t){int k;
 if(t->mode!=TP_MODE_FILL){unsigned axes=(t->mirror_axis[0]?1u:0)|(t->mirror_axis[1]?2u:0)|(t->mirror_axis[2]?4u:0);
 if(!tp_mirror_prepare(&t->s->mirror,&t->s->mesh,axes)){t->painting=t->pending=t->line_mode=0;status(t,"Could not prepare Symmetry. Stroke cancelled; texture preserved.");return;}
 if(axes){size_t matched=0,total=0;unsigned a;for(a=1;a<8;a++)if(t->s->mirror.faces[a]){matched+=t->s->mirror.matched[a];total+=t->s->mesh.count;}
 if(matched<total)status(t,"Symmetry: some faces have no symmetric triangle at the object origin. Unmatched faces are not mirrored.");}
 }
if(t->mode==TP_MODE_FILL&&t->strength<=0){t->painting=t->pending=t->line_mode=0;status(t,"Fill strength is zero. No pixels changed.");return;}if(t->mode!=TP_MODE_FILL&&!native_frame(t,t->frameview)){status(t,"Could not read the viewport. Use a native 3D or UV view, up to 4096 pixels per side.");t->painting=t->pending=t->line_mode=0;return;}if(!checkpoint(t)){t->painting=t->pending=t->line_mode=0;return;}t->brush.radius=(int)t->radius;t->brush.strength=t->strength;t->brush.hard=t->hard;t->brush.erase=t->mode==1;for(k=0;k<3;k++)t->brush.color[k]=(unsigned char)(bound(t->rgb[k])*255+.5);{TPRect*r=&t->s->coverage_rect;int y;if(r->valid)for(y=r->y0;y<=r->y1;y++)memset(t->s->coverage+(size_t)y*t->s->doc.size+r->x0,0,(size_t)(r->x1-r->x0+1)*sizeof(float));memset(r,0,sizeof(*r));}t->pending=0;if(t->mode==TP_MODE_FILL){TPRect region={0};if(tp_fill_mesh(&t->s->mesh,&t->s->doc,&t->s->undo,t->s->coverage,&t->brush,&region)){
 t->s->modified=1;t->s->image_modified=t->s->doc.texture_path[0]!=0;t->s->undo_dirty|=1u<<t->s->doc.active;
 tp_rect_add(&t->s->coverage_rect,region.x0,region.y0);tp_rect_add(&t->s->coverage_rect,region.x1,region.y1);composite_region(t,&region);
 status(t,"Filled all UV-mapped faces on the active layer. Release LMB to finish.");
 }return;}t->last[0]=t->start_mouse[0];t->last[1]=t->start_mouse[1];stamp_to(t,t->last[0],t->last[1]);stamp_to(t,t->mouse[0],t->mouse[1]);}
/* Rebuild only the affected UV rectangle from the stroke snapshot. This
   removes the previous line when the endpoint turns or moves backwards. */
static void restore_line_pixels(Tool*t){Session*s=t->s;TPRect r=s->coverage_rect;int y,n=s->doc.size,l=s->doc.active;
 if(!r.valid||s->undo.size!=n)return;
 for(y=r.y0;y<=r.y1;y++){size_t at=(size_t)y*n+r.x0;size_t count=(size_t)(r.x1-r.x0+1);
 memcpy(s->doc.layer[l].rgba+at*4,s->undo.layer[l].rgba+at*4,count*4);
 memset(s->coverage+at,0,count*sizeof(float));}
 memset(&s->coverage_rect,0,sizeof(s->coverage_rect));composite_region(t,&r);
}
static void redraw_line(Tool*t){if(t->pending||!t->painting)return;
 if(!matches(t)){status(t,"Object or layer changed. Finish the line before changing targets.");return;}
 restore_line_pixels(t);memcpy(t->last,t->start_mouse,sizeof(t->last));
 stamp_to(t,t->last[0],t->last[1]);stamp_to(t,t->mouse[0],t->mouse[1]);
}
static void cancel_line(Tool*t){if(!t->pending){restore_line_pixels(t);t->s->history_pending=0;}
 t->line_mode=t->painting=t->pending=0;t->update=LWT_TEST_NOTHING;request_ui(t);
}
static LWError build(LWInstance inst,MeshEditOp*op){Tool*t=inst;int err;trace("build.begin",t);t->cache_valid=0;
 if(!op||!op->done){t->update=LWT_TEST_NOTHING;t->pending=t->painting=t->line_mode=0;status(t,"Modeler did not provide a valid mesh edit operation.");trace("build.invalid_op",t);return "Invalid mesh edit operation.";}
 err=capture_mesh(t,op);trace("build.capture_returned",t);trace("build.done.begin",t);op->done(op->state,err,0);trace("build.done.end",t);t->update=err?LWT_TEST_NOTHING:LWT_TEST_ACCEPT;if(err){t->pending=t->painting=t->line_mode=0;return "3A_Texture Paint: see the Modeler tool help/status line.";}if(t->pending){begin_stroke(t);if(t->released){t->painting=0;finish_stroke(t);}}else{sync_ui(t);trace("prepare.save.begin",t);if(autosave(t))status(t,"Ready. Paint with the left mouse button; use normal Modeler navigation.");trace("prepare.save.end",t);}trace("build.end",t);return NULL;}
static int test(LWInstance inst){Tool*t=inst;int id;if(t->queued_action&&!t->busy&&!t->ui_depth){id=t->queued_action;t->queued_action=0;t->busy=1;trace("action.begin",t);run_action(t,id);t->busy=0;trace("action.end",t);}if(!t->busy&&!t->painting&&!t->pending&&!t->adjusting&&GetTickCount64()-t->image_list_poll>1000){t->image_list_poll=GetTickCount64();refresh_project_images(t);}if(t->update==LWT_TEST_UPDATE){char object[1024],key[256],uv[256];trace("test.prepare",t);if(!query_target(t,object,key,uv)){t->update=LWT_TEST_NOTHING;t->pending=t->painting=t->line_mode=0;}else trace("test.request_build",t);}return t->update;}
static void end(LWInstance inst,int keep){Tool*t=inst;(void)keep;t->update=LWT_TEST_NOTHING;trace("tool.end",t);}
static void adjust_brush(Tool*t,LWToolEvent*e){double delta=(double)e->dx-t->adjust_dx;char message[160];
 if(t->adjusting>=3){adjust_stamp(t,e);return;}
 if(t->adjusting==1){t->radius=fmax(1,fmin(180,t->adjust_radius+delta*.5));snprintf(message,sizeof(message),"Radius: %.1f px | RMB drag: radius; Shift + RMB drag: strength.",t->radius);}
 else{t->strength=bound(t->adjust_strength+delta*.005);snprintf(message,sizeof(message),"Stroke Strength: %.1f%% | RMB drag: radius; Shift + RMB drag: strength.",t->strength*100);}
 status(t,message);
}
static int down(LWInstance inst,LWToolEvent*e){Tool*t=inst;int n;
 if(t->adjusting||t->painting||t->pending||t->busy||t->queued_action)return 0;
 if(e->flags&(LWTOOLF_ALT|LWTOOLF_CTRL))return 0;
 if(e->flags&LWTOOLF_ALT_BUTTON){n=update_cursor(t,e,t->mouse);if(n<0)return 0;t->adjusting=e->flags&LWTOOLF_SHIFT?2:1;t->adjust_dx=e->dx;t->adjust_radius=t->radius;t->adjust_strength=t->strength;adjust_brush(t,e);return 1;}
 
 if(t->mode==TP_MODE_INK&&!stamp_asset.rgba){status(t,"Select Ink / Stamp mode and import a stamp in the Brush tab before painting.");return 0;}
 n=update_cursor(t,e,t->mouse);if(n<0)return 0;
 if(!(e->flags&LWTOOLF_SHIFT)&&begin_stamp_control(t,n,t->mouse))return 1;
 memcpy(t->start_mouse,t->mouse,sizeof(t->mouse));t->frameview=n;t->cache_valid=0;t->nav_suspended=0;
 t->line_mode=(e->flags&LWTOOLF_SHIFT)&&t->mode!=TP_MODE_FILL;
 t->painting=1;t->pending=1;t->released=0;t->update=LWT_TEST_UPDATE;return 1;
}
static void update_line(Tool*t,LWToolEvent*e){
 double xy[2],end[2],dx,dy,factor=1;int n=sample_position(t,e,xy),left,top,w,h;
 if(n!=t->frameview)return;
 tp_line_endpoint(t->start_mouse,xy,(e->flags&LWTOOLF_SHIFT)!=0,end);
 t->vp->rect(n,&left,&top,&w,&h);dx=end[0]-t->start_mouse[0];dy=end[1]-t->start_mouse[1];
 if(end[0]<0&&dx<0)factor=fmin(factor,-t->start_mouse[0]/dx);
 if(end[0]>w-1&&dx>0)factor=fmin(factor,(w-1-t->start_mouse[0])/dx);
 if(end[1]<0&&dy<0)factor=fmin(factor,-t->start_mouse[1]/dy);
 if(end[1]>h-1&&dy>0)factor=fmin(factor,(h-1-t->start_mouse[1])/dy);
 t->mouse[0]=t->start_mouse[0]+dx*factor;t->mouse[1]=t->start_mouse[1]+dy*factor;
 memcpy(t->cursor_xy,t->mouse,sizeof(t->mouse));t->cursor_view=t->frameview;t->dirty=1;redraw_line(t);
}
static void move(LWInstance inst,LWToolEvent*e){Tool*t=inst;double xy[2];int n=update_cursor(t,e,xy),switched;
 if(t->adjusting){adjust_brush(t,e);return;}
 if(t->line_mode){if(e->flags&(LWTOOLF_ALT|LWTOOLF_CTRL)){cancel_line(t);return;}update_line(t,e);return;}
 if(!t->painting||t->mode==TP_MODE_FILL)return;
 if(e->flags&(LWTOOLF_ALT|LWTOOLF_CTRL|LWTOOLF_SHIFT)){t->painting=t->pending=0;t->released=1;finish_stroke(t);return;}
 if(n<0){t->nav_suspended=1;return;}
 switched=n!=t->frameview||t->nav_suspended;
 if(t->pending){if(switched){t->frameview=n;memcpy(t->start_mouse,xy,sizeof(xy));}memcpy(t->mouse,xy,sizeof(xy));t->nav_suspended=0;return;}
 if(!matches(t)){t->painting=0;status(t,"Object or layer changed. Click Prepare in Numeric.");return;}
 if(!native_frame(t,n)){t->nav_suspended=1;return;}
 if(switched)memcpy(t->last,xy,sizeof(xy));
 t->nav_suspended=0;memcpy(t->mouse,xy,sizeof(xy));stamp_to(t,xy[0],xy[1]);
}
static void up(LWInstance inst,LWToolEvent*e){Tool*t=inst;double xy[2];update_cursor(t,e,xy);if(t->line_mode){if(e->flags&(LWTOOLF_ALT|LWTOOLF_CTRL)){cancel_line(t);return;}update_line(t,e);t->line_mode=0;t->released=1;if(!t->pending){t->painting=0;finish_stroke(t);sync_ui(t);}return;}if(t->adjusting){adjust_brush(t,e);t->adjusting=0;request_ui(t);return;}t->released=1;if(t->pending)return;if(t->painting)move(inst,e);t->painting=0;finish_stroke(t);sync_ui(t);}
static void track(LWInstance inst,LWToolEvent*e){Tool*t=inst;double xy[2];update_cursor(t,e,xy);}
static void event(LWInstance inst,int code){Tool*t=inst;if(t->line_mode&&(code==LWT_EVENT_RESET||code==LWT_EVENT_DROP||code==LWT_EVENT_DEACTIVATE)){cancel_line(t);return;}if(code==LWT_EVENT_RESET&&t->adjusting){if(t->adjusting>=3){t->stamp_scale=t->ink_start_scale;t->stamp_rotation=t->ink_start_rotation;t->stamp_x=t->ink_start_x;t->stamp_y=t->ink_start_y;}else{t->radius=t->adjust_radius;t->strength=t->adjust_strength;}t->adjusting=0;request_ui(t);return;}if(code==LWT_EVENT_DROP||code==LWT_EVENT_DEACTIVATE){t->adjusting=t->painting=t->pending=0;autosave(t);}if(code==LWT_EVENT_RESET){if(t->painting&&t->s->canundo){t->painting=0;undo_action(t,0);}t->pending=0;}if(code==LWT_EVENT_EXTERNAL_ACTION)t->cache_valid=0;}
static int dirty(LWInstance inst){Tool*t=inst;int d;flush_ui(t);if(!is_live(t))return 0;d=t->dirty;t->dirty=0;return d?(LWT_DIRTY_WIREFRAME|LWT_DIRTY_HELPTEXT):0;}
static const char*help(LWInstance inst,LWToolEvent*e){Tool*t=inst;(void)e;return t->status;}
/* Screen-space cursor and isolated preview drawing; no legacy wire-circle handles. */
#include "overlay.inc"
static int tool_undo(LWInstance inst){Tool*t=inst;if(!t->busy&&!t->adjusting&&!t->painting&&!t->pending&&!t->queued_action){t->queued_action=ID_UNDO;request_ui(t);}return 0;}
static int tool_redo(LWInstance inst){Tool*t=inst;if(!t->busy&&!t->adjusting&&!t->painting&&!t->pending&&!t->queued_action){t->queued_action=ID_REDO;request_ui(t);}return 0;}
static void done(LWInstance inst){Tool*t=inst;alpha_wheel_forget(t);Tool**p=&live_tools;t->busy=1;t->queued_action=0;trace("tool.done",t);if(t->line_mode)cancel_line(t);autosave(t);if(t->panel){t->xp->setData(t->panel,0,NULL);t->xp->viewInst(t->panel,NULL);t->panel=NULL;}while(*p&&*p!=t)p=&(*p)->next;if(*p)*p=t->next;free_project_images(t);free(t);if(!live_tools){alpha_wheel_stop();alpha_dispatch_stop();}}
static void panel_destroy(void*data){Tool*t=data;if(is_live(t)){alpha_wheel_forget(t);t->panel=NULL;t->ui_pending=0;}}
static int ink_control(unsigned id){switch(id){case ID_LOAD_STAMP:case ID_PROJECT_IMAGES:case ID_REFRESH_IMAGES:case ID_STAMP_IMAGE:case ID_STAMP_SHOW:case ID_STAMP_OPACITY:case ID_STAMP_X:case ID_STAMP_Y:case ID_STAMP_SCALE:case ID_STAMP_ROTATION:case ID_CENTER_STAMP:return 1;default:return 0;}}
static int ink_control_allowed(Tool*t,unsigned id){return !ink_control(id)||t->mode==TP_MODE_INK;}
static void*get(void*data,unsigned id){Tool*t=data;if(!is_live(t))return NULL;switch(id){case ID_AXIS_ROW:return &t->axis_value;case ID_ALPHA_PRESETS:return &t->alpha_gallery_value;case ID_MIRROR_X:case ID_MIRROR_Y:case ID_MIRROR_Z:return &t->mirror_axis[id-ID_MIRROR_X];case ID_ALPHA_SIZE:return &alpha_size;case ID_ALPHA_DIRECTORY:return t->alpha_directory;case ID_ALPHA_SELECT:return &alpha_catalog.selected;case ID_ALPHA_PAGE:return alpha_catalog.page_info;case ID_ALPHA_NAME:return brush_alpha.data?brush_alpha.name:"None - normal brush";case ID_ALPHA_INVERT:return &brush_alpha.mask.invert;case ID_UNDO_LEVELS:return &undo_levels;case ID_PROJECT_IMAGES:return &t->project_image;case ID_STAMP_ROTATION:return &t->stamp_rotation;case ID_STAMP_IMAGE:return stamp_asset.rgba?stamp_asset.info:"No stamp image loaded";case ID_STAMP_SHOW:return &t->stamp_show;case ID_STAMP_OPACITY:return &t->stamp_opacity;case ID_STAMP_X:return &t->stamp_x;case ID_STAMP_Y:return &t->stamp_y;case ID_STAMP_SCALE:return &t->stamp_scale;case ID_AUTO_IMAGE:return &auto_save_image;case ID_FAST_PREVIEW:return &t->fast_preview;case ID_SAVE_TIMING:return &t->save_timing;case ID_READY:return &t->ready;case ID_TEXTURE_STATUS:return t->status;case ID_CURRENT:return t->texture_info;case ID_RESOLUTION:return &t->resolution;case ID_ALPHA:return &t->alpha;case ID_LINKED:return t->s->doc.texture_path;case ID_LAYER:return &t->layer;case ID_NAME:return t->name;case ID_VISIBLE:return &t->visible;case ID_OPACITY:return &t->opacity;case ID_PALETTE:return &t->palette;case ID_COLOR:return t->rgb;case ID_MODE:return &t->mode;case ID_HARD:return &t->hard;case ID_RADIUS:return &t->radius;case ID_STRENGTH:return &t->strength;case ID_NO_DEPTH:return &t->no_depth;case ID_WIRE_CUSTOM:return &t->wire_custom;case ID_WIRE_COLOR:return t->wire_color;case ID_WIREFRAME:return &t->wireframe;case ID_PREVIEW:return &t->preview;case ID_OPEN_FILE:return t->s->open_path;case ID_PROJECT:return t->s->project;case ID_PNG:return t->s->png;case ID_IMPORT_FILE:return t->s->import_path;case ID_STATUS:return t->status;default:return NULL;}}
static LWXPRefreshCode set_value(void*data,unsigned id,void*value){Tool*t=data;Session*s;int k;if(!is_live(t)||!value)return LWXPRC_NONE;if(!ink_control_allowed(t,id))return LWXPRC_NONE;s=t->s;if(t->adjusting||t->painting||t->pending||t->busy||t->queued_action)return LWXPRC_DFLT;switch(id){case ID_ALPHA_PRESETS:return LWXPRC_DRAW;case ID_MIRROR_X:case ID_MIRROR_Y:case ID_MIRROR_Z:t->mirror_axis[id-ID_MIRROR_X]=*(int*)value!=0;break;case ID_ALPHA_SIZE:k=*(int*)value;if(k>=0&&k<=2&&k!=alpha_size){alpha_size=k;t->queued_action=ID_ALPHA_SIZE;request_ui(t);}break;case ID_ALPHA_DIRECTORY:if(strlen(value)<1024){snprintf(t->alpha_directory,1024,"%s",(char*)value);t->queued_action=ID_ALPHA_REFRESH;request_ui(t);}break;case ID_ALPHA_SELECT:k=*(int*)value;if(k>0&&k<=alpha_catalog.count){alpha_catalog.selected=k;t->queued_action=ID_ALPHA_SELECT;request_ui(t);}break;case ID_ALPHA_INVERT:brush_alpha.mask.invert=*(int*)value!=0;break;case ID_UNDO_LEVELS:k=*(int*)value;undo_levels=k<1?1:k>10000?10000:k;tp_history_limit(&s->history,undo_levels);break;case ID_PROJECT_IMAGES:k=*(int*)value;if(k>0&&k<=t->image_count){t->project_image=k;t->queued_action=ID_PROJECT_IMAGES;request_ui(t);}break;case ID_STAMP_ROTATION:t->stamp_rotation=*(double*)value;if(!isfinite(t->stamp_rotation))t->stamp_rotation=0;t->stamp_rotation=remainder(t->stamp_rotation,360);break;case ID_STAMP_SHOW:t->stamp_show=*(int*)value!=0;break;case ID_STAMP_OPACITY:t->stamp_opacity=bound(*(double*)value);break;case ID_STAMP_X:t->stamp_x=bound(*(double*)value);break;case ID_STAMP_Y:t->stamp_y=bound(*(double*)value);break;case ID_STAMP_SCALE:t->stamp_scale=*(double*)value;if(!isfinite(t->stamp_scale)||t->stamp_scale<.05)t->stamp_scale=.05;if(t->stamp_scale>4)t->stamp_scale=4;break;case ID_AUTO_IMAGE:auto_save_image=*(int*)value!=0;status(t,auto_save_image?"PNG auto-save ON. Pending changes are saved at the next save point; Save Texture Now saves immediately.":"PNG auto-save OFF. Use Save Texture Now manually. Layered project safety saves remain active.");break;case ID_FAST_PREVIEW:t->fast_preview=*(int*)value!=0;if(s->valid)composite(t);break;case ID_SAVE_TIMING:t->save_timing=*(int*)value==1;break;case ID_RESOLUTION:k=*(int*)value;if(k>=0&&k<4)t->resolution=k;break;case ID_ALPHA:t->alpha=*(int*)value!=0;break;case ID_LAYER:if(s->valid){int v=*(int*)value;if(v>=0&&v<8){s->doc.active=v;sync_ui(t);}}break;case ID_NAME:if(s->valid&&strlen(value)<64&&checkpoint(t)){snprintf(s->doc.layer[s->doc.active].name,64,"%s",(char*)value);changed(t);}break;case ID_VISIBLE:if(s->valid&&checkpoint(t)){s->doc.layer[s->doc.active].visible=*(int*)value!=0;changed(t);}break;case ID_OPACITY:if(s->valid&&checkpoint(t)){s->doc.layer[s->doc.active].opacity=bound(*(double*)value);changed(t);}break;case ID_PALETTE:t->palette=*(int*)value;if(t->palette>0&&t->palette<13)memcpy(t->rgb,colors[t->palette],sizeof(t->rgb));break;case ID_COLOR:for(k=0;k<3;k++)t->rgb[k]=bound(((double*)value)[k]);t->palette=0;break;case ID_MODE:k=*(int*)value;if(k>=0&&k<=3){t->mode=k;request_ui(t);}break;case ID_HARD:t->hard=*(int*)value!=0;break;case ID_RADIUS:t->radius=*(double*)value;if(!isfinite(t->radius)||t->radius<1)t->radius=1;if(t->radius>180)t->radius=180;break;case ID_STRENGTH:t->strength=bound(*(double*)value);break;case ID_NO_DEPTH:t->no_depth=*(int*)value!=0;t->dirty=1;break;case ID_WIRE_CUSTOM:t->wire_custom=*(int*)value!=0;t->dirty=1;break;case ID_WIRE_COLOR:for(k=0;k<3;k++)t->wire_color[k]=bound(((double*)value)[k]);t->wire_custom=1;t->dirty=1;break;case ID_WIREFRAME:t->wireframe=*(int*)value!=0;t->dirty=1;break;case ID_PREVIEW:t->preview=*(int*)value!=0;break;case ID_OPEN_FILE:case ID_PROJECT:case ID_PNG:case ID_IMPORT_FILE:if(strlen(value)<1024){char*target=id==ID_PROJECT?s->project:id==ID_PNG?s->png:id==ID_OPEN_FILE?s->open_path:s->import_path;snprintf(target,1024,"%s",(char*)value);}break;default:return LWXPRC_NONE;}t->dirty=1;return LWXPRC_DFLT;}
static LWXPRefreshCode set(void*data,unsigned id,void*value){Tool*t=data;LWXPRefreshCode result;if(!is_live(t))return LWXPRC_NONE;t->ui_depth++;result=set_value(data,id,value);t->ui_depth--;if(t->ui_pending){t->ui_pending=0;return LWXPRC_FULL;}return result;}
#include "mirror_actions.inc"
static void button(LWXPanelID panel,int id){Tool*t=find_panel(panel);if(!t||t->adjusting||t->painting||t->pending||t->busy||t->queued_action||t->ui_refreshing)return;if(!ink_control_allowed(t,(unsigned)id))return;t->ui_depth++;trace(id==ID_PREP?"button.prepare":id==ID_CREATE?"button.create":"button.other",t);
 if(id==ID_PREP)t->update=LWT_TEST_UPDATE;
 else if(!t->s->valid&&id!=ID_LOAD_STAMP&&id!=ID_CENTER_STAMP&&id!=ID_REFRESH_IMAGES&&id!=ID_PROJECT_IMAGES&&id!=ID_ALPHA_REFRESH&&id!=ID_ALPHA_SELECT&&id!=ID_ALPHA_PREV&&id!=ID_ALPHA_NEXT&&id!=ID_ALPHA_IMPORT&&id!=ID_ALPHA_REMOVE)status(t,"Not prepared. Open Brush and click Prepare / Update UV Mesh first.");
 else{t->queued_action=id;t->dirty=1;}
 request_ui(t);t->ui_depth--;
}
static LWXPRefreshCode panel_changed(LWXPanelID panel,unsigned cid,unsigned vid,int event){Tool*t=find_panel(panel);(void)cid;(void)vid;(void)event;if(t&&t->ui_pending){t->ui_pending=0;return LWXPRC_FULL;}return LWXPRC_NONE;}
static void run_action(Tool*t,int id){Session*s=t->s;int l;if(!ink_control_allowed(t,(unsigned)id))return;if(id==ID_ALPHA_SIZE){alpha_catalog.scroll=0;load_alpha_page(t);return;}if(id==ID_ALPHA_SCROLL){alpha_catalog.scroll=t->alpha_scroll_target;load_alpha_page(t);return;}if(id==ID_ALPHA_REFRESH){refresh_alpha_catalog(t);return;}if(id==ID_ALPHA_SELECT){use_alpha_preset(t);return;}if(id==ID_ALPHA_IMPORT){import_brush_alpha(t);return;}if(id==ID_ALPHA_REMOVE){free(brush_alpha.data);memset(&brush_alpha,0,sizeof(brush_alpha));status(t,"Brush alpha removed. Normal painting restored.");return;}if(id==ID_REFRESH_IMAGES){refresh_project_images(t);return;}if(id==ID_PROJECT_IMAGES){use_project_image(t);return;}if(id==ID_LOAD_STAMP){choose_stamp_image(t);if(stamp_asset.path[0]&&t->images)t->images->load(stamp_asset.path);refresh_project_images(t);return;}if(id==ID_CENTER_STAMP){t->stamp_x=t->stamp_y=.5;t->stamp_scale=1;t->stamp_rotation=0;request_ui(t);return;}if(!s->valid){status(t,"Not prepared. Open Brush and click Prepare / Update UV Mesh first.");return;}l=s->doc.active;

 switch(id){case ID_COPY_NEG:case ID_COPY_POS:mirror_layer(t,id==ID_COPY_POS?1:-1);break;case ID_IMPORT_TEXTURE:choose_texture_image(t);break;case ID_CREATE:create_texture(t);break;case ID_WRITE_IMAGE:if(!s->doc.texture_path[0])status(t,"Create a texture first to link a PNG destination.");else if(save_texture(t))status(t,"PNG texture saved and image updated in LightWave.");break;case ID_CLEAR:if(checkpoint(t)){memset(s->doc.layer[l].rgba,0,(size_t)s->doc.size*s->doc.size*4);changed(t);}break;case ID_UP:case ID_DOWN:{int other=l+(id==ID_UP?1:-1);if(other>=0&&other<8&&checkpoint(t)){TPLayer r=s->doc.layer[l];s->doc.layer[l]=s->doc.layer[other];s->doc.layer[other]=r;s->doc.active=other;changed(t);}break;}case ID_UNDO:undo_action(t,0);break;case ID_REDO:undo_action(t,1);break;case ID_SAVE:s->modified=1;if(autosave(t))status(t,"Project saved with all eight layers.");break;case ID_EXPORT:status(t,atomic_file(s,s->png,0)?"PNG exported. Assign it to the material using the same UV map.":"Could not export PNG. Check the path and permissions.");break;
 case ID_IMPORT:{wchar_t path[MAX_PATH];unsigned char*p=malloc((size_t)s->doc.size*s->doc.size*4);if(!p)break;if(to_wide(s->import_path,path)&&decode_image(path,s->doc.size,p)&&checkpoint(t)){memcpy(s->doc.layer[l].rgba,p,(size_t)s->doc.size*s->doc.size*4);changed(t);}else status(t,"Could not import the image. Choose a valid PNG, JPEG or BMP file.");free(p);break;}
 case ID_OPEN:{wchar_t path[MAX_PATH];FILE*f;TPDoc d={0};if(!autosave(t))break;if(!to_wide(s->open_path,path)||(f=_wfopen(path,L"rb"))==NULL){status(t,"Could not open the selected project.");break;}if(!tp_project_read(f,&d,s->mesh.hash,s->mesh.uvname)){fclose(f);status(t,"Invalid project or geometry/UV mismatch.");break;}fclose(f);if(d.size!=s->doc.size){unsigned char*c=malloc((size_t)d.size*d.size*4),*display=malloc((size_t)d.size*d.size*3);float*m=calloc((size_t)d.size*d.size,sizeof(float));if(!c||!display||!m){free(c);free(display);free(m);tp_doc_free(&d);status(t,"Not enough memory.");break;}free(s->composite);free(s->preview_rgb);free(s->coverage);s->composite=c;s->preview_rgb=display;s->coverage=m;}tp_history_free(&s->history);s->history_pending=0;tp_doc_free(&s->doc);tp_doc_free(&s->undo);s->doc=d;memset(s->coverage,0,(size_t)d.size*d.size*sizeof(float));memset(&s->coverage_rect,0,sizeof(s->coverage_rect));s->undo_dirty=255;snprintf(s->project,1024,"%s",s->open_path);s->canundo=s->canredo=0;s->modified=0;s->image_modified=d.texture_path[0]!=0;t->cache_valid=0;t->alpha=d.alpha;if(d.texture_path[0])snprintf(s->png,1024,"%s",d.texture_path);t->resolution=d.size==8192?3:d.size==4096?2:d.size==2048?1:0;composite(t);sync_ui(t);status(t,"Project opened. You can continue painting in the viewports.");break;}
 }
}
static LWXPanelID panel(LWInstance inst){Tool*t=inst;static LWXPanelControl c[]={
 {ID_AXIS_ROW,"","dThumbnail"},{ID_COPY_NEG,"Mirror X -","vButton"},{ID_COPY_POS,"Mirror X +","vButton"},
 {ID_ALPHA_SIZE,"Preset Thumbnail Size","iPopChoice"},{ID_ALPHA_PRESETS,"Alpha Presets","dThumbnail"},{ID_ALPHA_DIRECTORY,"Alpha Content Directory","sFileName"},{ID_ALPHA_SELECT,"Preset","iPopChoice"},{ID_ALPHA_IMPORT,"Import Brush Alpha...","vButton"},{ID_ALPHA_REMOVE,"Remove Brush Alpha","vButton"},{ID_ALPHA_INVERT,"Invert Alpha","iBoolean"},
 {ID_LOAD_STAMP,"Import Stamp Image...","vButton"},{ID_PROJECT_IMAGES,"Image Editor Images","iPopChoice"},{ID_REFRESH_IMAGES,"Refresh Image List","vButton"},{ID_STAMP_IMAGE,"Stamp Image","sInfo"},{ID_STAMP_SHOW,"Show Stamp Display","iBoolean"},{ID_STAMP_OPACITY,"Display Opacity","percent"},{ID_STAMP_X,"Stamp Center X","percent"},{ID_STAMP_Y,"Stamp Center Y","percent"},{ID_STAMP_SCALE,"Stamp Scale","percent"},{ID_STAMP_ROTATION,"Stamp Rotation (degrees)","float"},{ID_CENTER_STAMP,"Center / Fit Stamp","vButton"},
 {ID_IMPORT_TEXTURE,"Import Texture Image...","vButton"},{ID_AUTO_IMAGE,"Auto-save Texture Image","iBoolean"},{ID_FAST_PREVIEW,"Fast Preview (max 1K)","iBoolean"},{ID_SAVE_TIMING,"Save Timing","iPopChoice"},
 {ID_CURRENT,"Current Texture","sInfo"},{ID_RESOLUTION,"New Image Resolution","iPopChoice"},{ID_ALPHA,"New Image with Alpha","iBoolean"},{ID_CREATE,"Create Texture Image","vButton"},{ID_WRITE_IMAGE,"Save Texture Now","vButton"},
 {ID_PREP,"Prepare / Update UV Mesh","vButton"},
 {ID_LAYER,"Active Layer","iPopChoice"},{ID_NAME,"Layer Name","string"},{ID_VISIBLE,"Visible","iBoolean"},{ID_OPACITY,"Opacity","percent"},{ID_UP,"Move Layer Up","vButton"},{ID_DOWN,"Move Layer Down","vButton"},{ID_CLEAR,"Clear Layer","vButton"},
 {ID_COLOR,"Colour","color"},{ID_MODE,"Mode","iPopChoice"},{ID_HARD,"Hard Brush","iBoolean"},{ID_RADIUS,"Radius in Pixels","float"},{ID_STRENGTH,"Stroke Strength","percent"},{ID_PREVIEW,"Viewport Texture Preview","iBoolean"},{ID_WIREFRAME,"Show Wireframe","iBoolean"},{ID_WIRE_CUSTOM,"Wireframe Color","iBoolean"},{ID_WIRE_COLOR,"Wireframe Color","color"},{ID_NO_DEPTH,"No Depth","iBoolean"},
 {ID_UNDO_LEVELS,"Undo Levels (match Modeler)","integer"},
 {ID_OPEN_FILE,"Project to Open","sFileName"},{ID_PROJECT,"Project / Autosave","sFileName"},{ID_OPEN,"Open Selected Project","vButton"},{ID_SAVE,"Save Project","vButton"},{ID_PNG,"Destination PNG Image","sFileName"},{ID_EXPORT,"Export PNG","vButton"},{ID_IMPORT_FILE,"Image to Import","sFileName"},{ID_IMPORT,"Import into Active Layer","vButton"},{0}};
 static LWXPanelDataDesc data[]={
 {ID_ALPHA_PRESETS,"Alpha Presets","integer"},{ID_AXIS_ROW,"Symmetry","integer"},
 {ID_ALPHA_SIZE,"Thumbnail Size","integer"},{ID_ALPHA_DIRECTORY,"Alpha Directory","string"},{ID_ALPHA_SELECT,"Preset","integer"},{ID_ALPHA_INVERT,"Invert Alpha","integer"},
 {ID_UNDO_LEVELS,"Undo Levels","integer"},{ID_PROJECT_IMAGES,"Image Editor Images","integer"},
 {ID_STAMP_IMAGE,"Stamp Image","string"},{ID_STAMP_SHOW,"Show Stamp","integer"},{ID_STAMP_OPACITY,"Display Opacity","percent"},{ID_STAMP_X,"Center X","percent"},{ID_STAMP_Y,"Center Y","percent"},{ID_STAMP_SCALE,"Scale","percent"},{ID_STAMP_ROTATION,"Rotation","float"},
 {ID_AUTO_IMAGE,"Auto-save Texture Image","integer"},{ID_FAST_PREVIEW,"Fast Preview","integer"},{ID_SAVE_TIMING,"Save Timing","integer"},
 {ID_READY,"Prepared","integer"},{ID_CURRENT,"Current Texture","string"},{ID_RESOLUTION,"Resolution","integer"},{ID_ALPHA,"Alpha","integer"},
 {ID_LAYER,"Layer","integer"},{ID_NAME,"Name","string"},{ID_VISIBLE,"Visible","integer"},{ID_OPACITY,"Opacity","percent"},{ID_COLOR,"Colour","color"},{ID_MODE,"Mode","integer"},{ID_HARD,"Hard","integer"},{ID_RADIUS,"Radius","float"},{ID_STRENGTH,"Strength","percent"},{ID_PREVIEW,"Preview","integer"},{ID_WIREFRAME,"Show Wireframe","integer"},{ID_WIRE_CUSTOM,"Wireframe Color","integer"},{ID_WIRE_COLOR,"Wireframe Color","color"},{ID_NO_DEPTH,"No Depth","integer"},{ID_OPEN_FILE,"Open","string"},{ID_PROJECT,"Project","string"},{ID_PNG,"PNG","string"},{ID_IMPORT_FILE,"Import","string"},{0}};
 static int ink_enabled[]={0,0,0,1};
 LWXPanelHint hints[]={XpENABLE_MAP_(ID_MODE,ink_enabled),XpH(ID_LOAD_STAMP),XpH(ID_PROJECT_IMAGES),XpH(ID_REFRESH_IMAGES),XpH(ID_STAMP_IMAGE),XpH(ID_STAMP_SHOW),XpH(ID_STAMP_OPACITY),XpH(ID_STAMP_X),XpH(ID_STAMP_Y),XpH(ID_STAMP_SCALE),XpH(ID_STAMP_ROTATION),XpH(ID_CENTER_STAMP),XpEND,XpLABEL(0,"3A_Texture Paint v0.39 - Numeric"),XpSTRLIST(ID_ALPHA_SIZE,alpha_sizes),XpXREQCFG(ID_ALPHA_DIRECTORY,LWXPREQ_DIR,"Alpha Content Directory",""),XpPOPFUNCS(ID_ALPHA_SELECT,alpha_count,alpha_name),XpCTRLCFG(ID_ALPHA_PRESETS,THUM_XLG|THUM_FULL),XpDRAWCBFUNC(ID_ALPHA_PRESETS,alpha_gallery_draw),XpMOVECBFUNC(ID_ALPHA_PRESETS,alpha_gallery_move),XpMOUSECBFUNC(ID_ALPHA_PRESETS,alpha_gallery_mouse),XpZOOMCBFUNC(ID_ALPHA_PRESETS,alpha_gallery_click,0),XpBUTNOTIFY(ID_ALPHA_IMPORT,button),XpBUTNOTIFY(ID_ALPHA_REMOVE,button),XpPOPFUNCS(ID_PROJECT_IMAGES,project_image_count,project_image_name),XpBUTNOTIFY(ID_REFRESH_IMAGES,button),XpMIN(ID_UNDO_LEVELS,1),XpMAX(ID_UNDO_LEVELS,10000),XpBUTNOTIFY(ID_LOAD_STAMP,button),XpBUTNOTIFY(ID_CENTER_STAMP,button),XpSTRLIST(ID_SAVE_TIMING,save_timings),XpCHGNOTIFY(panel_changed),XpENABLE_(ID_READY),XpH(ID_CREATE),XpH(ID_IMPORT_TEXTURE),XpEND,XpSTRLIST(ID_RESOLUTION,resolutions),XpBUTNOTIFY(ID_IMPORT_TEXTURE,button),XpBUTNOTIFY(ID_CREATE,button),XpBUTNOTIFY(ID_WRITE_IMAGE,button),XpSTRLIST(ID_LAYER,layer_names),XpSTRLIST(ID_MODE,modes),XpMIN(ID_RADIUS,1),XpMAX(ID_RADIUS,180),XpXREQCFG(ID_OPEN_FILE,LWXPREQ_LOAD,"Open Project","*.tpaint"),XpXREQCFG(ID_PROJECT,LWXPREQ_SAVE,"TexturePaint Project","*.tpaint"),XpXREQCFG(ID_PNG,LWXPREQ_SAVE,"Export PNG","*.png"),XpXREQCFG(ID_IMPORT_FILE,LWXPREQ_LOAD,"Import Image","*.png;*.jpg;*.bmp"),XpBUTNOTIFY(ID_PREP,button),XpBUTNOTIFY(ID_UP,button),XpBUTNOTIFY(ID_DOWN,button),XpBUTNOTIFY(ID_CLEAR,button),XpBUTNOTIFY(ID_OPEN,button),XpBUTNOTIFY(ID_SAVE,button),XpBUTNOTIFY(ID_EXPORT,button),XpBUTNOTIFY(ID_IMPORT,button),XpCTRLCFG(ID_AXIS_ROW,THUM_SNGL|THUM_FULL|THUM_BORDER_NONE),XpDRAWCBFUNC(ID_AXIS_ROW,axes_draw),XpZOOMCBFUNC(ID_AXIS_ROW,axes_click,0),XpBUTNOTIFY(ID_COPY_NEG,button),XpBUTNOTIFY(ID_COPY_POS,button),XpLEFT(ID_COPY_NEG),XpNARROW(ID_COPY_NEG),XpNARROW(ID_COPY_POS),XpGROUP_(0x9100),XpH(ID_PREP),XpH(ID_COLOR),XpH(ID_MODE),XpH(ID_RADIUS),XpH(ID_STRENGTH),XpH(ID_HARD),XpH(ID_AXIS_ROW),XpH(ID_COPY_NEG),XpH(ID_COPY_POS),XpH(ID_ALPHA_SIZE),XpH(ID_ALPHA_PRESETS),XpH(ID_ALPHA_DIRECTORY),XpH(ID_ALPHA_SELECT),XpH(ID_ALPHA_IMPORT),XpH(ID_ALPHA_REMOVE),XpH(ID_ALPHA_INVERT),XpH(ID_LOAD_STAMP),XpH(ID_PROJECT_IMAGES),XpH(ID_REFRESH_IMAGES),XpH(ID_STAMP_IMAGE),XpH(ID_STAMP_SHOW),XpH(ID_STAMP_OPACITY),XpH(ID_STAMP_X),XpH(ID_STAMP_Y),XpH(ID_STAMP_SCALE),XpH(ID_STAMP_ROTATION),XpH(ID_CENTER_STAMP),XpH(ID_UNDO_LEVELS),XpH(ID_PREVIEW),XpH(ID_WIREFRAME),XpH(ID_WIRE_CUSTOM),XpH(ID_WIRE_COLOR),XpH(ID_NO_DEPTH),XpH(ID_FAST_PREVIEW),XpEND,
 XpGROUP_(0x9103),XpH(ID_IMPORT_TEXTURE),XpH(ID_PNG),XpH(ID_ALPHA),XpH(ID_RESOLUTION),XpH(ID_CREATE),XpH(ID_CURRENT),XpH(ID_AUTO_IMAGE),XpH(ID_WRITE_IMAGE),XpH(ID_EXPORT),XpH(ID_SAVE_TIMING),XpH(ID_PROJECT),XpH(ID_SAVE),XpH(ID_OPEN_FILE),XpH(ID_OPEN),XpEND,
 XpGROUP_(0x9101),XpH(ID_LAYER),XpH(ID_NAME),XpH(ID_VISIBLE),XpH(ID_OPACITY),XpH(ID_UP),XpH(ID_DOWN),XpH(ID_CLEAR),XpH(ID_IMPORT_FILE),XpH(ID_IMPORT),XpEND,
 XpDIVREM(ID_HARD),XpDIVREM(ID_AXIS_ROW),XpDIVADD(ID_COPY_POS),XpDIVADD(ID_ALPHA_INVERT),XpDIVADD(ID_CENTER_STAMP),XpDIVADD(ID_CURRENT),XpDIVADD(ID_CLEAR),
 XpLABEL(0x9103,"Texture"),XpLABEL(0x9100,"Brush"),XpLABEL(0x9101,"Layers"),XpTABS_(0x9110),XpH(0x9100),XpH(0x9103),XpH(0x9101),XpEND,
 XpDESTROYNOTIFY(panel_destroy),XpEND};
 if(t->panel)return t->panel;
 refresh_project_images(t);
 if(!alpha_catalog.loaded){default_alpha_directory();snprintf(t->alpha_directory,1024,"%s",alpha_catalog.directory);refresh_alpha_catalog(t);}else snprintf(t->alpha_directory,1024,"%s",alpha_catalog.directory);
 t->panel=t->xp->create(LWXP_VIEW,c);if(!t->panel)return NULL;t->xp->describe(t->panel,data,get,set);t->xp->hint(t->panel,0,hints);t->xp->setData(t->panel,0,t);t->xp->viewInst(t->panel,t);alpha_dispatch_start();alpha_wheel_start();alpha_dispatch_wake(t);return t->panel;}
static int activate(int version,GlobalFunc*global,void*local,void*server_data){LWMeshEditTool*l=local;Tool*t;(void)server_data;if(version!=LWMESHEDITTOOL_VERSION)return AFUNC_BADVERSION;t=calloc(1,sizeof(*t));if(!t)return AFUNC_BADLOCAL;t->global=global;t->xp=global(LWXPANELFUNCS_GLOBAL,GFUSE_TRANSIENT);t->vp=global(LWVIEWPORTINFO_GLOBAL,GFUSE_TRANSIENT);t->state=global(LWSTATEQUERYFUNCS_GLOBAL,GFUSE_TRANSIENT);t->messages=global(LWMESSAGEFUNCS_GLOBAL,GFUSE_TRANSIENT);if(!t->xp||!t->vp||!t->state||!t->messages){free(t);return AFUNC_BADGLOBAL;}t->images=global(LWIMAGELIST_GLOBAL,GFUSE_TRANSIENT);t->alpha=1;t->next=live_tools;live_tools=t;t->s=&session;t->stamp_show=1;t->stamp_opacity=.45;t->stamp_x=t->stamp_y=.5;t->stamp_scale=1;t->fast_preview=1;t->radius=30;t->strength=1;t->preview=1;t->cursor_view=-1;t->palette=3;memcpy(t->rgb,colors[3],sizeof(t->rgb));snprintf(t->status,sizeof(t->status),"Press N and click Prepare. LMB: paint. RMB drag: radius. Shift + RMB drag: strength.");if(session.valid){t->alpha=session.doc.alpha;t->resolution=session.doc.size==8192?3:session.doc.size==4096?2:session.doc.size==2048?1:0;}sync_ui(t);trace("tool.activate",t);
 l->instance=t;l->tool->done=done;l->tool->draw=NULL;l->tool->drawUV=NULL;l->tool->help=help;l->tool->dirty=dirty;l->tool->down=down;l->tool->move=move;l->tool->up=up;l->tool->track=track;l->tool->event=event;l->tool->panel=panel;l->tool->undo=tool_undo;l->tool->redo=tool_redo;l->tool->drawOverlay=overlay;l->tool->drawOverlayUV=overlay;l->build=build;l->test=test;l->end=end;return AFUNC_OK;}
static void*startup(void){return (void*)1;}
static void module_shutdown(void*p){(void)p;alpha_wheel_stop();alpha_dispatch_stop();if(session.valid){if(session.modified)atomic_file(&session,session.project,1);if(auto_save_image&&session.image_modified&&session.doc.texture_path[0])atomic_file(&session,session.doc.texture_path,0);}free_session(&session);free(stamp_asset.rgba);free(stamp_asset.display_rgba);memset(&stamp_asset,0,sizeof(stamp_asset));free(brush_alpha.data);memset(&brush_alpha,0,sizeof(brush_alpha));free_alpha_catalog();}
static ServerTagInfo tags[]={{"3A_Texture Paint",SRVTAG_USERNAME|LANGID_USENGLISH},{"3A_Texture Paint",SRVTAG_BUTTONNAME|LANGID_USENGLISH},{NULL,0}};
static ServerRecord servers[]={{LWMESHEDITTOOL_CLASS,"3A_TexturePaint",activate,tags},{NULL,NULL,NULL,NULL}};
__declspec(dllexport) ModuleDescriptor _mod_descrip={MOD_SYSSYNC,MOD_SYSVER,MOD_MACHINE,startup,module_shutdown,servers};
