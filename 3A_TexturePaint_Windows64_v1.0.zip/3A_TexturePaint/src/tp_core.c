/* Original texture-painting engine. MIT. No LightWave dependency. */
#include "tp_core.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include "spatial.inc"
static double clamp(double x){return !isfinite(x)?0:x<0?0:x>1?1:x;}
static unsigned char byte(double x){return (unsigned char)(255*clamp(x)+.5);}
static int valid_size(int s){return s==512||s==1024||s==2048||s==4096||s==8192;}
void tp_doc_free(TPDoc*d){int l;for(l=0;l<TP_LAYERS;l++)free(d->layer[l].rgba);memset(d,0,sizeof(*d));}
int tp_doc_init(TPDoc*d,int size,uint64_t hash,const char*uv){int l;memset(d,0,sizeof(*d));if(!valid_size(size))return 0;d->size=size;d->alpha=1;d->mesh_hash=hash;snprintf(d->uvname,sizeof(d->uvname),"%s",uv);for(l=0;l<TP_LAYERS;l++){d->layer[l].rgba=calloc((size_t)size*size,4);if(!d->layer[l].rgba){tp_doc_free(d);return 0;}snprintf(d->layer[l].name,64,"Layer %02d",l+1);d->layer[l].opacity=1;d->layer[l].visible=1;}return 1;}
int tp_doc_clone(TPDoc*out,const TPDoc*d){int l;if(!tp_doc_init(out,d->size,d->mesh_hash,d->uvname))return 0;out->active=d->active;out->alpha=d->alpha;memcpy(out->texture_path,d->texture_path,sizeof(out->texture_path));for(l=0;l<TP_LAYERS;l++){memcpy(out->layer[l].rgba,d->layer[l].rgba,(size_t)d->size*d->size*4);memcpy(out->layer[l].name,d->layer[l].name,64);out->layer[l].opacity=d->layer[l].opacity;out->layer[l].visible=d->layer[l].visible;}return 1;}
void tp_rect_add(TPRect*r,int x,int y){if(!r)return;if(!r->valid){r->x0=r->x1=x;r->y0=r->y1=y;r->valid=1;return;}if(x<r->x0)r->x0=x;if(x>r->x1)r->x1=x;if(y<r->y0)r->y0=y;if(y>r->y1)r->y1=y;}
void tp_composite_region(const TPDoc*d,unsigned char*out,const TPRect*r){int x,y,l,k,x0=0,y0=0,x1=d->size-1,y1=d->size-1;if(r){if(!r->valid)return;x0=r->x0<0?0:r->x0;y0=r->y0<0?0:r->y0;x1=r->x1>=d->size?d->size-1:r->x1;y1=r->y1>=d->size?d->size-1:r->y1;}for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){size_t i=(size_t)y*d->size+x;double c[3]={0,0,0},a=0;for(l=0;l<TP_LAYERS;l++){const TPLayer*r=&d->layer[l];const unsigned char*p=r->rgba+4*i;double b=r->visible?p[3]/255.0*r->opacity:0;if(b<=0)continue;for(k=0;k<3;k++)c[k]=p[k]/255.0*b+c[k]*(1-b);a=b+a*(1-b);}for(k=0;k<3;k++)out[4*i+k]=byte(a>0?c[k]/a:0);out[4*i+3]=byte(a);}}
void tp_composite(const TPDoc*d,unsigned char*out){tp_composite_region(d,out,NULL);}
static void hash_integer(uint64_t*h,int64_t value){int i;uint64_t u=(uint64_t)value;for(i=0;i<8;i++){*h^=(u>>(8*i))&255;*h*=UINT64_C(1099511628211);}}
int tp_mesh_finish(TPMesh*m){size_t i;int j,k;double lo[3]={DBL_MAX,DBL_MAX,DBL_MAX},hi[3]={-DBL_MAX,-DBL_MAX,-DBL_MAX};if(!m->count||m->count>TP_MAX_TRIANGLES)return 0;m->hash=UINT64_C(14695981039346656037);for(i=0;i<m->count;i++)for(j=0;j<3;j++){TPVertex*v=&m->tri[i].v[j];for(k=0;k<3;k++){if(!isfinite(v->p[k])||fabs(v->p[k])>1e9)return 0;if(v->p[k]<lo[k])lo[k]=v->p[k];if(v->p[k]>hi[k])hi[k]=v->p[k];hash_integer(&m->hash,(int64_t)llround(v->p[k]*1e6));}for(k=0;k<2;k++){if(!isfinite(v->uv[k])||v->uv[k]<0||v->uv[k]>1)return 0;hash_integer(&m->hash,(int64_t)llround(v->uv[k]*1e8));}}
 for(k=0;k<3;k++)m->center[k]=(lo[k]+hi[k])*.5;
 for(i=0;i<m->count;i++)hash_integer(&m->hash,m->tri[i].outline);
 m->radius=0;
 for(i=0;i<m->count;i++)for(j=0;j<3;j++){double sum=0;for(k=0;k<3;k++){double x=m->tri[i].v[j].p[k]-m->center[k];sum+=x*x;}if(sum>m->radius)m->radius=sum;}
 m->radius=sqrt(m->radius);return m->radius>1e-12;}
int tp_view_resize(TPView*v,int w,int h){uint32_t*p,*owner;float*z;if(w<1||h<1||w>4096||h>4096)return 0;p=malloc((size_t)w*h*4);z=malloc((size_t)w*h*sizeof(float));owner=malloc((size_t)w*h*sizeof(uint32_t));if(!p||!z||!owner){free(p);free(z);free(owner);return 0;}free(v->bgra);free(v->depth);free(v->owner);v->bgra=p;v->depth=z;v->owner=owner;v->w=w;v->h=h;return 1;}
void tp_view_free(TPView*v){spatial_free(v);free(v->bgra);free(v->depth);free(v->owner);free(v->projected);memset(v,0,sizeof(*v));}
static TPProjected project(const TPView*v,const TPMesh*m,const double*p){TPProjected q;double x=(p[0]-m->center[0])/m->radius,y=(p[1]-m->center[1])/m->radius,z=(p[2]-m->center[2])/m->radius,cy=cos(v->yaw),sy=sin(v->yaw),cp=cos(v->pitch),sp=sin(v->pitch),a=cy*x+sy*z,b=-sy*x+cy*z,c=cp*y-sp*b; q.z=v->distance-(sp*y+cp*b);q.w=q.z;q.x=v->w*.5+v->panx+a*v->h*1.2/q.z;q.y=v->h*.5+v->pany-c*v->h*1.2/q.z;return q;}
static double edge(double ax,double ay,double bx,double by,double px,double py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);}
static int bary(double ax,double ay,double bx,double by,double cx,double cy,double x,double y,double*b){double area=edge(ax,ay,bx,by,cx,cy);if(fabs(area)<1e-14)return 0;b[0]=edge(bx,by,cx,cy,x,y)/area;b[1]=edge(cx,cy,ax,ay,x,y)/area;b[2]=1-b[0]-b[1];return b[0]>=-1e-7&&b[1]>=-1e-7&&b[2]>=-1e-7;}
static int mini(double a,double b,double c,int lo,int hi){double d=fmin(a,fmin(b,c));if(d<lo)return lo;if(d>hi)return hi;return (int)floor(d);}
static int maxi(double a,double b,double c,int lo,int hi){double d=fmax(a,fmax(b,c));if(d<lo)return lo;if(d>hi)return hi;return (int)ceil(d);}
static uint32_t sample(const unsigned char*rgba,int size,double u,double vv,int x,int y){int tx=(int)(clamp(u)*size),ty=(int)((1-clamp(vv))*size),k;double a,bg;unsigned c[3];const unsigned char*p;if(tx==size)tx--;if(ty==size)ty--;p=rgba+4*((size_t)ty*size+tx);a=p[3]/255.0;bg=(((x/16)+(y/16))&1)?210:240;for(k=0;k<3;k++)c[k]=(unsigned)(p[k]*a+bg*(1-a)+.5);return (c[0]<<16)|(c[1]<<8)|c[2];}
int tp_render_projected(TPView*v,const TPMesh*m,const TPDoc*d,const unsigned char*rgba){size_t i,n=(size_t)v->w*v->h;int j,x,y;if(!v->bgra||!v->depth||!v->owner||!d->size)return 0;spatial_free(v);for(i=0;i<n;i++){v->bgra[i]=0x202831;v->depth[i]=FLT_MAX;v->owner[i]=UINT32_MAX;}
 if(v->uv_mode){if(!rgba)return 1;double side=fmin(v->w,v->h)*.9,left=(v->w-side)*.5,top=(v->h-side)*.5;for(y=0;y<v->h;y++)for(x=0;x<v->w;x++)if(x>=left&&x<left+side&&y>=top&&y<top+side)v->bgra[(size_t)y*v->w+x]=sample(rgba,d->size,(x-left)/side,1-(y-top)/side,x,y);return 1;}
 if(v->project_count!=m->count||!v->projected)return 0;
 for(i=0;i<m->count;i++){
  TPProjected*q=v->projected+3*i;const TPTriangle*t=&m->tri[i];int x0,x1,y0,y1;if(!projected_valid(q))continue;
  x0=mini(q[0].x,q[1].x,q[2].x,0,v->w-1);x1=maxi(q[0].x,q[1].x,q[2].x,0,v->w-1);y0=mini(q[0].y,q[1].y,q[2].y,0,v->h-1);y1=maxi(q[0].y,q[1].y,q[2].y,0,v->h-1);
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){double b[3],iz,z,u=0,uv=0;size_t at=(size_t)y*v->w+x;if(!bary(q[0].x,q[0].y,q[1].x,q[1].y,q[2].x,q[2].y,x+.5,y+.5,b))continue;iz=b[0]/q[0].w+b[1]/q[1].w+b[2]/q[2].w;z=(b[0]*q[0].z/q[0].w+b[1]*q[1].z/q[1].w+b[2]*q[2].z/q[2].w)/iz;if(z>=v->depth[at])continue;if(rgba)for(j=0;j<3;j++){u+=b[j]*t->v[j].uv[0]/q[j].w;uv+=b[j]*t->v[j].uv[1]/q[j].w;}v->depth[at]=(float)z;v->owner[at]=(uint32_t)i;if(rgba)v->bgra[at]=sample(rgba,d->size,u/iz,uv/iz,x,y);}
 }spatial_build(v);return 1;}
int tp_render(TPView*v,const TPMesh*m,const TPDoc*d,const unsigned char*rgba){size_t i;int j;if(v->project_count!=m->count){TPProjected*p=realloc(v->projected,m->count*3*sizeof(*p));if(!p)return 0;v->projected=p;v->project_count=m->count;}for(i=0;i<m->count;i++)for(j=0;j<3;j++)v->projected[i*3+j]=project(v,m,m->tri[i].v[j].p);return tp_render_projected(v,m,d,rgba);}
int tp_stencil_place(const unsigned char*rgba,int iw,int ih,int vw,int vh,double cx,double cy,double scale,TPStencil*out){double fit;
 if(!out||!rgba||iw<1||ih<1||vw<1||vh<1||!isfinite(cx)||!isfinite(cy)||!isfinite(scale)||scale<=0)return 0;
 fit=fmin(vw*.5/iw,vh*.5/ih)*scale;out->rgba=rgba;out->width=iw;out->height=ih;out->display_width=iw*fit;out->display_height=ih*fit;out->left=vw*cx-out->display_width*.5;out->top=vh*cy-out->display_height*.5;out->rotation_cos=1;out->rotation_sin=0;return 1;
}
/* Rotate local offsets around the image centre; used by preview and handles. */
void tp_stencil_point(const TPStencil*s,double x,double y,double out[2]){
 out[0]=s->left+s->display_width*.5+s->rotation_cos*x-s->rotation_sin*y;
 out[1]=s->top+s->display_height*.5+s->rotation_sin*x+s->rotation_cos*y;
}
/* Bilinear sampling in premultiplied alpha avoids coloured fringes around cutouts.
   Viewport coordinates use a top-left origin, just like imported image rows. */
int tp_stencil_sample(const TPStencil*s,double x,double y,double out[4]){double u,v,fx,fy,alpha=0,premul[3]={0};int x0,y0,dx,dy,k;
 if(!s||!s->rgba||s->width<1||s->height<1||!isfinite(s->display_width)||!isfinite(s->display_height)||s->display_width<=0||s->display_height<=0)return 0;
 x-=s->left+s->display_width*.5;y-=s->top+s->display_height*.5;
 u=(s->rotation_cos*x+s->rotation_sin*y)/s->display_width+.5;v=(-s->rotation_sin*x+s->rotation_cos*y)/s->display_height+.5;
 if(!isfinite(u)||!isfinite(v)||u<0||v<0||u>=1||v>=1)return 0;
 u=u*s->width-.5;v=v*s->height-.5;x0=(int)floor(u);y0=(int)floor(v);fx=u-x0;fy=v-y0;
 for(dy=0;dy<2;dy++)for(dx=0;dx<2;dx++){int ix=x0+dx,iy=y0+dy;double w=(dx?fx:1-fx)*(dy?fy:1-fy),a;const unsigned char*p;
  if(ix<0)ix=0;
  if(ix>=s->width)ix=s->width-1;
  if(iy<0)iy=0;
  if(iy>=s->height)iy=s->height-1;
  p=s->rgba+((size_t)iy*s->width+ix)*4;a=p[3]/255.0;alpha+=w*a;for(k=0;k<3;k++)premul[k]+=w*a*p[k]/255.0;
 }
 if(alpha<=0)return 0;
 for(k=0;k<3;k++)out[k]=premul[k]/alpha;
 out[3]=alpha;return 1;
}
void tp_line_endpoint(const double start[2],const double end[2],int snap,double out[2]){
 double dx=end[0]-start[0],dy=end[1]-start[1],angle,length;
 if(!snap){out[0]=end[0];out[1]=end[1];return;}
 angle=round(atan2(dy,dx)/.7853981633974483)*.7853981633974483;
 length=dx*cos(angle)+dy*sin(angle);
 out[0]=start[0]+length*cos(angle);out[1]=start[1]+length*sin(angle);
}
double tp_alpha_sample(const TPAlpha*a,double x,double y){
 double u=(x+1)*.5,v=(y+1)*.5,fx,fy,value=0;int ix,iy,dx,dy;
 if(!a||!a->gray)return 1;
 if(a->width<1||a->height<1||!isfinite(u)||!isfinite(v)||u<0||u>1||v<0||v>1)return 0;
 u=u*a->width-.5;v=v*a->height-.5;ix=(int)floor(u);iy=(int)floor(v);fx=u-ix;fy=v-iy;
 for(dy=0;dy<2;dy++)for(dx=0;dx<2;dx++){int sx=ix+dx,sy=iy+dy;if(sx<0)sx=0;if(sy<0)sy=0;if(sx>=a->width)sx=a->width-1;if(sy>=a->height)sy=a->height-1;
 value+=(dx?fx:1-fx)*(dy?fy:1-fy)*a->gray[(size_t)sy*a->width+sx]/255.;}
 return a->invert?1-value:value;
}
static int dab_pixel(TPDoc*d,const TPDoc*before,float*mask,const TPBrush*brush,size_t at,double dist,TPRect*dirty,const TPStencil*stencil,double sx,double sy,const TPAlpha*alpha,double mx,double my){double weight,oldalpha,a,newalpha,ink[4]={brush->color[0]/255.0,brush->color[1]/255.0,brush->color[2]/255.0,1};int k;unsigned char*out;const unsigned char*old;if(dist>=brush->radius)return 0;weight=1-dist/brush->radius;if(!brush->hard)weight=weight*weight*(3-2*weight);else weight=1;weight*=clamp(brush->strength);if(alpha)weight*=tp_alpha_sample(alpha,(sx-mx)/brush->radius,(sy-my)/brush->radius);if(stencil){if(!tp_stencil_sample(stencil,sx,sy,ink))return 0;weight*=ink[3];}if(weight<=mask[at])return 0;mask[at]=(float)weight;tp_rect_add(dirty,(int)(at%d->size),(int)(at/d->size));out=d->layer[d->active].rgba+4*at;old=before->layer[d->active].rgba+4*at;oldalpha=old[3]/255.0;if(brush->erase){memcpy(out,old,3);out[3]=byte(oldalpha*(1-weight));if(!out[3])memset(out,0,4);return 1;}a=weight;newalpha=a+oldalpha*(1-a);out[3]=byte(newalpha);for(k=0;k<3;k++)out[k]=byte(newalpha>0?(ink[k]*a+old[k]/255.0*oldalpha*(1-a))/newalpha:0);return 1;}
/* Fill UV-covered texels once, regardless of viewport visibility or overlap. */
int tp_fill_mesh(const TPMesh*m,TPDoc*d,const TPDoc*before,float*mask,const TPBrush*brush,TPRect*dirty){
 size_t i;int j,x,y,changed=0,s=d->size;TPBrush fill=*brush;
 if(!m||!mask||s<1||before->size!=s||clamp(brush->strength)<=0)return 0;
 fill.radius=1;fill.hard=1;fill.erase=0;
 for(i=0;i<m->count;i++){
  double u[3],v[3];int x0,x1,y0,y1;
  for(j=0;j<3;j++){u[j]=m->tri[i].v[j].uv[0]*s;v[j]=(1-m->tri[i].v[j].uv[1])*s;}
  x0=mini(u[0],u[1],u[2],0,s-1);x1=maxi(u[0],u[1],u[2],0,s-1);
  y0=mini(v[0],v[1],v[2],0,s-1);y1=maxi(v[0],v[1],v[2],0,s-1);
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){
   size_t at=(size_t)y*s+x;double b[3];if(mask[at]>0)continue;
   if(bary(u[0],v[0],u[1],v[1],u[2],v[2],x+.5,y+.5,b))
    changed|=dab_pixel(d,before,mask,&fill,at,0,dirty,NULL,0,0,NULL,0,0);
  }
 }
 return changed;
}
typedef struct {double x,y,uz,vz,iz;} ClipVertex;
static int brush_uv_bounds(const TPTriangle*t,const TPProjected*q,double mx,double my,double r,int size,int*bounds){
 ClipVertex a[16],b[16];int count=3,pass,j,n;double min_u=DBL_MAX,min_v=DBL_MAX,max_u=-DBL_MAX,max_v=-DBL_MAX;
 for(j=0;j<3;j++){if(q[j].w<=0)return 0;a[j].x=q[j].x;a[j].y=q[j].y;a[j].iz=1/q[j].w;a[j].uz=t->v[j].uv[0]/q[j].w;a[j].vz=t->v[j].uv[1]/q[j].w;}
 for(pass=0;pass<4;pass++){
  double limit=pass==0?mx-r:pass==1?mx+r:pass==2?my-r:my+r;n=0;
  for(j=0;j<count;j++){ClipVertex p=a[j],v=a[(j+1)%count];double cp=pass<2?p.x:p.y,cv=pass<2?v.x:v.y;int inp=(pass==0||pass==2)?cp>=limit:cp<=limit,inv=(pass==0||pass==2)?cv>=limit:cv<=limit;
   if(inp)b[n++]=p;
   if(inp!=inv){double w=(limit-cp)/(cv-cp);ClipVertex z;z.x=p.x+(v.x-p.x)*w;z.y=p.y+(v.y-p.y)*w;z.uz=p.uz+(v.uz-p.uz)*w;z.vz=p.vz+(v.vz-p.vz)*w;z.iz=p.iz+(v.iz-p.iz)*w;b[n++]=z;}
  }
  if(!n)return 0;
  memcpy(a,b,(size_t)n*sizeof(*a));count=n;
 }
 for(j=0;j<count;j++){double u=a[j].uz/a[j].iz,vy=1-a[j].vz/a[j].iz;min_u=fmin(min_u,u);max_u=fmax(max_u,u);min_v=fmin(min_v,vy);max_v=fmax(max_v,vy);}
 bounds[0]=(int)fmax(0,floor(min_u*size)-1);bounds[1]=(int)fmin(size-1,ceil(max_u*size)+1);bounds[2]=(int)fmax(0,floor(min_v*size)-1);bounds[3]=(int)fmin(size-1,ceil(max_v*size)+1);return 1;
}
/* Visibility is evaluated at the projected texel, not extrapolated from
   whichever triangle owns the neighbouring screen-pixel centre. */
static int paint_point_visible(const TPView*v,size_t source,double sx,double sy,double z,int ix,int iy){
 uint32_t seen[25];int count=0,xx,yy,k;
 if(v->owner[(size_t)iy*v->w+ix]==source)return 1;
 for(yy=iy-2;yy<=iy+2;yy++)for(xx=ix-2;xx<=ix+2;xx++){
  uint32_t owner;const TPProjected*q;double b[3],iz,front;
  if(xx<0||yy<0||xx>=v->w||yy>=v->h)continue;
  owner=v->owner[(size_t)yy*v->w+xx];if(owner>=v->project_count||owner==source)continue;
  for(k=0;k<count;k++)if(seen[k]==owner)break;
  if(k<count)continue;
  seen[count++]=owner;q=v->projected+owner*3;
  if(q[0].w<=0||q[1].w<=0||q[2].w<=0||!bary(q[0].x,q[0].y,q[1].x,q[1].y,q[2].x,q[2].y,sx,sy,b))continue;
  iz=b[0]/q[0].w+b[1]/q[1].w+b[2]/q[2].w;if(iz<=0)continue;
  front=(b[0]*q[0].z/q[0].w+b[1]*q[1].z/q[1].w+b[2]*q[2].z/q[2].w)/iz;
  if(z>front+1e-6)return 0;
 }
 return 1;
}
static int stamp_mapped(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*before,float*mask,const TPBrush*brush,double mx,double my,TPRect*dirty,const TPStencil*stencil,const TPAlpha*alpha,const TPMirrorFace*map){size_t i;int x,y,j,changed=0,s=d->size;if(brush->radius<1||before->size!=s)return 0;
 if(v->uv_mode){double side=fmin(v->w,v->h)*.9,left=(v->w-side)*.5,top=(v->h-side)*.5;int x0=(int)fmax(0,floor((mx-brush->radius-left)/side*s)),x1=(int)fmin(s-1,ceil((mx+brush->radius-left)/side*s)),y0=(int)fmax(0,floor((my-brush->radius-top)/side*s)),y1=(int)fmin(s-1,ceil((my+brush->radius-top)/side*s));for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){double sx=left+(x+.5)/s*side,sy=top+(y+.5)/s*side;changed|=dab_pixel(d,before,mask,brush,(size_t)y*s+x,hypot(sx-mx,sy-my),dirty,stencil,sx,sy,alpha,mx,my);}return changed;}
 if(v->project_count!=m->count||!v->projected)return 0;
 TPSpatialIter iterator;size_t scan=0;int indexed=!map&&v->spatial_count>0;if(indexed)spatial_begin(&iterator,mx,my,brush->radius);
 while(indexed?spatial_next(v,&iterator,&i):(i=scan++)<m->count){
  const TPTriangle*t=&m->tri[i];TPProjected reflected[3],*q=v->projected+3*i;size_t source=i;double uvx[3],uvy[3];int x0,x1,y0,y1,bounds[4];
  if(map){source=map[i].source;if(source>=m->count)continue;for(j=0;j<3;j++)reflected[j]=v->projected[source*3+map[i].corner[j]];q=reflected;}
  if(!projected_valid(q))continue;
  if(fmax(q[0].x,fmax(q[1].x,q[2].x))<mx-brush->radius||fmin(q[0].x,fmin(q[1].x,q[2].x))>mx+brush->radius||fmax(q[0].y,fmax(q[1].y,q[2].y))<my-brush->radius||fmin(q[0].y,fmin(q[1].y,q[2].y))>my+brush->radius)continue;
  for(j=0;j<3;j++){uvx[j]=t->v[j].uv[0]*s;uvy[j]=(1-t->v[j].uv[1])*s;}
  if(!brush_uv_bounds(t,q,mx,my,brush->radius,s,bounds))continue;
  x0=bounds[0];x1=bounds[1];y0=bounds[2];y1=bounds[3];
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++){
   double b[3],z=0,w=0,sx=0,sy=0,dist;int ix,iy;
   if(!bary(uvx[0],uvy[0],uvx[1],uvy[1],uvx[2],uvy[2],x+.5,y+.5,b))continue;
   for(j=0;j<3;j++){z+=b[j]*q[j].z;w+=b[j]*q[j].w;sx+=b[j]*q[j].x*q[j].w;sy+=b[j]*q[j].y*q[j].w;}if(w<=0)continue;sx/=w;sy/=w;dist=hypot(sx-mx,sy-my);if(dist>=brush->radius||sx<0||sy<0||sx>=v->w||sy>=v->h)continue;
   ix=(int)sx;iy=(int)sy;
   if(!v->no_depth&&!paint_point_visible(v,source,sx,sy,z,ix,iy))continue;
   changed|=dab_pixel(d,before,mask,brush,(size_t)y*s+x,dist,dirty,stencil,sx,sy,alpha,mx,my);
  }
 }return changed;}
int tp_stamp_masked(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*b,float*mask,const TPBrush*brush,double x,double y,TPRect*r,const TPStencil*s,const TPAlpha*a){return stamp_mapped(m,v,d,b,mask,brush,x,y,r,s,a,NULL);}
int tp_stamp_mirror(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*b,float*mask,const TPBrush*brush,double x,double y,TPRect*r,const TPStencil*s,const TPAlpha*a,const TPMirror*mirror){
 int changed=tp_stamp_masked(m,v,d,b,mask,brush,x,y,r,s,a);unsigned axis;
 if(!mirror||mirror->count!=m->count||mirror->mesh_hash!=m->hash||v->uv_mode)return changed;
 for(axis=1;axis<8;axis++)if(mirror->faces[axis])changed|=stamp_mapped(m,v,d,b,mask,brush,x,y,r,s,a,mirror->faces[axis]);
 return changed;
}
#include "mirror.inc"
int tp_stamp_stencil(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*b,float*mask,const TPBrush*brush,double x,double y,TPRect*r,const TPStencil*s){return tp_stamp_masked(m,v,d,b,mask,brush,x,y,r,s,NULL);}
int tp_stamp_region(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*before,float*mask,const TPBrush*brush,double mx,double my,TPRect*dirty){return tp_stamp_stencil(m,v,d,before,mask,brush,mx,my,dirty,NULL);}
int tp_stamp(const TPMesh*m,const TPView*v,TPDoc*d,const TPDoc*before,float*mask,const TPBrush*brush,double mx,double my){return tp_stamp_region(m,v,d,before,mask,brush,mx,my,NULL);}
static int write_bytes(FILE*f,const void*p,size_t n){return n==0||fwrite(p,1,n,f)==n;}
static int u32(FILE*f,uint32_t x){unsigned char b[4]={(unsigned char)x,(unsigned char)(x>>8),(unsigned char)(x>>16),(unsigned char)(x>>24)};return write_bytes(f,b,4);}
static int read32(FILE*f,uint32_t*x){unsigned char b[4];if(fread(b,1,4,f)!=4)return 0;*x=(uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24);return 1;}
int tp_project_write(FILE*f,const TPDoc*d){int l;if(!write_bytes(f,"TPUV0002",8)||!u32(f,(uint32_t)d->size)||!u32(f,(uint32_t)d->mesh_hash)||!u32(f,(uint32_t)(d->mesh_hash>>32))||!u32(f,(uint32_t)d->active)||!write_bytes(f,d->uvname,256)||!u32(f,d->alpha!=0)||!write_bytes(f,d->texture_path,1024))return 0;for(l=0;l<TP_LAYERS;l++){const TPLayer*r=&d->layer[l];if(!write_bytes(f,r->name,64)||!u32(f,(uint32_t)llround(clamp(r->opacity)*1000000))||!u32(f,r->visible!=0)||!write_bytes(f,r->rgba,(size_t)d->size*d->size*4))return 0;}return !ferror(f);}
int tp_project_read(FILE*f,TPDoc*out,uint64_t hash,const char*uv){char magic[8],name[256];uint32_t size,low,high,active,op,visible;int l,v2;TPDoc d={0};if(fread(magic,1,8,f)!=8||(memcmp(magic,"TPUV0001",8)&&memcmp(magic,"TPUV0002",8))||!read32(f,&size)||!read32(f,&low)||!read32(f,&high)||!read32(f,&active)||fread(name,1,256,f)!=256)return 0;if(!valid_size((int)size)||active>=TP_LAYERS||((uint64_t)high<<32|low)!=hash||!memchr(name,0,256)||strcmp(name,uv))return 0;if(!tp_doc_init(&d,(int)size,hash,uv))return 0;d.active=(int)active;v2=!memcmp(magic,"TPUV0002",8);if(v2){uint32_t alpha;if(!read32(f,&alpha)||alpha>1||fread(d.texture_path,1,1024,f)!=1024||!memchr(d.texture_path,0,1024)){tp_doc_free(&d);return 0;}d.alpha=(int)alpha;}for(l=0;l<TP_LAYERS;l++){TPLayer*r=&d.layer[l];if(fread(r->name,1,64,f)!=64||!memchr(r->name,0,64)||!read32(f,&op)||op>1000000||!read32(f,&visible)||visible>1||fread(r->rgba,1,(size_t)size*size*4,f)!=(size_t)size*size*4){tp_doc_free(&d);return 0;}r->opacity=op/1000000.0;r->visible=(int)visible;}if(fgetc(f)!=EOF||ferror(f)){tp_doc_free(&d);return 0;}*out=d;return 1;}
static uint32_t crc(const unsigned char*p,size_t n,uint32_t c){size_t i;int k;for(i=0;i<n;i++){c^=p[i];for(k=0;k<8;k++)c=(c>>1)^((0-(c&1))&0xedb88320);}return c;}
static void be32(unsigned char*b,uint32_t n){b[0]=(unsigned char)(n>>24);b[1]=(unsigned char)(n>>16);b[2]=(unsigned char)(n>>8);b[3]=(unsigned char)n;}
static int png_chunk(FILE*f,const char*tag,const unsigned char*p,size_t n){unsigned char b[4];uint32_t c;if(n>UINT32_MAX)return 0;be32(b,(uint32_t)n);if(!write_bytes(f,b,4)||!write_bytes(f,tag,4)||!write_bytes(f,p,n))return 0;c=crc((const unsigned char*)tag,4,~0u);c=crc(p,n,c);be32(b,~c);return write_bytes(f,b,4);}
/* One stored-deflate block per row: bounded temporary memory, even at 8K.
 * RGB exports composite transparent pixels over white; source layers stay RGBA. */
int tp_png_mode(FILE*f,const unsigned char*rgba,int w,int h,int alpha){
 unsigned char ihdr[13]={0},header[2]={0x78,1},tail[4],*block;
 size_t row,k;uint32_t a=1,b=0;int x,y,c,ok=0,channels=alpha?4:3;
 if(!f||!rgba||w<1||h<1||w>8192||h>8192)return 0;
 row=1+(size_t)w*channels;block=malloc(row+5);if(!block)return 0;
 be32(ihdr,(uint32_t)w);be32(ihdr+4,(uint32_t)h);ihdr[8]=8;ihdr[9]=alpha?6:2;
 if(!write_bytes(f,"\211PNG\r\n\032\n",8)||!png_chunk(f,"IHDR",ihdr,13)||!png_chunk(f,"IDAT",header,2))goto finish;
 for(y=0;y<h;y++){
  block[0]=(unsigned char)(y==h-1);block[1]=(unsigned char)row;block[2]=(unsigned char)(row>>8);
  block[3]=(unsigned char)~row;block[4]=(unsigned char)(~row>>8);block[5]=0;
  for(x=0;x<w;x++){const unsigned char*p=rgba+((size_t)y*w+x)*4;unsigned char*q=block+6+(size_t)x*channels;
   if(alpha)memcpy(q,p,4);else for(c=0;c<3;c++)q[c]=(unsigned char)((p[c]*p[3]+255*(255-p[3])+127)/255);
  }
  for(k=5;k<row+5;k++){a=(a+block[k])%65521;b=(b+a)%65521;}
  if(!png_chunk(f,"IDAT",block,row+5))goto finish;
 }
 be32(tail,(b<<16)|a);ok=png_chunk(f,"IDAT",tail,4)&&png_chunk(f,"IEND",NULL,0)&&!ferror(f);
 finish:free(block);return ok;
}
int tp_png(FILE*f,const unsigned char*rgba,int w,int h){return tp_png_mode(f,rgba,w,h,1);}
