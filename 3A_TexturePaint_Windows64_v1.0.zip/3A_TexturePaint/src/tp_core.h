#ifndef TP_CORE_H
#define TP_CORE_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#define TP_LAYERS 8
enum {TP_MODE_PAINT,TP_MODE_ERASER,TP_MODE_FILL,TP_MODE_INK};
#define TP_MAX_TRIANGLES 2000000
typedef struct { double p[3],uv[2]; } TPVertex;
typedef struct { TPVertex v[3]; unsigned char outline; } TPTriangle;
typedef struct { TPTriangle *tri; size_t count,capacity; double center[3],radius; uint64_t hash; char uvname[256]; } TPMesh;
typedef struct { unsigned char *rgba; char name[64]; double opacity; int visible; } TPLayer;
typedef struct { int size,active,alpha; char texture_path[1024]; TPLayer layer[TP_LAYERS]; uint64_t mesh_hash; char uvname[256]; } TPDoc;
typedef struct { double x,y,z,w; } TPProjected;
typedef struct {double lo[2],hi[2];uint32_t first,count,left,right;} TPSpatialNode;
typedef struct {TPSpatialNode*spatial_nodes;uint32_t*spatial_ids;size_t spatial_count; int w,h,uv_mode,no_depth; uint32_t *bgra,*owner; float *depth; TPProjected *projected; size_t project_count; double yaw,pitch,distance,panx,pany; } TPView;
typedef struct {uint32_t source;unsigned char corner[3];} TPMirrorFace;
typedef struct {TPMirrorFace*faces[8];size_t count,matched[8];uint64_t mesh_hash;unsigned axes;} TPMirror;
void tp_mirror_free(TPMirror*);
int tp_mirror_prepare(TPMirror*,const TPMesh*,unsigned);
typedef struct { int radius,hard,erase; double strength; unsigned char color[3]; } TPBrush;
typedef struct {const unsigned char*gray;int width,height,invert;} TPAlpha;
double tp_alpha_sample(const TPAlpha*,double,double);
void tp_line_endpoint(const double[2],const double[2],int,double[2]);
typedef struct {const unsigned char*rgba;int width,height;double left,top,display_width,display_height,rotation_cos,rotation_sin;} TPStencil;
int tp_stencil_place(const unsigned char*,int,int,int,int,double,double,double,TPStencil*);
void tp_stencil_point(const TPStencil*,double,double,double[2]);
int tp_stencil_sample(const TPStencil*,double,double,double[4]);
typedef struct {int x0,y0,x1,y1,valid;} TPRect;
void tp_rect_add(TPRect*,int,int);
void tp_composite_region(const TPDoc*,unsigned char*,const TPRect*);
int tp_fill_mesh(const TPMesh*,TPDoc*,const TPDoc*,float*,const TPBrush*,TPRect*);
int tp_stamp_mirror(const TPMesh*,const TPView*,TPDoc*,const TPDoc*,float*,const TPBrush*,double,double,TPRect*,const TPStencil*,const TPAlpha*,const TPMirror*);
int tp_stamp_masked(const TPMesh*,const TPView*,TPDoc*,const TPDoc*,float*,const TPBrush*,double,double,TPRect*,const TPStencil*,const TPAlpha*);
int tp_stamp_stencil(const TPMesh*,const TPView*,TPDoc*,const TPDoc*,float*,const TPBrush*,double,double,TPRect*,const TPStencil*);
int tp_stamp_region(const TPMesh*,const TPView*,TPDoc*,const TPDoc*,float*,const TPBrush*,double,double,TPRect*);
int tp_doc_init(TPDoc*,int,uint64_t,const char*);
void tp_doc_free(TPDoc*);
int tp_doc_clone(TPDoc*,const TPDoc*);
void tp_composite(const TPDoc*,unsigned char*);
int tp_mesh_finish(TPMesh*);
int tp_view_resize(TPView*,int,int);
void tp_view_free(TPView*);
int tp_render_projected(TPView*,const TPMesh*,const TPDoc*,const unsigned char*);
int tp_render(TPView*,const TPMesh*,const TPDoc*,const unsigned char*);
int tp_stamp(const TPMesh*,const TPView*,TPDoc*,const TPDoc*,float*,const TPBrush*,double,double);
int tp_png_mode(FILE*,const unsigned char*,int,int,int);
int tp_png(FILE*,const unsigned char*,int,int);
int tp_project_write(FILE*,const TPDoc*);
int tp_project_read(FILE*,TPDoc*,uint64_t,const char*);
#endif
