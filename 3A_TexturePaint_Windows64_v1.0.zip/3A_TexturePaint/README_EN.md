# 3A_Texture Paint — experimental 0.39 English — Symmetry controls and alpha directory placement

Windows x64 texture-painting tool for Modeler viewports, with controls in Numeric (N).

The three live symmetry switches share one fixed row. Mirror X - copies painted pixels from positive X to negative X. Mirror X + copies in the reverse direction. Each action uses the active layer and prepared matching triangles across X=0. Transparent source pixels are skipped. Undo reverses the copy.

New in v0.39. The symmetry cursor uses the original brush size and orange color at half opacity. No Depth paints through the prepared mesh and renders each preview surface at 90% opacity. Show Wireframe offers a custom color picker. Disable Wireframe Color to reveal native sketch lines. Earlier changes in v0.37. The cyan symmetry cursor is displayed at one fifth of the original brush diameter, including its alpha preview and strength ring. Earlier changes in v0.36. Active symmetry axes show cyan brush cursors (#16EBFF) on matched triangles, using the current radius, strength ring and alpha preset. Earlier changes in v0.35. Wireframe, below Viewport Texture Preview, reveals the native viewport pixels along visible polygon edges. Use a viewport mode that shows the native sketch lines and their colours. Requires the isolated OpenGL preview framebuffer. Earlier changes in v0.34:

- Renames the axis controls to **Symmetry X**, **Symmetry Y**, and **Symmetry Z**, with X/Y/Z checkboxes side by side in that order.
- Moves **Alpha Content Directory** below the alpha preset thumbnail gallery.

Earlier changes in v0.31:

- Adds the missing left-alignment hint to Symmetry Z so it participates in the same compact row as Symmetry X and Symmetry Y. The controls remain below Hard Brush and above the divider preceding Alpha Content Directory.
- Windows x64 compilation checked with warnings treated as errors. Actual placement still requires confirmation in Modeler.

Earlier changes in v0.30:

- Places the three independent Symmetry controls directly in the Brush tab, immediately after Hard Brush: Symmetry X, Symmetry Y, Symmetry Z.
- Applies narrow sizing to each control and left-flow hints to X and Y, following the SDK's adjacent-control layout pattern. Removes the nested group that could introduce a divider before Mirror or leave its children vertical.
- Suppresses dividers after Hard Brush, Symmetry X and Symmetry Y; requests the divider after Symmetry Z, before Alpha Content Directory.
- Windows x64 compilation checked with warnings treated as errors. Actual Numeric layout remains to be verified in Modeler 2026; no host runtime is available here.

Earlier changes in v0.29:

- Raises the capture ceiling from 200,000 to 2,000,000 triangles. Available memory still limits practical texture and mesh sizes; this is not unlimited geometry support.
- Adds an optional screen-space spatial index, rebuilt with the projection and reused during normal brush dabs. Only nearby triangle candidates are visited. Mirrored passes still use the existing linear traversal.
- Rejects non-finite or invalid projected triangles before rasterization and painting. If index allocation fails, painting falls back to linear traversal.
- Symmetry X, Symmetry Y and Symmetry Z have full labels, ordered left to right in one native row immediately below Hard Brush. Numeric width can affect host layout.
- Synthetic dense-index tests cover 2,000,000 triangles, complete candidate coverage, coincident centroids and invalid projections. Indexed and linear painting produce identical output in the polygon-edge regression.
- The user's Modeler shutdown has not been reproduced here. These are robustness and scalability improvements, not confirmation that every possible host crash is resolved. Actual dense-mesh painting needs verification in Modeler 2026. If it still closes, retain the diagnostic log and a reproducible .lwo sample.

Earlier changes in v0.28:

- Fixes false occlusion along faceted polygon edges. Previously the screen-pixel owner could be a neighbouring triangle, and its depth was extrapolated outside its actual triangle at the projected texture pixel. This rejected valid paint samples and left dotted or broken unpainted lines.
- Occlusion candidates must now contain the actual projected texel before their depth can block painting. A bounded 5 x 5 screen neighbourhood supplies candidate triangles; duplicate candidates are checked once. The normal same-owner path remains fast. This retains the screen-resolution visibility approximation rather than introducing a full ray tracer.
- Regression reproduction: the previous implementation left **16,001 internal unpainted texels** on a faceted test surface; the corrected implementation leaves **zero**. Orthographic and perspective cases pass. A separate UV island behind the visible surface stays unpainted in the occlusion test.
- The change applies to normal and mirrored Paint/Eraser/Ink strokes. No UI layout or preset changes.
- Existing gaps already stored in an image are not repaired automatically. Undo the affected stroke where possible, or repaint the area. Confirm with a fresh stroke or clean layer in Modeler.

Earlier changes in v0.27:

- Symmetry controls are grouped horizontally below Hard Brush, in X, Y, Z order. Compact labels read **Symmetry X**, **Y**, **Z**. The preset divider follows the whole row.
- Uses native XPanels narrow/left layout hints; final layout is subject to the available Numeric window width.

Earlier changes in v0.26:

- The bundled alpha presets are the **11 files supplied with this update**, preserved byte-for-byte at their original **551 x 551** resolution. Brush 09 was not attached; no replacement or duplicate entry has been invented. Original numbering is retained.
- Thumbnail decoding and its cache now use **551 x 551 pixels** instead of 256 x 256. Small / Medium / Large still control the displayed tile size inside Numeric, not the source resolution.
- The bounded 64-entry grayscale cache now uses at most **18.53 MiB** of pixel data (approximately 3.18 MiB for these 11 previews). Only visible entries are loaded, and cached entries are reused while browsing.
- The painting mask remains 512 x 512; this request changes preview resolution and bundled preset assets. Painting, Symmetry and gallery event handling are otherwise retained from v0.25.
- Install the complete folder, including **presets**, with Modeler closed. If **Alpha Content Directory** still points to an older installation or a custom folder, select the new package's presets folder to load this set.

Earlier changes in v0.25:

- **Symmetry X**, **Symmetry Y** and **Symmetry Z** are directly below **Hard Brush**. Enable any combination; X+Y+Z can paint the original plus seven reflected copies. All are off when the tool is activated.

- Mirror uses object-space planes **X=0**, **Y=0**, **Z=0**, not the current view, bounding-box centre, or UV centre. Centre the symmetric model on the origin before preparing it.

- This first Symmetry implementation matches reflected **triangles and vertex positions** (including reordered vertices and different winding). Geometry **and triangulation must have a symmetric counterpart**. Separate UV islands are supported; the UV layout itself does not need to be symmetric. Faces without a matching reflected triangle are skipped and reported in Modeler's tool help. Arbitrary asymmetric surfaces and opposite quad triangulations are not automatically retopologized or projected to the nearest face.

- Symmetry works with Paint, Eraser, brush alpha, Ink / Stamp and interactive straight strokes in native 3D and UV viewports. It reflects the visible source stroke into the counterpart's UVs, including a counterpart hidden from the current view. Fill already covers every UV-mapped face and needs no duplication.

- Original and reflected pixels use the same stroke strength/coverage and a **single Undo step**. Overlap does not repeatedly increase strength. The geometry correspondence cache is rebuilt when the mesh or axes change; enabling more axes increases painting work. Mirror choices are tool settings, not saved in the .tpaint file.

- **Viewport Texture Preview** and **Fast Preview** now follow **Undo Levels** at the bottom of Brush.

- The gallery now has a bound integer redraw value, a direct XPanels mouse callback, click-only zoom notification, and a thread-local mouse click fallback. Selection is queued outside drawing callbacks; a newer selection replaces a pending gallery selection or scroll.

- Wheel input now also uses the UI thread's removed-message path (**WH_GETMESSAGE**) when the previous **WH_MOUSE** route does not deliver it. Consumed messages are cleared, peeked messages are ignored, and input outside the identified gallery is passed through. The sidebar can also be dragged through the mouse route.

- These are source-level corrections based on the reported failures. **Actual selection, wheel delivery, DPI scaling and Numeric layout still require verification inside Modeler 2026.** The existing Preset dropdown remains available for direct selection.

Retained changes from v0.24:

- **Undo Levels (match Modeler)** follows Ink / Stamp and a horizontal divider; the preview options now follow Undo Levels. It remains available in every painting mode.

- Thumbnail previews use **551 x 551**, with bilinear display scaling, one-pixel rows and merged equal-colour runs instead of 2-pixel blocks. The 64-entry cache uses at most 18.53 MiB of grayscale pixels. Painting alpha resolution remains 512 x 512.

- Gallery selection, resizing, directory rescans and scrolling now have a private UI-thread message dispatcher. They no longer rely solely on Modeler's mesh-tool test callback. It does not open a visible window, capture the mouse, or create another event loop; it is destroyed when the last tool closes. Numeric callbacks still defer decoding and refresh to avoid reentrancy.

- Clicking a thumbnail can supersede a pending gallery scroll instead of silently dropping the selection. Resizing updates hit-test geometry immediately and reloads previews outside the draw callback.

- **Mouse wheel over Alpha Presets** scrolls up/down without a modifier key. A left-click in the gallery no longer clears its wheel target: selecting an image then scrolling works without requiring another pointer movement. The right scrollbar remains available.

- **Create Texture Image** is directly below **New Image Resolution**. **New Image with Alpha** is above the resolution selector, so it can be set before creation.

- The Texture divider previously above Save Timing is now directly above **Auto-save Texture Image**. All saving and project functions are retained.

Retained layout changes from v0.23:

- Numeric now has three tabs: **Brush**, **Texture**, **Layers**.

- Brush no longer shows Status, the Presets count/help field, Brush Alpha info, Palette or Refresh Presets. The alpha gallery, direct Preset selector, Colour picker, thumbnail sizes, directory picker below the gallery, import/remove alpha and inversion remain available. To rescan a folder after changing its files, select the directory again with **Alpha Content Directory**.

- Brush order: Prepare, Colour, Mode, **Radius in Pixels**, **Stroke Strength**, **Hard Brush**, Symmetry X/Y/Z; a horizontal divider; alpha preset controls; a second horizontal divider; all Ink / Stamp controls; a final divider, Undo Levels and both preview options.

- Ink controls are disabled unless **Mode = Ink / Stamp**. Choose that mode first, then import/select a stamp or adjust its controls at the bottom of Brush. Inactive Ink actions are also rejected by the callbacks. Switching modes preserves the loaded stamp and its settings.

- Texture no longer shows Status or Linked PNG. Image destinations remain stored internally, and Save Texture Now keeps using the linked texture. Resolution choices read **1024x1024**, **2048x2048**, **4096x4096**, **8192x8192**.

- The Files tab is removed. Project / Autosave, Save Timing, Save Project, Project to Open and Open Selected Project are preserved at the bottom of Texture. Image to Import / Import into Active Layer move to Layers. Project safety saves and manual/automatic PNG saves keep their existing behaviour.

- Status text remains available through Modeler's tool help/status line; the removed Numeric fields do not disable diagnostics or error reporting.

Features retained from v0.22:

- Move the pointer over **Alpha Presets** and turn the mouse wheel: wheel down browses lower rows; wheel up browses higher rows. Small/high-resolution wheel deltas accumulate, rapid events share a pending scroll update, and the position is clamped at the beginning/end. The existing right scrollbar remains available.

- Wheel handling is scoped to the gallery identified by the native XPanels move callback. Events outside that rectangle, over another window, or during painting/adjustments are passed through. The thread-local Windows hook is removed when the final tool instance closes or the plugin shuts down. No global mouse hook or replacement window is used. Actual hover coordinates/DPI and host refresh timing still require Modeler testing.

- The selected thumbnail now has a **one-pixel orange outline**, reduced from three pixels.

- Up to **64 grayscale thumbnails at 551 x 551** are cached (about 18.53 MiB of thumbnail pixels). Moving within or revisiting cached rows does not reopen/decode their source files. Least-recently-used entries outside the visible rows are reused when browsing larger folders. Selecting the content directory again invalidates the cache so edited files can be reloaded.

- Gallery backgrounds, borders and the scrollbar use filled rectangles. Thumbnail drawing uses one-pixel rows with equal-colour horizontal runs combined into single drawing calls; the actual brush alpha remains **512 x 512**, and source images are unchanged. Initial visits to uncached files still require decoding; no measured Modeler frame-rate claim is made.

Features retained from v0.21:

- The embedded Numeric alpha gallery requests the full available panel width and the larger XPanels thumbnail height. Miniatures are doubled relative to the previous wide-aspect gallery; the number of columns adapts to the available width. Very narrow panels constrain a thumbnail to fit. Small / Medium / Large remain available.

- A vertical scrollbar is drawn on the gallery's right edge. Click the track or drag it up/down to reach earlier/later rows. The XPanels drag endpoint controls the scroll position; exact drag feedback timing is managed by the host and must be checked in Modeler. Thumbnails are loaded outside drawing callbacks. Empty folders and short lists have no scrolling range.

- Previous Presets and Next Presets are removed. Scrolling preserves the active brush alpha. The Preset dropdown remains available for direct selection.

- The hollow orange Ink rotation circle is now centred on the **right** edge. Its hit target and border gap move with it, including when the stencil is rotated. The scale square stays at the top and the move cross stays in the centre.

- The 11 supplied Brush images remain the only bundled presets. Undo/Redo buttons remain removed; use your configured Modeler shortcuts.

Features retained:

- **Brush > Alpha Presets** is now an embedded thumbnail gallery in the Modeler Numeric panel (N). No floating preset window. Use the right scrollbar to browse, then click a thumbnail, or select directly from the **Preset** list. The selected entry has an orange border.

- **Alpha Content Directory** chooses the folder containing PNG, JPEG and BMP presets. Its browse button selects a directory; select the directory again to rescan it after files are added. The folder is remembered between Modeler sessions. The initial folder is `presets` beside the plugin. Scanning is non-recursive, supports up to 4096 entries, and loads only the visible thumbnail rows.

- The brush cursor displays the selected alpha in translucent orange, with a softly feathered circular edge. The guide follows the same screen-space footprint used for painting and does not alter the selected paint colour. Its display mask is cached to avoid recomputing it on every mouse move. Fill retains its small orange dot.

- **Remove Brush Alpha** removes the cursor texture and restores the normal brush. **Import Brush Alpha...** selects an image directly; to add permanent presets, place images in the configured folder and refresh it.

- White permits painting, black blocks it, and grey attenuates Stroke Strength. Source transparency also reduces influence. **Invert Alpha** reverses the mask and updates the cursor. The mask affects Paint, Eraser and Ink / Stamp; Fill remains a whole-mesh colour fill.

- Alphas use an aspect-preserving 512 x 512 working mask with black margins for non-square sources. Original preset files remain unchanged. Alpha selection survives tool reactivation but is not stored in `.tpaint` projects or restored after restarting Modeler; the content directory is persisted separately.

- **Shift + LMB drag paints interactively**, starting with the press and updating the texture while the pointer moves. Directions snap every 45 degrees while Shift is held, including 90 and 180 degrees. The previous line is restored from the stroke snapshot before drawing the new position, so turning or shortening the line leaves no fan-shaped trail and does not repeatedly accumulate strength. Release LMB to finish one Undo operation and use the normal save policy.

- Hold Shift before pressing LMB. Releasing Shift during the drag allows a free-angle straight line. The line stays in its starting viewport. Alt/Ctrl, tool Reset, Drop or Deactivate cancel the in-progress line and restore the prior pixels. Fill and Ink transform handles keep their separate behaviour. Large lines on high-resolution textures still cost more than short strokes; there is no fixed frame-rate guarantee.

- **Ink / Stamp > Image Editor Images**, directly below **Import Stamp Image...**, now lists every enumerated Image Editor entry, including images without a source filename. Selecting one reads its pixels through LightWave, so it is not limited to the PNG/JPEG/BMP file importer. The list refreshes periodically while the tool is idle, and **Refresh Image List** refreshes it explicitly. Deleted images are checked before access.

- Image Editor selections are copied into the existing 8-bit RGBA stamp, proportionally capped at 2048 pixels per side. HDR values outside 0–1 are clamped. This is a snapshot of pixels exposed by the host, not an animated/live link; select again after changing image content. Entries without readable pixels report an error and preserve the previous stamp.

Existing features:

- Plugin name: **3A_Texture Paint**; mode order: **Paint, Eraser, Fill, Ink / Stamp**.

- Ink rotation: hollow orange circle centred on the **right** edge. Ink scale: hollow orange square centred on the **top** edge. Both interiors are unfilled.

- Centre move cross doubled from 14 to 28 logical pixels across.

- Fill cursor is a small orange dot, without radius/strength rings.

- Multi-step painting Undo/Redo uses the host Undo/Redo callbacks while this tool is active. Set **Brush > Undo Levels (match Modeler)** to the same value as Modeler's Undo Levels; default is 32. **Automatic synchronisation with the host preference is not available in this build.** The inspected SDK exposes Undo/Redo callbacks but no getter for that preference.

- History retains changed pixel blocks and layer metadata in temporary disk files, deleted when the painting session is replaced or Modeler exits. It persists across tool reactivation in the same session, but is not saved in .tpaint projects. A new edit after Undo discards the Redo branch. Large fills/imports can require substantial temporary disk space. If history recording fails, the latest operation is cancelled and Status reports the failure.

Fill and Ink features:

- **Brush > Mode > Fill:** select a colour and Stroke Strength, then click once in a painting viewport to fill every UV-mapped face of the prepared mesh on the active layer. Hidden/back faces are included. UV overlaps receive the colour once per click. Unused image space is left unchanged. This fills the whole mesh, not a colour-connected region or only selected polygons.

- Fill uses normal alpha blending: 50% strength adds half-opacity colour over the active layer; 100% makes covered texels opaque. Other layers and their opacity remain unchanged. Radius and Hard Brush do not affect Fill. Zero strength changes nothing.

- Hold/drag does not repeat Fill. A new click applies another fill. Painting Undo/Redo and the current PNG auto-save setting apply.

- **Centre cross:** drag with LMB to move the Ink image horizontally and vertically. Movement does not paint and preserves scale/rotation.

- Scale and rotation handles sit directly on the midpoints of the top and right image edges.

Existing Ink and brush controls:

- **Orange square at the midpoint of the top edge:** hold LMB and drag away from/toward the image centre to scale proportionally (5–400%).

- **Orange circle at the midpoint of the right edge:** hold LMB and drag around the centre to rotate. The guide, border and projected painting rotate together.

- **Thin orange border:** outlines the image, including transparent areas. Border and handles remain visible at 0% Display Opacity; Show Stamp Display hides all of them.

- **Inner brush circle:** an orange ring indicates Stroke Strength with the same thin line as the outer radius ring. Its radius is the outer radius multiplied by strength. At 100%, only the outer ring is drawn; below 100%, the inner ring appears and shrinks proportionally. At zero strength it collapses to zero radius. It indicates strength, not hardness.

- Brush radius/strength adjustment remains anchored as in v0.13. Ink handle drags do not paint, create Undo snapshots, or save textures. The brush circles are hidden during an Ink handle drag.

The Ink / Stamp section at the bottom of Brush loads and positions a semitransparent image stencil over the viewport.

- Import a PNG, JPEG or BMP using **Import Stamp Image...**. Loading selects Ink / Stamp automatically and does not replace the texture or its layers.

- Hold LMB and brush across the stencil display to transfer the image colours and alpha onto the visible mesh, on the active layer. Hover alone only moves the cursor.

- The display stays fixed relative to the viewport while the brush moves. Its preview and painting use the same screen-to-image mapping, including native UV view.

- Position, proportional scale, rotation and display opacity are available in Numeric; position, scale and rotation also have viewport handles. Display opacity does not change paint strength.

- Stamps retain their aspect ratio. Sources larger than 2048 pixels on either side are proportionally reduced to fit a 2048-pixel maximum side. This limit affects the stamp asset, not the working texture resolution.

- Paint, Eraser, brush shortcuts, texture import, layered Undo, regional updates and manual/automatic PNG saves remain available.

**The binary has been compiled, but has not been run inside LightWave 2026 in this environment.** Actual Numeric layout, mouse/navigation events, UV capture, OpenGL overlay, Windows file operations and Image Editor updates still require host testing. The build uses the SDK 2025 headers distributed through the LightWave 2026 documentation. The SDK is not included.

## Install or update

1. Save your work and close Modeler before replacing the previous `.p` file. Copy the complete folder, including presets. Keep a copy of your previous version if you need to roll back.
2. Extract this ZIP to a permanent folder. Replace the existing plugin or remove its old registration before adding this build: this version registers the new server name `3A_TexturePaint`. Remove the old TexturePaintNative2026 registration and menu entry to avoid loading both versions.
3. In Modeler, use Utilities > Plugins > Add Plugins to load `3A_TexturePaint.p`. Add 3A_Texture Paint to your menu through Edit Menu Layout if needed.
4. For an initial test, open `example/Cubo_UV.lwo`, keep only that layer in the foreground, and select **PaintUV** using Modeler's **T** UV-map selector. Example filenames are unchanged.

## Ink / Stamp: paint through an image

1. Prepare the mesh and its UV map. Create, import or open the texture project you want to paint on.
2. Choose the target layer. An empty layer above the base is useful when you want to erase the newly stamped paint without erasing the base image.
3. Select **Brush > Mode > Ink / Stamp**, then use **Import Stamp Image...** at the bottom of Brush and choose a PNG, JPEG or BMP.
4. Move the pointer over a viewport. The stencil appears there at 45% display opacity. Position the mesh underneath it with normal Modeler navigation between strokes, or adjust the stencil controls below.
5. Hold **LMB** and brush across the displayed image. Only the brush footprint transfers; the whole image is not applied by a single click. Pixels outside the displayed image, transparent source pixels and hidden back surfaces are not painted.
6. Release LMB, inspect the result, and save using your existing manual/automatic setting. Disable Show Stamp Display to inspect the painted result without the guide, or switch Mode back to Paint/Eraser.

| Ink / Stamp control | Behaviour |
|---|---|
| Import Stamp Image... | Load the stencil asset; does not replace the texture, edit layers or save the source image. |
| Stamp Image | Loaded working dimensions and whether the asset was reduced. |
| Show Stamp Display | Show/hide the guide. Hiding it does not disable Ink painting. |
| Display Opacity | Guide opacity, 0–100%; default 45%. Does not affect transferred paint. |
| Stamp Center X / Y | Position (also adjusted using the centre cross) as a percentage of viewport width/height, measured from the top-left corner. 50% / 50% is centred. |
| Stamp Scale | Proportional size, 5–400%. At 100%, the image fits within half the viewport width and half its height. |
| Stamp Rotation (degrees) | Clockwise screen-space rotation; editable in Numeric or with the right circle. |
| Center / Fit Stamp | Reset centre to 50% / 50%, scale to 100% and rotation to zero. |

Drag handles with LMB, then release before painting. Each handle follows the image rotation. The centre cross moves in screen X/Y even when the image is rotated. A drag remains attached to its starting viewport; movement outside that viewport pauses the adjustment. If a handle is offscreen, use Numeric controls or Center / Fit Stamp. A Modeler tool-reset event cancels the current adjustment.

**Stroke Strength**, radius and Hard Brush still control application. The palette colour is ignored in Ink mode: source-image RGB supplies the paint colour and source alpha multiplies brush coverage. Transparent PNGs work as cutouts. JPEG/BMP stamps normally have an opaque rectangular background, which will be transferred wherever you brush.

This is a screen-space stencil, not a stamp attached permanently to a 3D surface. Changing view angle changes where the stencil projects. The guide follows the hovered viewport, keeping its normalized centre and scale. Paint across view boundaries starts a new segment without a connecting stroke, as before.

The stamp is retained in memory during the Modeler session, independently of texture projects. Its image/placement are not embedded in `.tpaint` files. Reload the stamp after restarting Modeler; painted pixels are saved normally in the project and exported PNG. On tool reactivation, the mode and placement controls reset to their defaults; select Ink / Stamp again to use the retained asset.

## Create a texture and paint

1. Activate 3A_Texture Paint, press **N**, and click **Brush > Prepare / Update UV Mesh**.
2. Open the **Texture** tab. Set **Destination PNG Image** to a full filename in an existing folder, for example `D:\Project\Images\Paint.png`.
3. Choose **New Image Resolution**: 1K = 1024 × 1024, 2K = 2048 × 2048, 4K = 4096 × 4096, or 8K = 8192 × 8192.
4. Enable or disable **New Image with Alpha**.
5. Click **Create Texture Image**. This starts blank layers and clears Undo. It asks for confirmation, saves the previous project first, and asks before replacing an existing PNG. It does not resize existing painting.
6. The PNG is saved at the selected destination and the plugin requests its loading into the Image Editor. The linked path is retained internally. **Current Texture** shows the active resolution and PNG format.
7. Assign that image to the object's material with UV projection and the same prepared UV map. The plugin does not create or edit materials or nodes automatically. Configure the material's alpha connection separately if you want transparency.
8. Paint directly on the mesh with the left mouse button. By default, releasing each stroke saves the layered project. With Auto-save Texture Image enabled, it also updates the linked PNG and requests an in-place Image List replacement in LightWave. The existing image ID is preserved when the image is found by filename.
9. Navigate using Modeler's controls between strokes and continue painting. **Save Texture Now** retries image saving/reloading. If the Modeler tool help/status line reports a reload failure, the PNG may already be saved: reload it in the Image Editor.

Changing the creation path, resolution or alpha fields does not change the active texture. Those settings apply when you click Create Texture Image. New Image Resolution also supplies the target size when an import requires resizing; that resize is confirmed separately. Export PNG writes a copy to the destination field without changing the linked path. To resume a project, use Open Selected Project rather than Create.

## Import an existing image and continue painting

1. Open your mesh, select the UV map used by the image, activate the tool, press **N**, then **Prepare / Update UV Mesh**.
2. In **Texture**, click **Import Texture Image...** and select a PNG, JPEG or BMP. The button is disabled until a mesh is prepared.
3. Confirm starting a new layered project. If the dimensions need conversion, the plugin first shows the input and target sizes and asks whether to resize.
4. Paint directly in the viewport. **Paint** is the active empty layer above **Imported Image**. Erasing on Paint reveals the imported base; select Imported Image in Layers if you intend to edit or erase those pixels directly.
5. The imported image uses a separate working-copy destination retained internally. With Auto-save Texture Image ON, the working copy is written on import and then updated at the normal save points. With it OFF, the PNG is not created until **Save Texture Now**; the layered project is still saved.
6. If you want the material to display subsequent edits outside the tool overlay, assign the working-copy PNG to the material using the same UV map. The source material/image is not automatically relinked. Export PNG can save another copy at Destination PNG Image.

Import starts a new project and clears the previous painting Undo history. The previous layered project is saved before switching; the import operation does not write its linked PNG, even if that is the selected source image. Cancelled or failed decoding keeps the current painting in memory. A disk failure may leave a newly written working-project file, while the active painting remains unchanged.

For a `.tpaint` file created by this plugin, use **Texture > Open Selected Project** instead: this restores the original layers. An imported PNG/JPEG/BMP contains flattened pixels and cannot restore its former layers.

## Alpha and erasing

- **With alpha:** 8-bit RGBA PNG, initially transparent. Painting adds coverage. Erasing removes paint from the active layer, revealing lower layers or transparency.

- **Without alpha:** 8-bit RGB PNG with no alpha channel, initially white. The layer composite is flattened over white when saved. Erasing reveals lower layers or white where all layers are empty.

- Working layers remain RGBA in both modes so that layer compositing and erasing work normally. The alpha option controls the output texture.

- The tool's overlay previews transparent areas over white. It does not reproduce PBR lighting or material transparency.

## Numeric controls

| Tab | Controls |
|---|---|
| Brush | Prepare, Colour, Mode, Radius, Strength, Hard Brush, preview and Undo settings; alpha preset gallery and options; Ink / Stamp controls (enabled only in Ink mode). |
| Texture | Texture import/create/export, destination PNG, numeric resolutions, alpha, Current Texture, auto-save and Save Texture Now; project paths, Save Timing, Save Project and Open Selected Project. |
| Layers | Eight layers, names, visibility, opacity, ordering, Clear Layer; image import into the active layer. |

Controls remain in Numeric while this tool is active. Selecting another tool changes Numeric normally. There is no separate painting window, custom navigation camera or replacement scene drawing: the preview uses drawOverlay in Modeler viewports.

Unmodified left-click applies the selected Paint, Eraser or Ink / Stamp mode. RMB drag adjusts radius; Shift + RMB drag adjusts strength. Shift + LMB drag paints a straight line interactively and finishes it on release. Alt/Ctrl combinations remain available to the host. Shift + LMB is reserved for straight-line painting in this tool. Interleave navigation and brush strokes; navigation belongs to Modeler and your shortcut configuration. Orthographic, Perspective and native UV views are supported. Move to another view and paint there; crossing a viewport boundary during a held stroke starts a new segment without a connecting line. Hovering alone moves the cursor and does not apply paint. Painting Undo/Redo uses the configured Undo Levels. Pen pressure is not supported. The brush radius ranges from 1 to 180 viewport pixels; Stroke Strength limits coverage within one stroke.

## Save and resume

Preparing a new mesh starts a 1024-square working session. Create Texture Image then starts the selected resolution and saves a new `.tpaint` project under `Documents\LightWaveTexturePaint`. Its exact path appears under Texture and can be changed. The PNG is saved in the folder you selected, independently of the project folder.

The project stores all eight layers, names, opacity, visibility, resolution, alpha mode, absolute linked PNG path and a geometry/UV signature. Layered project safety saves run at the end of strokes, after layer changes and when the tool is deactivated. Linked PNG writes at these points require Auto-save Texture Image to be enabled. The optional timing mode below defers some stroke-end saves. Each file is written through a temporary file before replacement; project and PNG saves are separate operations, not one combined transaction. Check the Modeler tool help/status line if saving fails, and resolve unsaved changes before closing.

To resume after restarting: open the same LWO, prepare the same mesh/UV, select the `.tpaint` file in Project to Open, and click Open Selected Project. Its saved PNG path becomes the destination for subsequent painting. Also save the LWO: the project does not contain geometry. If you move the PNG, restore its original path before resuming autosave; Export PNG does not relink the destination.

Version 0.4 and 0.5 projects remain compatible. Version 0.3 projects load as RGBA without a linked PNG; they can be painted and exported manually. Projects saved by v0.4/v0.5 use TPUV0002, which v0.3 cannot read. Preserve original projects if you need to return to v0.3.

The separate **Layers > Import into Active Layer** command replaces only the active layer and resizes the source to the existing project resolution; this supports Undo. It differs from the new Texture import workflow, which starts a new layered project. Project to Open is separate from the autosave destination. Geometry, polygon order, positions or UV edits may invalidate the project's mesh signature.

## Resources and limitations

| Resolution | Approximate layered project size | Approximate RGBA PNG size |
|---|---:|---:|
| 1K | 32 MiB | 4 MiB |
| 2K | 128 MiB | 16 MiB |
| 4K | 512 MiB | 64 MiB |
| 8K | 2 GiB | 256 MiB |

This version writes effectively uncompressed data. RGB PNGs use roughly three quarters of the RGBA size. At 8K, layers, Undo and image buffers use approximately **4.7 GiB**, in addition to Modeler, geometry and GPU resources. Creating or opening another large project temporarily increases memory use. The Undo snapshot is reused on subsequent strokes.

Creation and autosave remain synchronous and can pause at 4K/8K. Brush compositing updates a bounding rectangle; widely separated UV islands can make that rectangle large. OpenGL still uploads the complete preview per overlay draw, but Fast Preview caps it at 1K. The isolated overlay additionally allocates temporary colour/depth buffers at the current viewport backing resolution; these are released after each draw, avoiding shared GPU handles across host contexts. The first Undo snapshot remains expensive. PNG writing uses a bounded row buffer rather than another full-image copy.

Other limits: complete UVs within 0–1; no UDIM; primary layer only; up to 2,000,000 triangles; convex polygons (triangulate concave polygons first). SubD uses the control cage and may not match the smoothed surface. Isolate the layer being painted because other layers do not participate in the painting engine's occlusion. Viewports are limited to 4096 pixels per side; this is independent of the 8K texture resolution. Triangles crossing clipping planes may not receive paint. No advanced colour management.

The overlay requires compatibility OpenGL and GPU support for the texture size. The isolated drawing path uses core framebuffer-object functions (OpenGL 3.0 or equivalent support). If these are unavailable or the framebuffer is incomplete, the older depth-tested preview is used; the viewport-visibility correction then cannot be guaranteed. The orange screen-space cursor remains available. It disappears when the tool is deactivated; permanent display depends on assigning the image to the material and selecting an appropriate viewport mode. Actual display behaviour and material refresh after Image List replacement remain unverified in the host.

## Performance settings

In **Brush**, leave **Fast Preview (max 1K)** enabled for smoother painting. The viewport shows a reduced image; fine details can be less visible. Disable it to inspect full-resolution detail. This does not resize the working layers or exported texture, and does not reduce the allocated Undo memory.

In **Texture > Save Timing**, the default is **Every stroke**. To reduce frequent disk pauses, select **At stroke end - 30s minimum**. This saves at a stroke end once at least 30 seconds have elapsed since the previous save. It is not a background timer: stopping painting before the interval expires can leave changes in memory until a later stroke ends, you press **Save Project**, or the tool deactivates. When image auto-save is enabled, linked PNG and material image refresh are also delayed; the tool overlay updates immediately. Layer changes still save immediately. Fast Preview and Save Timing reset on tool activation. The image auto-save checkbox instead persists until Modeler is restarted.

## Image saving: automatic or manual

The checkbox is in the **Texture** tab of Numeric:

- **ON:** update the linked PNG at normal save points, subject to Save Timing.

- **OFF:** continue painting with immediate viewport feedback, but leave the PNG on disk and its Image Editor/material version unchanged. Use **Save Texture Now** to write and reload the image when ready.

With the checkbox OFF, layer changes, Save Project, tool deactivation, opening another project and plugin shutdown do not automatically write the PNG. The layered `.tpaint` project still receives safety saves, so disabling image auto-save does not remove all disk activity. Save Project and Save Texture Now are separate operations.

**Create Texture Image** still writes the initial blank image because creation is an explicit request. **Export PNG** still writes an explicit copy. Opening a layered project can restore painting newer than its linked PNG; use Save Texture Now to synchronize it. Re-enabling auto-save does not perform disk I/O inside the checkbox callback: pending image changes are written at the next save point, or immediately through Save Texture Now.

## Brush shortcuts

| Gesture in a viewport | Action |
|---|---|
| LMB + drag | Apply Paint, Eraser or Ink / Stamp, according to Mode. |
| Shift + LMB + drag | Paint an interactive straight line; Shift snaps to 45-degree increments. |
| RMB + horizontal drag | Adjust Radius in Pixels: 0.5 brush pixels per mouse pixel, clamped to 1–180. |
| Shift + RMB + horizontal drag | Adjust Stroke Strength: 0.5 percentage points per mouse pixel, clamped to 0–100%. |

Hold Shift before pressing RMB to choose strength. The adjustment mode stays fixed until release, even if Shift is released first. Drag right to increase and left to decrease. Release RMB to keep the value. A Modeler tool Reset event cancels the current adjustment and restores its starting values. Normal navigation remains with Modeler; Alt/Ctrl-modified presses are not captured for these adjustments.

## Validation

For v0.29: dense rendering/painting at 2,000,000 triangles, index coverage, duplicate centroids, invalid projections and indexed/linear equivalence passed with AddressSanitizer/UndefinedBehaviorSanitizer. Windows x64 warnings-as-errors compilation; polygon-edge and hidden-surface tests with AddressSanitizer/UndefinedBehaviorSanitizer; Symmetry/Undo and native stroke regressions passed. No LightWave host runtime was available.

For v0.27: Windows x64 warnings-as-errors compilation and horizontal group/order inspection passed; actual layout needs Modeler confirmation.

For v0.26: Windows x64 warnings-as-errors compilation; supplied-asset count/dimension/byte-preservation checks; 551px gallery sampling, cache, resizing and selection tests passed. The remaining checks were performed for v0.25: all eight Symmetry axis combinations, UV island mapping, reordered vertices, hidden counterparts, strength limits, cache invalidation, unmatched faces and grouped Undo/Redo; direct gallery mouse and message-loop wheel fallback tests; Paint/Eraser/Ink/Fill/straight-line and native history regressions; production gallery/cache/hit-test and wheel tests; a dispatcher test with no Modeler test()/idle callback (including stale instances, busy/reentrancy guards and cleanup); Numeric callback/Ink gating and PNG save-policy regressions; and layout order/divider checks passed. Tests use a mocked host. Actual wheel delivery, DPI scaling, responsiveness and Numeric layout still need confirmation in Modeler 2026.

- Windows x64 compilation with warnings treated as errors, plus PE architecture/export checks.

- Native stroke callbacks: interactive line movement, replacement of old line pixels, shrinking/reversing, alpha strength without accumulation, cancellation, Paint/Eraser/Ink/Fill routing.

- Viewport event tests: immediate stroke request, live updates, angle snapping, viewport lock, release/cancellation, existing navigation and anchored radius/strength adjustments.

- Numeric gallery tests with mocked host/file/codec services: doubled dimensions, scrolling to both ends at each size, selection after scrolling, empty directories and failed decoding preserving the alpha.

- Image Editor tests with mocked host services: filename-less images, host pixel and alpha access, format independence, stable selection and deleted-image handling.

- Actual Mesa/llvmpipe OpenGL rendering: translucent orange alpha footprint, soft edge, inversion, removal and Fill exclusion; existing viewport, stencil, cursor and host-state restoration checks.

- v0.22: Windows compilation; wheel routing/directions, partial deltas, coalescing, boundary handling, window/viewport isolation and cleanup with a mocked Windows host; cache-hit and 130-image eviction tests; reduced drawing-call checks; one-pixel border checks; Numeric reentrancy and PNG save-policy regressions passed. Remaining checks describe retained implementation from earlier versions.

Tests run outside LightWave. The Windows codecs, actual Numeric layout, directory picker, device scaling, Image Editor pixel access and viewport interaction still need verification in Modeler 2026. Numeric identifies **v0.34**. Test on a small UV mesh first, then check your normal texture resolution.

Diagnostics remain opt-in: set **TPN_DIAGNOSTICS=1** before launching Modeler to append to `%TEMP%\TexturePaintNative2026_diagnostic.log`. Remove the variable and restart to disable logging.

## Source and build

Sources are in `src/`, portable tests in `tests/`, and examples in `example/`. From a recent Visual Studio x64 Native Tools Command Prompt, run:

```bat
build_windows.bat "C:\path\LightWaveSDK"
```

The included binary was built with MinGW-w64; the Visual Studio build recipe has not been executed here. To run portable engine tests (`test_core`, `test_projected`, `test_regions`, `test_texture`, `test_stencil`), compile each with `src/tp_core.c`, C11 and `-lm`. Run the Python harnesses with Python 3 and GCC; `test_native_viewports.py`, `test_import_texture.py` and `test_stamp_import.py` additionally need `LWSDK_INCLUDE` set to the SDK include directory. `test_overlay_gl.c` is a separate Linux graphics harness: compile together with `src/tp_core.c`, the SDK/OpenGL include directories, libGL, libEGL and `-lm`, then run with `EGL_PLATFORM=surfaceless`. It includes the production overlay directly and requires a compatibility OpenGL context. SDK and system headers are not distributed in this package. `test_texture` takes an existing output folder and optionally a reference v0.3 project. It creates large files; allow room for temporary output.

Reference: [LightWave 2026 SDK](https://docs.lightwave3d.com/2026/software-development-kit-sdk.html), and the SDK documentation for MeshEditTool, XPanels, Viewport Info and Image List. Original code is MIT licensed. This plugin is not affiliated with or certified by LightWave Digital.


During RMB or Shift + RMB adjustment, the orange brush circle stays anchored at the initial position and viewport. Only radius or strength changes. Normal cursor tracking resumes with the next pointer event after release.

History tests: test_history.c and test_native_history.py cover consecutive Undo/Redo, retention limits, redo branches, layer metadata and host shortcut deferral. Compile test_history.c with both src/tp_history.c and src/tp_core.c. test_project_images.c exercises popup selection and removal safety.

