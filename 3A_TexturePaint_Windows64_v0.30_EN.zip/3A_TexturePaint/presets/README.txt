Bundled alpha presets — v0.26

These 11 user-supplied images are preserved unchanged at 551 x 551 pixels.
Brush 09 was not supplied. Numbering is retained.
Preview cache: 551 x 551. Small / Medium / Large changes display size.
White paints, black blocks; use Invert Alpha to reverse influence.
Select this folder in Alpha Content Directory if an older location is remembered.
User-supplied image assets are not covered by the source-code MIT licence.
