#ifndef TP_HISTORY_H
#define TP_HISTORY_H
#include "tp_core.h"
typedef struct {FILE**entry;int count,cursor,capacity;} TPHistory;
void tp_history_free(TPHistory*);
void tp_history_limit(TPHistory*,int);
int tp_history_commit(TPHistory*,const TPDoc*,const TPDoc*,unsigned,int);
int tp_history_step(TPHistory*,TPDoc*,int);
#endif
