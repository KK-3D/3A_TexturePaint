#include "tp_history.h"
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#include <io.h>
#include <fcntl.h>
#endif
/* Session-only sparse byte patches. Disk-backed history avoids duplicating
   eight full-resolution layers for every brush stroke. Files delete on close. */
static FILE*history_file(void){
#ifdef _WIN32
 wchar_t folder[MAX_PATH],path[MAX_PATH];HANDLE h;int fd;FILE*f;
 DWORD n=GetTempPathW(MAX_PATH,folder);if(!n||n>=MAX_PATH||!GetTempFileNameW(folder,L"3au",0,path))return NULL;
 h=CreateFileW(path,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_DELETE_ON_CLOSE,NULL);
 if(h==INVALID_HANDLE_VALUE){DeleteFileW(path);return NULL;}
 fd=_open_osfhandle((intptr_t)h,_O_BINARY|_O_RDWR);if(fd<0){CloseHandle(h);return NULL;}
 f=_fdopen(fd,"w+b");if(!f)_close(fd);return f;
#else
 return tmpfile();
#endif
}
static void meta(TPDoc*out,const TPDoc*in){int l;memset(out,0,sizeof(*out));out->size=in->size;out->active=in->active;out->alpha=in->alpha;out->mesh_hash=in->mesh_hash;memcpy(out->uvname,in->uvname,256);memcpy(out->texture_path,in->texture_path,1024);for(l=0;l<TP_LAYERS;l++){memcpy(out->layer[l].name,in->layer[l].name,64);out->layer[l].opacity=in->layer[l].opacity;out->layer[l].visible=in->layer[l].visible;}}
static void apply_meta(TPDoc*d,const TPDoc*m){int l;unsigned char*p[TP_LAYERS];for(l=0;l<TP_LAYERS;l++)p[l]=d->layer[l].rgba;*d=*m;for(l=0;l<TP_LAYERS;l++)d->layer[l].rgba=p[l];}
void tp_history_free(TPHistory*h){int i;for(i=0;i<h->count;i++)fclose(h->entry[i]);free(h->entry);memset(h,0,sizeof(*h));}
void tp_history_limit(TPHistory*h,int limit){if(limit<1)limit=1;while(h->count>limit){if(h->cursor>0){fclose(h->entry[0]);memmove(h->entry,h->entry+1,(size_t)(h->count-1)*sizeof(FILE*));h->count--;h->cursor--;}else fclose(h->entry[--h->count]);}}
typedef struct {uint64_t offset;uint32_t length,layer;} Patch;
int tp_history_commit(TPHistory*h,const TPDoc*before,const TPDoc*after,unsigned dirty,int limit){
 TPDoc a,b;FILE*f;size_t bytes,off;int l,changed;Patch p={0};FILE**entries;
 if(before->size!=after->size||!after->size)return -1;
 meta(&a,before);meta(&b,after);changed=memcmp(&a,&b,sizeof(a))!=0;bytes=(size_t)after->size*after->size*4;
 f=history_file();if(!f)return -1;
 if(fwrite(&a,sizeof(a),1,f)!=1||fwrite(&b,sizeof(b),1,f)!=1)goto fail;
 for(l=0;l<TP_LAYERS;l++)if(dirty&(1u<<l))for(off=0;off<bytes;off+=4096){
  size_t n=bytes-off<4096?bytes-off:4096;
  if(!memcmp(before->layer[l].rgba+off,after->layer[l].rgba+off,n))continue;
  changed=1;p.offset=off;p.length=(uint32_t)n;p.layer=(uint32_t)l;
  if(fwrite(&p,sizeof(p),1,f)!=1||fwrite(before->layer[l].rgba+off,1,n,f)!=n||fwrite(after->layer[l].rgba+off,1,n,f)!=n)goto fail;
 }
 if(!changed){fclose(f);return 0;}
 p.offset=0;p.length=0;p.layer=UINT32_MAX;if(fwrite(&p,sizeof(p),1,f)!=1||fflush(f)||ferror(f))goto fail;
 if(h->cursor==h->capacity){int capacity=h->capacity?h->capacity*2:16;entries=realloc(h->entry,(size_t)capacity*sizeof(FILE*));if(!entries)goto fail;h->entry=entries;h->capacity=capacity;}
 while(h->count>h->cursor)fclose(h->entry[--h->count]);
 h->entry[h->count++]=f;h->cursor=h->count;tp_history_limit(h,limit);return 1;
fail:fclose(f);return -1;
}
int tp_history_step(TPHistory*h,TPDoc*d,int redo){
 FILE*f;TPDoc a,b;Patch p;unsigned char old[4096],newer[4096];int pass;size_t bytes=(size_t)d->size*d->size*4;
 if(redo?h->cursor>=h->count:h->cursor<=0)return 0;
 f=h->entry[redo?h->cursor:h->cursor-1];
 /* Validate the complete retained stream before changing any pixel. */
 for(pass=0;pass<2;pass++){
  rewind(f);if(fread(&a,sizeof(a),1,f)!=1||fread(&b,sizeof(b),1,f)!=1||a.size!=d->size||b.size!=d->size||a.mesh_hash!=d->mesh_hash||b.mesh_hash!=d->mesh_hash)return 0;
  for(;;){if(fread(&p,sizeof(p),1,f)!=1)return 0;if(p.layer==UINT32_MAX)break;
   if(p.layer>=TP_LAYERS||p.length>4096||p.offset>bytes||p.length>bytes-p.offset||fread(old,1,p.length,f)!=p.length||fread(newer,1,p.length,f)!=p.length)return 0;
   if(pass)memcpy(d->layer[p.layer].rgba+(size_t)p.offset,redo?newer:old,p.length);
  }
 }
 apply_meta(d,redo?&b:&a);h->cursor+=redo?1:-1;return 1;
}
