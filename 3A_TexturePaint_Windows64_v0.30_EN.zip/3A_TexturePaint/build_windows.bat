@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: build_windows.bat "C:\path\LightWaveSDK"
  exit /b 1
)
if not exist "%~1\include\lwmodtool.h" exit /b 1
where cl >nul 2>nul
if errorlevel 1 (
  echo Open an x64 Native Tools Command Prompt for a recent Visual Studio version.
  exit /b 1
)
cl /nologo /LD /O2 /MT /std:c11 /D_MSWIN /I"%~1\include" src\native.c src\tp_core.c src\tp_history.c /link /OUT:3A_TexturePaint.p /MACHINE:X64 opengl32.lib gdi32.lib shell32.lib ole32.lib windowscodecs.lib uuid.lib user32.lib
if errorlevel 1 exit /b 1
echo Compiled. Integration still needs validation inside Modeler 2026.
endlocal
