#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
typedef unsigned UINT;typedef unsigned DWORD;typedef uintptr_t UINT_PTR;typedef void*HHOOK;typedef void*HWND;typedef void*LWXPanelID;typedef long LRESULT;typedef uintptr_t WPARAM;typedef intptr_t LPARAM;
typedef struct{long x,y;}POINT;typedef struct{long left,top,right,bottom;}RECT;
typedef struct{POINT pt;HWND hwnd;}MOUSEHOOKSTRUCT;typedef struct{MOUSEHOOKSTRUCT base;unsigned mouseData;}MOUSEHOOKSTRUCTEX;
#define CALLBACK
#define HC_ACTION 0
#define WM_LBUTTONUP 6
#define WM_MOUSEWHEEL 1
#define WM_MOUSEMOVE 2
#define WM_LBUTTONDOWN 3
#define WM_RBUTTONDOWN 4
#define WM_MBUTTONDOWN 5
#define WH_MOUSE 7
#define WH_GETMESSAGE 8
#define PM_REMOVE 1
#define ID_ALPHA_PRESETS 125
#define ID_ALPHA_SELECT 126
#define LOWORD(x) ((x)&65535)
#define MOUSE_DOWN 128
#define LCLICK(x) (((x)&32)&&!((x)&64))
#define ID_ALPHA_SCROLL 124
#define HIWORD(x) (((x)>>16)&65535)
typedef struct{HWND hwnd;UINT message;WPARAM wParam;LPARAM lParam;}MSG;
typedef struct{LWXPanelID panel;int ui_depth,ui_refreshing,busy,painting,pending,adjusting,queued_action,alpha_scroll_target,alpha_gallery_w,alpha_gallery_h;}Tool;
static struct{int cell,max_scroll,scroll;}alpha_catalog={120,1000,100};
static Tool*live;static HWND under=(void*)7;static POINT cursor={110,220};static RECT window={0,0,600,600};static int installs,uninstalls,updates;
static void trace(const char*s,Tool*t){(void)s;(void)t;}
static int clicks;
static void alpha_gallery_click(LWXPanelID p,unsigned cid,int x,int y,int*r,int n){assert(p&&cid==ID_ALPHA_PRESETS&&x>=0&&y>=0&&!r&&n==1);clicks++;}
static int IsChild(HWND a,HWND b){(void)a;(void)b;return 0;}
static int is_live(Tool*t){return t==live;}static Tool*find_panel(LWXPanelID p){return live&&p==live->panel?live:NULL;}static void request_ui(Tool*t){(void)t;updates++;}
static int PtInRect(const RECT*r,POINT p){return p.x>=r->left&&p.x<r->right&&p.y>=r->top&&p.y<r->bottom;}
static HWND WindowFromPoint(POINT p){(void)p;return under;}
static int GetWindowRect(HWND w,RECT*r){assert(w);*r=window;return 1;}
static int EqualRect(const RECT*a,const RECT*b){return memcmp(a,b,sizeof(*a))==0;}
static int GetCursorPos(POINT*p){*p=cursor;return 1;}
static unsigned GetCurrentThreadId(void){return 99;}
static HHOOK SetWindowsHookExW(int type,LRESULT(*cb)(int,WPARAM,LPARAM),void*m,unsigned thread){assert((type==WH_MOUSE||type==WH_GETMESSAGE)&&cb&&!m&&thread==99);installs++;return (void*)(uintptr_t)type;}
static int UnhookWindowsHookEx(HHOOK h){assert(h==(void*)7||h==(void*)8);uninstalls++;return 1;}
static LRESULT CallNextHookEx(HHOOK h,int c,WPARAM m,LPARAM p){(void)h;(void)c;(void)m;(void)p;return 77;}
#define WM_NULL 0

#include "../src/alpha_wheel.inc"
int main(void){Tool t={0};MOUSEHOOKSTRUCTEX m={0};t.panel=(void*)1;t.alpha_gallery_w=384;t.alpha_gallery_h=256;live=&t;m.base.pt=cursor;
 alpha_wheel_start();alpha_wheel_start();assert(installs==2);
 alpha_gallery_move(t.panel,0,10,20);m.mouseData=(unsigned)(uint16_t)(short)-120<<16;
 assert(alpha_mouse_hook(3,WM_MOUSEWHEEL,(LPARAM)&m)==77&&!updates); /* no-remove */
 assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==1&&t.alpha_scroll_target==148&&t.queued_action==ID_ALPHA_SCROLL);
 assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==1&&t.alpha_scroll_target==196); /* coalesce queued wheels */
 m.mouseData=(unsigned)120<<16;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==1&&t.alpha_scroll_target==148);
 
 t.queued_action=0;t.painting=1;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==77);t.painting=0;
 m.base.pt.x=900;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==77&&!alpha_hover_tool); /* viewport untouched */
 m.base.pt=cursor;alpha_gallery_move(t.panel,0,10,20);under=(void*)9;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==77);under=(void*)7;
 alpha_gallery_move(t.panel,0,10,20);window.left=50;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==77);window.left=0;
 alpha_gallery_move(t.panel,0,10,20);alpha_mouse_hook(0,WM_LBUTTONDOWN,(LPARAM)&m);assert(alpha_hover_tool==&t&&clicks==1); /* click then wheel without pointer motion */
 alpha_gallery_move(t.panel,0,10,20);live=NULL;assert(alpha_mouse_hook(0,WM_MOUSEWHEEL,(LPARAM)&m)==77);live=&t;
 t.queued_action=0;alpha_catalog.scroll=0;assert(alpha_wheel_delta(&t,120)&&t.alpha_scroll_target==0);
 assert(alpha_wheel_delta(&t,-1)&&!t.queued_action);assert(alpha_wheel_delta(&t,-2)&&t.alpha_scroll_target==1); /* high-resolution deltas */
 /* Direct XPanels mouse callback and message-loop wheel fallback. */
 t.queued_action=0;alpha_gallery_mouse(t.panel,ID_ALPHA_PRESETS,10,20,128|32);assert(clicks==2);
 {MSG msg={0};int start=alpha_catalog.scroll;msg.message=WM_MOUSEWHEEL;msg.wParam=(WPARAM)(unsigned)(uint16_t)(short)-120<<16;msg.lParam=(LPARAM)((unsigned)cursor.y<<16)|(unsigned)cursor.x;
 alpha_getmessage_hook(0,0,(LPARAM)&msg);assert(!t.queued_action); /* peek */
 alpha_getmessage_hook(0,PM_REMOVE,(LPARAM)&msg);assert(msg.message==WM_NULL&&t.queued_action==ID_ALPHA_SCROLL&&t.alpha_scroll_target>start);
 alpha_getmessage_hook(0,PM_REMOVE,(LPARAM)&msg); /* already consumed */
 }
 alpha_wheel_stop();assert(uninstalls==2&&!alpha_hover_tool&&!alpha_wheel_hook);alpha_wheel_stop();assert(uninstalls==2);
 puts("PASS: wheel directions, queued-event coalescing, partial deltas, bounds, view/window isolation, stale-tool safety and hook cleanup.");return 0;}
