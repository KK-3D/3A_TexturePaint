"""Exercise production Ink versus Paint/Eraser stroke callbacks."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include "tp_core.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
typedef struct {TPDoc doc,undo;TPMirror mirror;TPMesh mesh;TPView cache;float*coverage;TPRect coverage_rect;int history_pending,modified,image_modified;unsigned undo_dirty;} Session;
typedef struct {Session*s;TPBrush brush;double radius,strength,rgb[3],last[2],start_mouse[2],mouse[2],stamp_x,stamp_y,stamp_scale;int mirror_axis[3];int mode,hard,frameview,painting,pending,line_mode,update;} Tool;
static struct {unsigned char*rgba;int width,height;} stamp_asset;
static struct {TPAlpha mask;unsigned char*data;} brush_alpha;
static int updates;
#define LWT_TEST_NOTHING 0
static int matches(Tool*t){(void)t;return 1;}
static void request_ui(Tool*t){(void)t;}
static int stencil_layout(Tool*t,int w,int h,TPStencil*out){return tp_stencil_place(stamp_asset.rgba,stamp_asset.width,stamp_asset.height,w,h,t->stamp_x,t->stamp_y,t->stamp_scale,out);}
static void status(Tool*t,const char*s){(void)t;(void)s;}
static int native_frame(Tool*t,int n){(void)t;(void)n;return 1;}
static int checkpoint(Tool*t){tp_doc_free(&t->s->undo);return tp_doc_clone(&t->s->undo,&t->s->doc);}
static void composite_region(Tool*t,const TPRect*r){(void)t;assert(r->valid);updates++;}
'''
tail=r'''
int main(void){unsigned char image[8]={255,0,0,255,255,0,0,255};Session s={0};Tool t={0};size_t at=((size_t)256*512+256)*4;t.s=&s;t.radius=14;t.strength=1;t.hard=1;t.mode=TP_MODE_INK;t.rgb[2]=1;t.stamp_x=t.stamp_y=.5;t.stamp_scale=1;t.start_mouse[0]=t.start_mouse[1]=t.mouse[0]=t.mouse[1]=100;stamp_asset.rgba=image;stamp_asset.width=2;stamp_asset.height=1;assert(tp_doc_init(&s.doc,512,1,"UV"));strcpy(s.doc.texture_path,"copy.png");assert(tp_view_resize(&s.cache,200,200));s.cache.uv_mode=1;s.coverage=calloc(512*512,sizeof(float));assert(s.coverage);
 begin_stroke(&t);assert(!t.brush.erase&&s.doc.layer[0].rgba[at]==255&&s.doc.layer[0].rgba[at+2]==0&&s.doc.layer[0].rgba[at+3]==255&&s.modified&&s.image_modified&&updates);
 t.mode=1;begin_stroke(&t);assert(t.brush.erase&&s.doc.layer[0].rgba[at+3]==0);
 t.mode=0;begin_stroke(&t);assert(!t.brush.erase&&s.doc.layer[0].rgba[at]==0&&s.doc.layer[0].rgba[at+2]==255&&s.doc.layer[0].rgba[at+3]==255);

 /* Fill all UV faces once; overlap must not accumulate opacity. */
 {TPTriangle tri[3]={0};double uv[4][2]={{0,0},{.5,0},{.5,1},{0,1}};int ids[2][3]={{0,1,2},{0,2,3}},i,j;
 for(i=0;i<2;i++)for(j=0;j<3;j++)memcpy(tri[i].v[j].uv,uv[ids[i][j]],sizeof(uv[0]));
 tri[2]=tri[0];s.mesh.tri=tri;s.mesh.count=3;s.doc.active=1;t.mode=TP_MODE_FILL;t.strength=.5;t.rgb[0]=1;t.rgb[2]=0;
 begin_stroke(&t);assert(!t.pending&&s.coverage_rect.valid);
 for(i=0;i<512;i++)for(j=0;j<512;j++){unsigned char*q=s.doc.layer[1].rgba+((size_t)i*512+j)*4;
 if(j<256)assert(q[0]==255&&q[1]==0&&q[2]==0&&q[3]==128);else assert(q[3]==0);}
 {int old_updates=updates;stamp_to(&t,100,100);assert(updates==old_updates);}
 /* New click blends once again; snapshot remains the prior fill for Undo. */
 begin_stroke(&t);assert(s.doc.layer[1].rgba[3]==192&&s.undo.layer[1].rgba[3]==128);
 t.strength=1;begin_stroke(&t);assert(s.doc.layer[1].rgba[3]==255);
 t.strength=0;t.painting=t.pending=1;begin_stroke(&t);assert(!t.painting&&!t.pending&&s.doc.layer[1].rgba[3]==255);
 }
 /* Live straight line uses one stroke snapshot and the selected alpha. */
 {unsigned char half=128;t.mode=TP_MODE_PAINT;t.strength=1;t.radius=3;t.hard=1;s.doc.active=3;
 t.start_mouse[0]=t.start_mouse[1]=20;t.mouse[0]=t.mouse[1]=180;
 brush_alpha.data=&half;brush_alpha.mask=(TPAlpha){&half,1,1,0};begin_stroke(&t);
 assert(s.doc.layer[3].rgba[((size_t)256*512+256)*4+3]==128);
 assert(s.doc.layer[3].rgba[((size_t)140*512+256)*4+3]==0);
 assert(s.undo.layer[3].rgba[((size_t)256*512+256)*4+3]==0);
 /* Move line to horizontal: diagonal must disappear immediately, baseline stays. */
 t.painting=1;t.pending=0;t.line_mode=1;s.history_pending=1;t.mouse[1]=20;
 redraw_line(&t);
 assert(s.doc.layer[3].rgba[((size_t)256*512+256)*4+3]==0);
 assert(s.doc.layer[3].rgba[((size_t)28*512+256)*4+3]==128);
 /* Repeated redraw must not accumulate strength. */
 redraw_line(&t);assert(s.doc.layer[3].rgba[((size_t)28*512+256)*4+3]==128);
 /* Reverse/shrink: old extension goes away. */
 t.mouse[0]=70;redraw_line(&t);assert(s.doc.layer[3].rgba[((size_t)28*512+256)*4+3]==0);
 assert(s.doc.layer[3].rgba[((size_t)28*512+100)*4+3]==128);
 cancel_line(&t);assert(!t.painting&&!t.line_mode&&!s.history_pending);
 assert(s.doc.layer[3].rgba[((size_t)28*512+100)*4+3]==0);
 brush_alpha.data=NULL;
 }
 free(s.coverage);tp_view_free(&s.cache);tp_doc_free(&s.doc);tp_doc_free(&s.undo);puts("PASS: production stroke callbacks select image ink versus palette paint/eraser, clear prior coverage, mark saves and refresh the affected region.");return 0;}
'''

root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'ink.c';out=Path(d)/'ink'
    c.write_text(head+'\n'.join(function(n) for n in ['bound','stamp_to','begin_stroke','restore_line_pixels','redraw_line','cancel_line'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
