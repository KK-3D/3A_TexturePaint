"""Exercise production Ink versus Paint/Eraser stroke callbacks."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;{]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head='\n#include "tp_history.h"\n#include <assert.h>\n#include <string.h>\n#include <stdlib.h>\ntypedef void*LWInstance;\ntypedef unsigned long long ULONGLONG;\nenum{ID_UNDO=1,ID_REDO};\ntypedef struct {TPDoc doc,undo;TPHistory history;int history_pending,valid,canundo,canredo,modified,image_modified;unsigned undo_dirty;ULONGLONG last_save;} Session;\ntypedef struct {Session*s;int adjusting,painting,pending,dirty,busy,queued_action,save_timing;} Tool;\nstatic int undo_levels=3,auto_save_image=0,refreshes;\nstatic int commit_history(Tool*);\nstatic void status(Tool*t,const char*s){(void)t;(void)s;}\nstatic void composite(Tool*t){(void)t;refreshes++;}\nstatic void sync_ui(Tool*t){(void)t;}\nstatic void request_ui(Tool*t){t->dirty=1;}\nstatic int autosave(Tool*t){return commit_history(t);}\nstatic ULONGLONG GetTickCount64(void){return 100000;}\n'
tail='\nint main(void){Session s={0};Tool t={0};int i;t.s=&s;s.valid=1;assert(tp_doc_init(&s.doc,512,1,"UV"));strcpy(s.doc.texture_path,"paint.png");\n for(i=1;i<=5;i++){assert(checkpoint(&t));s.doc.layer[0].rgba[0]=(unsigned char)i;s.undo_dirty=1;finish_stroke(&t);assert(!s.history_pending);}\n assert(s.history.count==3);\n for(i=4;i>=2;i--){undo_action(&t,0);assert(s.doc.layer[0].rgba[0]==i&&s.modified&&s.image_modified);}\n undo_action(&t,0);assert(s.doc.layer[0].rgba[0]==2);\n for(i=3;i<=5;i++){undo_action(&t,1);assert(s.doc.layer[0].rgba[0]==i);}\n undo_action(&t,0);assert(checkpoint(&t));s.doc.layer[0].rgba[0]=99;s.undo_dirty=1;finish_stroke(&t);assert(!s.canredo);\n undo_action(&t,0);assert(s.doc.layer[0].rgba[0]==4);undo_action(&t,1);assert(s.doc.layer[0].rgba[0]==99);\n assert(checkpoint(&t));s.doc.layer[0].visible=0;changed(&t);undo_action(&t,0);assert(s.doc.layer[0].visible==1);\n t.queued_action=0;tool_undo(&t);assert(t.queued_action==ID_UNDO);t.queued_action=0;tool_redo(&t);assert(t.queued_action==ID_REDO);\n assert(refreshes>0);tp_history_free(&s.history);tp_doc_free(&s.doc);tp_doc_free(&s.undo);\n puts("PASS: native checkpoint/commit, consecutive Undo/Redo, branch edit, layer metadata, save flags and deferred host shortcuts.");\n return 0;}\n'

root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'history.c';out=Path(d)/'history'
    c.write_text(head+'\n'.join(function(n) for n in ['checkpoint','commit_history','changed','finish_stroke','undo_action','tool_undo','tool_redo'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),str(root/'src/tp_history.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
