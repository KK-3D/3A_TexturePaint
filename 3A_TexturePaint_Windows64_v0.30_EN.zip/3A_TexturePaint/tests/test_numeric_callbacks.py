"""Compile actual Numeric callback bodies against a deliberately reentrant fake host.
No Windows or LightWave required. This checks callback safety, not host integration.
"""
from pathlib import Path
import re, subprocess, tempfile
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M)
    assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef void* LWXPanelID;
typedef void* LWInstance;
typedef int LWXPRefreshCode;
enum {LWXPRC_NONE=0,LWXPRC_FULL=3,LWT_TEST_UPDATE=1,LWT_TEST_NOTHING=0};
#define TP_MODE_INK 3

typedef struct {int valid;} Session;
typedef struct {void (*viewRefresh)(LWXPanelID);} XP;
typedef struct Tool {struct Tool*next;LWXPanelID panel;XP*xp;Session*s;
 unsigned long long image_list_poll;int mode,line_mode,adjusting,painting,pending,busy,queued_action,ui_pending,ui_refreshing,ui_depth,dirty,update;
 char status[512];} Tool;
static Tool*live_tools;
static void alpha_dispatch_wake(Tool*t){(void)t;}
static unsigned long long GetTickCount64(void){return 0;}
static void refresh_project_images(Tool*t){(void)t;}
static int actions,refreshes,nested;
static void trace(const char*s,Tool*t){(void)s;(void)t;}
static void run_action(Tool*t,int id);
static int query_target(Tool*t,char a[1024],char b[256],char c[256]){(void)t;(void)a;(void)b;(void)c;return 1;}
'''
head+=re.search(r'enum \{ID_PREP.*?\};',src).group(0)
body='\n'.join(function(n) for n in ['ink_control','ink_control_allowed','find_panel','is_live','request_ui','flush_ui','status','button','panel_changed','test'])
tail=r'''
static void run_action(Tool*t,int id){assert(id==ID_CREATE);assert(t->ui_depth==0&&t->busy);actions++;status(t,"Texture created");flush_ui(t);}
static void fake_refresh(LWXPanelID p){Tool*t=find_panel(p);assert(t);assert(t->ui_depth==0&&!t->busy);assert(!nested);nested=1;refreshes++;
 /* A synchronous callback from the host must neither recurse nor start work. */
 request_ui(t);flush_ui(t);button(p,ID_CREATE);assert(!t->queued_action);nested=0;
}
int main(void){Session s={0};XP xp={fake_refresh};Tool t={0};int p=1,stale=2;
 t.panel=&p;t.xp=&xp;t.s=&s;live_tools=&t;
 button(&p,ID_CREATE);assert(!actions&&!refreshes&&!t.queued_action);assert(strstr(t.status,"Not prepared"));
 assert(panel_changed(&p,ID_CREATE,0,0)==LWXPRC_FULL);assert(!refreshes);
 button(&stale,ID_CREATE);assert(!t.queued_action);
 button(&p,ID_PREP);assert(t.update==LWT_TEST_UPDATE);
 s.valid=1;t.adjusting=1;button(&p,ID_CREATE);assert(!t.queued_action);t.adjusting=0;button(&p,ID_CREATE);assert(t.queued_action==ID_CREATE&&!actions&&!refreshes);
 button(&p,ID_CREATE);assert(t.queued_action==ID_CREATE);
 test(&t);assert(actions==1&&!t.queued_action&&!refreshes&&!t.busy);assert(!strcmp(t.status,"Texture created"));
 flush_ui(&t);assert(refreshes==1&&!t.ui_refreshing);t.ui_pending=0;
 t.ui_depth=1;request_ui(&t);flush_ui(&t);assert(refreshes==1);t.ui_depth=0;
 t.busy=1;flush_ui(&t);assert(refreshes==1);t.busy=0;flush_ui(&t);assert(refreshes==2);
 {int mode;unsigned ids[]={ID_LOAD_STAMP,ID_PROJECT_IMAGES,ID_REFRESH_IMAGES,ID_STAMP_SHOW,ID_STAMP_OPACITY,ID_STAMP_X,ID_STAMP_Y,ID_STAMP_SCALE,ID_STAMP_ROTATION,ID_CENTER_STAMP};unsigned i;
 t.busy=t.adjusting=t.painting=t.pending=t.queued_action=t.ui_refreshing=0;
 for(mode=0;mode<4;mode++){t.mode=mode;for(i=0;i<sizeof(ids)/sizeof(ids[0]);i++)assert(ink_control_allowed(&t,ids[i])==(mode==3));button(&p,ID_LOAD_STAMP);assert((t.queued_action==ID_LOAD_STAMP)==(mode==3));t.queued_action=0;assert(ink_control_allowed(&t,ID_COLOR));}}
 live_tools=NULL;button(&p,ID_CREATE);assert(actions==1);assert(!is_live(&t));
 puts("PASS: unprepared Create, stale panels, deferred single execution, callback depth and reentrant refresh.");return 0;
}
'''
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'callbacks.c';binary=Path(d)/'callbacks';c.write_text(head+body+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-g',str(c),'-o',str(binary)],check=True)
    import os
    env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
    subprocess.run([str(binary)],check=True,env=env)
