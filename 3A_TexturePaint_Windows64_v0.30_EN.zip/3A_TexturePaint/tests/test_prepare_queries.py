"""Exercise production preflight/matching code with missing targets and reused host strings."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef unsigned LWID;
enum {OPLYR_PRIMARY=0,LWM_VMAP_TEXTURE=1,LWVMAP_TXUV=123};
typedef struct {const char*(*object)(void);const char*(*layerList)(int,const char*);const char*(*vmap)(int,LWID*);} State;
typedef struct {int valid;char object[1024],layer_key[256];} Session;
typedef struct {State*state;Session*s;char status[512];} Tool;
static void trace(const char*s,Tool*t){(void)s;(void)t;}
static void status(Tool*t,const char*s){snprintf(t->status,sizeof(t->status),"%s",s);}
static int mode,calls[3];static char shared[1200];
static const char*obj(void){calls[0]++;if(mode==1)return NULL;if(mode==4){memset(shared,'a',1100);shared[1100]=0;return shared;}strcpy(shared,"cube.lwo");return shared;}
static const char*layers(int layer,const char*name){(void)layer;(void)name;calls[1]++;assert(mode!=1&&mode!=4);if(mode==2)return NULL;strcpy(shared,"1");return shared;}
static const char*uvmap(int index,LWID*type){(void)index;calls[2]++;assert(mode!=1&&mode!=2&&mode!=4);*type=LWVMAP_TXUV;if(mode==3)return NULL;if(mode==5)*type=9;strcpy(shared,"PaintUV");return shared;}
'''
tail=r'''
int main(void){Session s={0};State state={obj,layers,uvmap};Tool t={&state,&s,{0}};char o[1024],k[256],uv[256];
 assert(!matches(&t));assert(calls[0]==0&&calls[1]==0);
 mode=1;assert(!query_target(&t,o,k,uv));assert(calls[0]==1&&!calls[1]&&!calls[2]);assert(strstr(t.status,"No active object"));
 mode=2;assert(!query_target(&t,o,k,uv));assert(!calls[2]);assert(strstr(t.status,"primary layer"));
 mode=3;assert(!query_target(&t,o,k,uv));assert(strstr(t.status,"UV map"));
 mode=4;assert(!query_target(&t,o,k,uv));
 mode=5;assert(!query_target(&t,o,k,uv));
 mode=0;assert(query_target(&t,o,k,uv));assert(!strcmp(o,"cube.lwo")&&!strcmp(k,"1")&&!strcmp(uv,"PaintUV"));
 s.valid=1;strcpy(s.object,"cube.lwo");strcpy(s.layer_key,"1");assert(matches(&t));mode=1;assert(!matches(&t));
 puts("PASS: no object, no layer, missing/wrong UV, long names, unprepared overlay and reused host buffers.");return 0;
}
'''
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'queries.c';out=Path(d)/'queries';c.write_text(head+function('query_target')+function('matches')+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',str(c),'-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
