"""Exercise production PNG save policy, project saves, retries and shutdown."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
typedef unsigned long long ULONGLONG;
typedef struct {char texture_path[1024];} Doc;
typedef struct {Doc doc;int valid,modified,image_modified;char project[1024];ULONGLONG last_save;} Session;
typedef struct {Session*s;int save_timing;} Tool;
static struct {unsigned char*rgba,*display_rgba;} stamp_asset;
static struct {unsigned char*data;} brush_alpha;
static void free_alpha_catalog(void){}
static void alpha_wheel_stop(void){}
static void alpha_dispatch_stop(void){}
static Session session;static int auto_save_image=1,project_writes,image_writes,reloads,fail_project,fail_image,fail_reload;static ULONGLONG now=100;
static ULONGLONG GetTickCount64(void){return now;}
static void status(Tool*t,const char*s){(void)t;(void)s;}
static int commit_history(Tool*t){(void)t;return 1;}
static int atomic_file(Session*s,const char*path,int project){(void)s;assert(*path);if(project){project_writes++;return !fail_project;}image_writes++;return !fail_image;}
static int refresh_image(Tool*t){(void)t;reloads++;return !fail_reload;}
static void free_session(Session*s){s->valid=0;}
'''
tail=r'''
int main(void){Tool t={&session,0};session.valid=1;strcpy(session.project,"layers.tpaint");strcpy(session.doc.texture_path,"paint.png");
 session.modified=session.image_modified=1;assert(autosave(&t));assert(project_writes==1&&image_writes==1&&reloads==1&&!session.modified&&!session.image_modified);
 auto_save_image=0;session.modified=session.image_modified=1;finish_stroke(&t);assert(project_writes==2&&image_writes==1&&!session.modified&&session.image_modified);
 assert(autosave(&t));assert(image_writes==1&&session.image_modified); /* Deactivation uses this same gate. */
 assert(save_texture(&t));assert(image_writes==2&&!session.image_modified); /* Explicit manual PNG save works when off. */
 session.image_modified=1;auto_save_image=1;assert(autosave(&t));assert(image_writes==3&&project_writes==2&&!session.image_modified); /* Pending PNG survives clean project. */
 session.modified=session.image_modified=1;fail_project=1;assert(!autosave(&t));assert(session.modified&&session.image_modified&&image_writes==3);fail_project=0;fail_image=1;assert(!autosave(&t));assert(!session.modified&&session.image_modified);fail_image=0;fail_reload=1;assert(!autosave(&t)&&session.image_modified);fail_reload=0;assert(autosave(&t)&&!session.image_modified);
 t.save_timing=1;session.modified=session.image_modified=1;{int projects=project_writes,images=image_writes;now=101;finish_stroke(&t);assert(project_writes==projects&&image_writes==images);now=30100;finish_stroke(&t);assert(project_writes==projects+1&&image_writes==images+1);}
 auto_save_image=0;session.modified=session.image_modified=1;{int images=image_writes,projects=project_writes;module_shutdown(NULL);assert(image_writes==images&&project_writes==projects+1);}
 session.valid=1;session.modified=0;session.image_modified=1;auto_save_image=1;{int images=image_writes;module_shutdown(NULL);assert(image_writes==images+1);}
 puts("PASS: auto/manual PNG policy, independent project safety saves, pending PNG retry/re-enable, write/reload failures, timed saves and shutdown respecting manual mode.");return 0;}
'''

with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'save.c';out=Path(d)/'save'
    c.write_text(head+'\n'.join(function(n) for n in ['save_texture','autosave','finish_stroke','module_shutdown'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',str(c),'-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
