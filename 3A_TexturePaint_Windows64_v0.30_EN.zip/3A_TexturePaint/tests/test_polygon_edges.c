#include "../src/tp_core.c"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int main(void){TPMesh m={0};TPView v={0};TPDoc d={0},before={0};TPBrush brush={100,1,0,1,{255,0,0}};TPRect dirty={0};float*mask=calloc(512*512,sizeof(float));int grid=12,at=0;
 m.count=m.capacity=2*grid*grid;m.tri=calloc(m.count,sizeof(TPTriangle));v.project_count=m.count;v.projected=calloc(m.count*3,sizeof(TPProjected));
 assert(tp_view_resize(&v,100,100));assert(tp_doc_init(&d,512,1,"UV"));assert(tp_doc_clone(&before,&d));
 for(int y=0;y<grid;y++)for(int x=0;x<grid;x++)for(int t=0;t<2;t++,at++)for(int j=0;j<3;j++){
  const int ids[2][3]={{0,1,2},{0,2,3}},dx[4]={0,1,1,0},dy[4]={0,0,1,1};int k=ids[t][j];double u=(x+dx[k])/(double)grid,w=(y+dy[k])/(double)grid;TPProjected*q=&v.projected[at*3+j];TPVertex*p=&m.tri[at].v[j];
  p->uv[0]=u;p->uv[1]=1-w;p->p[0]=u;p->p[1]=w;p->p[2]=.3*(u-.5)*(u-.5)+.4*(w-.5)*(w-.5);
  q->x=12.17+75.37*u;q->y=11.31+76.28*w;q->w=1;q->z=1+p->p[2];
 }
 assert(tp_render_projected(&v,&m,&d,NULL));assert(tp_stamp_masked(&m,&v,&d,&before,mask,&brush,50,50,&dirty,NULL,NULL));
 {unsigned holes=0;for(int y=2;y<510;y++)for(int x=2;x<510;x++)if(d.layer[0].rgba[((size_t)y*512+x)*4+3]!=255)holes++;printf("Internal edge holes: %u\n",holes);assert(!holes);}
 /* Optional-index failure must produce exactly the same stroke. */
 {unsigned char*reference=malloc(512*512*4);assert(reference);memcpy(reference,d.layer[0].rgba,512*512*4);
 spatial_free(&v);memset(mask,0,512*512*sizeof(float));memset(d.layer[0].rgba,0,512*512*4);
 assert(tp_stamp_masked(&m,&v,&d,&before,mask,&brush,50,50,&dirty,NULL,NULL));
 assert(!memcmp(reference,d.layer[0].rgba,512*512*4));free(reference);}
 /* Perspective interpolation must also keep shared edges closed. */
 for(size_t i=0;i<m.count*3;i++)v.projected[i].w=v.projected[i].z;
 memset(mask,0,512*512*sizeof(float));memset(d.layer[0].rgba,0,512*512*4);
 assert(tp_render_projected(&v,&m,&d,NULL));assert(tp_stamp_masked(&m,&v,&d,&before,mask,&brush,50,50,&dirty,NULL,NULL));
 for(int y=2;y<510;y++)for(int x=2;x<510;x++)assert(d.layer[0].rgba[((size_t)y*512+x)*4+3]==255);
 /* A genuinely hidden surface in a separate UV island must remain untouched. */
 {size_t old=m.count;m.tri=realloc(m.tri,old*2*sizeof(TPTriangle));v.projected=realloc(v.projected,old*6*sizeof(TPProjected));assert(m.tri&&v.projected);
 for(size_t i=0;i<old;i++){m.tri[old+i]=m.tri[i];for(int j=0;j<3;j++){
 m.tri[i].v[j].uv[0]*=.5;m.tri[old+i].v[j].uv[0]=.5+m.tri[i].v[j].uv[0];
 v.projected[(old+i)*3+j]=v.projected[i*3+j];v.projected[(old+i)*3+j].z+=2;
 }}
 m.count=m.capacity=v.project_count=old*2;memset(mask,0,512*512*sizeof(float));memset(d.layer[0].rgba,0,512*512*4);
 assert(tp_render_projected(&v,&m,&d,NULL));assert(tp_stamp_masked(&m,&v,&d,&before,mask,&brush,50,50,&dirty,NULL,NULL));
 {unsigned missing=0,leaks=0;for(int y=2;y<510;y++)for(int x=2;x<510;x++){int a=d.layer[0].rgba[((size_t)y*512+x)*4+3];if(x<256&&a!=255)missing++;if(x>=256&&a!=0){if(!leaks)fprintf(stderr,"First leak %d,%d alpha=%d\n",x,y,a);leaks++;}}fprintf(stderr,"Missing=%u leaks=%u\n",missing,leaks);assert(!missing&&!leaks);}
 }
 
 tp_doc_free(&d);tp_doc_free(&before);tp_view_free(&v);free(m.tri);free(mask);puts("PASS: no cracks across orthographic/perspective faceted edges; hidden UV island remains unpainted.");
}
