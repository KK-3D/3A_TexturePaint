/* Linux/Mesa integration harness for the actual overlay implementation.
   Needs the LightWave SDK headers, an OpenGL 1.1 header, libGL and libEGL.
   No LightWave binary is involved. */
#define WINGDIAPI
#define APIENTRY
#include <GL/gl.h>
#include <lwtool.h>
#include <lwviewportinfo.h>
#include "../src/tp_core.h"
#include <assert.h>
#include <math.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
typedef void(*PROC)(void);
extern PROC eglGetProcAddress(const char*);
extern void* eglGetDisplay(void*);
extern unsigned eglInitialize(void*,int*,int*);
extern unsigned eglBindAPI(unsigned);
extern unsigned eglChooseConfig(void*,const int*,void**,int,int*);
extern void* eglCreatePbufferSurface(void*,void*,const int*);
extern void* eglCreateContext(void*,void*,void*,const int*);
extern unsigned eglMakeCurrent(void*,void*,void*,void*);
extern unsigned eglDestroySurface(void*,void*);
extern unsigned eglDestroyContext(void*,void*);
extern unsigned eglTerminate(void*);
static PROC wglGetProcAddress(const char*n){return eglGetProcAddress(n);}
static void* wglGetCurrentContext(void){return (void*)1;}
typedef struct {TPMesh mesh;unsigned char*preview_rgb;int preview_size;} Session;
typedef struct {Session*s;LWViewportInfo*vp;int mode,stamp_show;double stamp_opacity,stamp_x,stamp_y,stamp_scale,stamp_rotation;int preview,cursor_view,adjusting,line_mode;double start_mouse[2],mouse[2];double strength,radius,cursor_xy[2];} Tool;
static int paint_view(Tool*t,int n){return n>=0&&n<t->vp->numViewports;}
static int matches(Tool*t){return t->s!=NULL;}
static struct {unsigned char*rgba,*display_rgba;int width,height;} stamp_asset;
static struct {TPAlpha mask;unsigned char*data;unsigned char cursor[128*128*4];int cursor_valid,cursor_invert;} brush_alpha;
static double bound(double x){return !isfinite(x)?0:x<0?0:x>1?1:x;}
static int stencil_layout(Tool*t,int w,int h,TPStencil*out){if(!tp_stencil_place(stamp_asset.rgba,stamp_asset.width,stamp_asset.height,w,h,t->stamp_x,t->stamp_y,t->stamp_scale,out))return 0;out->rotation_cos=cos(t->stamp_rotation*0.017453292519943295);out->rotation_sin=sin(t->stamp_rotation*0.017453292519943295);return 1;}
#include "../src/overlay.inc"
static int viewtype=1;
static int type(int n){(void)n;return viewtype;}
static void rect(int n,int*l,int*t,int*w,int*h){*l=n*256;*t=0;*w=*h=256;}
static int matrix(int n,LWDMatrix4 m,LWDMatrix4 inv){int i;(void)n;(void)inv;memset(m,0,sizeof(LWDMatrix4));for(i=0;i<4;i++)m[i][i]=1;return 1;}
static void pixel(int x,int y,unsigned char*out){glReadPixels(x,y,1,1,GL_RGBA,GL_UNSIGNED_BYTE,out);}
static int orange_near(int x,int y){int dx,dy;unsigned char p[4];for(dy=-1;dy<=1;dy++)for(dx=-1;dx<=1;dx++){pixel(x+dx,y+dy,p);if(p[0]>240&&p[1]>100&&p[1]<180&&p[2]<40)return 1;}return 0;}
static void base(void){glViewport(0,0,512,256);glDisable(GL_SCISSOR_TEST);glDisable(GL_STENCIL_TEST);glColorMask(1,1,1,1);glDepthMask(1);glClearColor(0,0,1,1);glClearDepth(0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);}
int main(void){void*d,*cfg,*surface,*ctx;int count,major,minor;unsigned char rgb[12]={0,255,0,255,0,0,0,255,0,255,0,0},px[4];Session s={0};Tool t={0};LWViewportInfo vp={0};int i,j;GLint mode,viewport[4];GLboolean mask[4];GLdouble depthrange[2];
 int config[]={0x3033,1,0x3040,8,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3025,24,0x3026,8,0x3038};int surf[]={0x3057,512,0x3056,256,0x3038};int attrs[]={0x3038};
 d=eglGetDisplay(NULL);assert(d&&eglInitialize(d,&major,&minor));assert(eglBindAPI(0x30a2));assert(eglChooseConfig(d,config,&cfg,1,&count)&&count);surface=eglCreatePbufferSurface(d,cfg,surf);ctx=eglCreateContext(d,cfg,NULL,attrs);assert(surface&&ctx&&eglMakeCurrent(d,surface,surface,ctx));printf("GL renderer: %s\n",glGetString(GL_RENDERER));
 vp.numViewports=2;vp.type=type;vp.rect=rect;vp.modelview=matrix;vp.projection=matrix;s.preview_rgb=rgb;s.preview_size=2;s.mesh.count=4;s.mesh.tri=calloc(4,sizeof(TPTriangle));assert(s.mesh.tri);
 /* Near green square is submitted first; far red square must not cover it. */
 {double p[4][2]={{-.8,-.8},{.8,-.8},{.8,.8},{-.8,.8}};int ix[2][3]={{0,1,2},{0,2,3}};
 for(i=0;i<4;i++)for(j=0;j<3;j++){TPVertex*v=&s.mesh.tri[i].v[j];v->p[0]=p[ix[i%2][j]][0];v->p[1]=p[ix[i%2][j]][1];v->p[2]=i<2?-.5:.5;v->uv[0]=i<2?.25:.75;v->uv[1]=.5;}}
 t.s=&s;t.vp=&vp;t.preview=1;t.cursor_view=1;t.radius=20;t.cursor_xy[0]=128;t.cursor_xy[1]=128;
 base();glViewport(256,0,256,256);
 /* Deliberately hostile inherited state, including depth that hides all geometry. */
 glEnable(GL_STENCIL_TEST);glStencilFunc(GL_NEVER,0,255);glEnable(GL_SCISSOR_TEST);glScissor(0,0,1,1);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_NEVER);glDepthRange(.2,.7);glColorMask(0,0,0,0);glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);glEnable(GL_TEXTURE_GEN_S);glEnable(GL_LINE_STIPPLE);glLineStipple(1,0x5555);glMatrixMode(GL_TEXTURE);
 overlay(&t,NULL,1,0);assert(glGetError()==GL_NO_ERROR);
 pixel(384,128,px);assert(px[0]<5&&px[1]>250&&px[2]<5);pixel(128,128,px);assert(px[2]>250&&px[0]<5);
 assert(orange_near(404,128)); /* orange ring */
 pixel(395,117,px);assert(px[0]<5&&px[1]>250); /* no spoke inside ring */
 glGetIntegerv(GL_MATRIX_MODE,&mode);assert(mode==GL_TEXTURE);glGetIntegerv(GL_VIEWPORT,viewport);assert(viewport[0]==256&&viewport[2]==256);glGetBooleanv(GL_COLOR_WRITEMASK,mask);assert(!mask[0]&&!mask[1]&&!mask[2]&&!mask[3]);glGetDoublev(GL_DEPTH_RANGE,depthrange);assert(fabs(depthrange[0]-.2)<1e-6&&fabs(depthrange[1]-.7)<1e-6);assert(glIsEnabled(GL_STENCIL_TEST)&&glIsEnabled(GL_TEXTURE_GEN_S)&&glIsEnabled(GL_LINE_STIPPLE));
 /* Other viewport paints independently, and cursor is not copied there. */
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(128,128,px);assert(px[1]>250&&px[0]<5);pixel(148,128,px);assert(px[1]>250&&px[0]<5);pixel(384,128,px);assert(px[2]>250);
 /* Cursor-only mode erases the old location on a normal scene redraw. */
 base();t.preview=0;t.cursor_view=0;t.cursor_xy[0]=80;t.cursor_xy[1]=70;glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(100,185));pixel(128,128,px);assert(px[2]>250);
 /* UV overlay uses UV coordinates, not the object's world positions. */
 base();viewtype=LVVIEWT_UV;t.preview=1;t.cursor_view=-1;s.mesh.count=2;
 {double uv[4][2]={{.1,.1},{.9,.1},{.9,.9},{.1,.9}};int ids[2][3]={{0,1,2},{0,2,3}};for(i=0;i<2;i++)for(j=0;j<3;j++)memcpy(s.mesh.tri[i].v[j].uv,uv[ids[i][j]],sizeof(s.mesh.tri[i].v[j].uv));}
 glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(160,160,px);assert(px[1]>240&&px[2]<5);pixel(80,80,px);assert(px[2]>250);
 /* Non-default host draw framebuffer and separate read binding survive. */
 {TPGL g=gl_functions();GLuint host=0,tex=0,rb=0;GLint current;
 g.genframe(1,&host);g.framebuffer(0x8ca9,host);glGenTextures(1,&tex);glBindTexture(GL_TEXTURE_2D,tex);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,512,256,0,GL_RGBA,GL_UNSIGNED_BYTE,NULL);g.attachtexture(0x8ca9,0x8ce0,GL_TEXTURE_2D,tex,0);glDrawBuffer(0x8ce0);assert(g.check(0x8ca9)==0x8cd5);g.genrender(1,&rb);g.renderbuffer(0x8d41,rb);
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);glGetIntegerv(0x8ca6,&current);assert(current==(GLint)host);glGetIntegerv(0x8caa,&current);assert(current==0);glGetIntegerv(0x8ca7,&current);assert(current==(GLint)rb);
 g.framebuffer(0x8ca8,host);glReadBuffer(0x8ce0);pixel(160,160,px);assert(px[1]>240&&px[2]<5);g.framebuffer(0x8d40,0);g.renderbuffer(0x8d41,0);g.delframe(1,&host);g.delrender(1,&rb);glDeleteTextures(1,&tex);}
 /* Stencil rows, opacity and alpha align with the CPU projection layout. */
 {unsigned char source[16]={255,0,0,255,0,255,0,128,0,0,255,0,255,255,255,255},display[16];for(i=0;i<4;i++){for(j=0;j<3;j++)display[4*i+j]=(unsigned char)((source[4*i+j]*source[4*i+3]+127)/255);display[4*i+3]=source[4*i+3];}stamp_asset.rgba=source;stamp_asset.display_rgba=display;stamp_asset.width=stamp_asset.height=2;
 t.mode=TP_MODE_INK;t.stamp_show=1;t.stamp_opacity=.5;t.stamp_x=t.stamp_y=.5;t.stamp_scale=1;t.preview=0;t.cursor_view=0;t.cursor_xy[0]=t.cursor_xy[1]=20;t.radius=5;
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(80,175,px);assert(abs(px[0]-128)<=2&&px[1]<2&&abs(px[2]-127)<=2);pixel(175,175,px);assert(px[0]<2&&abs(px[1]-64)<=2&&abs(px[2]-191)<=2);pixel(80,80,px);assert(px[0]<2&&px[1]<2&&px[2]>250);pixel(175,80,px);assert(abs(px[0]-128)<=2&&abs(px[1]-128)<=2&&px[2]>250);
 base();t.stamp_show=0;glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(80,175,px);assert(px[0]<2&&px[2]>250);
 base();t.stamp_show=1;t.stamp_x=t.stamp_y=.25;t.stamp_scale=.5;glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(40,215,px);assert(px[0]>120&&px[2]<135);pixel(160,175,px);assert(px[0]<2&&px[2]>250);
 /* Border and handles stay orange even when image opacity is zero. */
 t.stamp_x=t.stamp_y=.5;t.stamp_scale=1;t.stamp_opacity=0;
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);
 assert(orange_near(133,192));pixel(128,191,px);assert(px[2]>250);
 assert(orange_near(198,128));pixel(192,127,px);assert(px[2]>250);
 assert(orange_near(64,150));assert(orange_near(128,128));assert(orange_near(140,128));
 /* Clockwise rotation sends top-left red to top-right. */
 t.stamp_opacity=.5;t.stamp_rotation=90;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);
 pixel(175,175,px);assert(abs(px[0]-128)<=2&&px[1]<2&&abs(px[2]-127)<=2);
 assert(orange_near(192,133));
 t.mode=0;stamp_asset.rgba=stamp_asset.display_rgba=NULL;}
 /* Full-radius strength scale, equal line width, no inner ring at 100%. */
 t.cursor_xy[0]=t.cursor_xy[1]=128;t.radius=40;t.strength=.5;
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(148,128));assert(orange_near(168,128));assert(!orange_near(158,128));
 t.strength=.75;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(158,128));assert(!orange_near(148,128));
 t.strength=1;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(168,128));assert(!orange_near(158,128));assert(!orange_near(148,128));
 t.strength=0;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(168,128));assert(!orange_near(148,128));
 t.mode=TP_MODE_FILL;t.strength=.5;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(128,128));assert(!orange_near(168,128));assert(!orange_near(148,128));assert(!orange_near(134,128));
 t.mode=TP_MODE_PAINT;t.line_mode=1;t.start_mouse[0]=t.start_mouse[1]=80;t.mouse[0]=t.mouse[1]=160;t.cursor_xy[0]=t.cursor_xy[1]=160;
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);assert(orange_near(120,136));assert(!orange_near(120,146));
 /* Alpha cursor tint/transparency, feather, invert, removal and Fill exclusion. */
 {unsigned char white=255;t.line_mode=0;t.strength=1;t.cursor_xy[0]=t.cursor_xy[1]=128;t.radius=40;
 brush_alpha.data=&white;brush_alpha.mask=(TPAlpha){&white,1,1,0};brush_alpha.cursor_valid=0;
 base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(128,128,px);
 assert(px[0]>=98&&px[0]<=102&&px[1]>=53&&px[1]<=57&&px[2]>150&&px[2]<175);
 pixel(165,128,px);assert(px[0]>0&&px[0]<95);pixel(163,163,px);assert(px[0]==0&&px[2]==255);
 brush_alpha.mask.invert=1;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(128,128,px);assert(px[0]==0&&px[2]==255);
 brush_alpha.mask.invert=0;t.mode=TP_MODE_FILL;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(138,128,px);assert(px[0]==0&&px[2]==255);
 t.mode=TP_MODE_PAINT;brush_alpha.data=NULL;base();glViewport(0,0,256,256);overlay(&t,NULL,0,0);pixel(128,128,px);assert(px[0]==0&&px[2]==255);
 }
 assert(glGetError()==GL_NO_ERROR);free(s.mesh.tri);eglMakeCurrent(d,NULL,NULL,NULL);eglDestroyContext(d,ctx);eglDestroySurface(d,surface);eglTerminate(d);puts("PASS: real GL rendering, target viewport, own-mesh occlusion, orange ring without spokes, cursor-only movement, native UV geometry and host state/framebuffer restoration.");return 0;
}
