#include "../src/tp_core.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char**argv){int size,alpha,l;const char*dir=argc>1?argv[1]:"/tmp";char path[512];
 for(size=1024;size<=8192;size*=2){TPDoc d={0},loaded={0};unsigned char*p;FILE*f;size_t n=(size_t)size*size;
  assert(tp_doc_init(&d,size,42,"UV"));d.alpha=0;strcpy(d.texture_path,"C:\\Texturas\\pintura.png");
  d.layer[0].rgba[0]=255;d.layer[0].rgba[3]=128;d.layer[0].rgba[(n-1)*4+2]=255;d.layer[0].rgba[(n-1)*4+3]=255;
  p=malloc(n*4);assert(p);tp_composite(&d,p);
  for(alpha=0;alpha<=1;alpha++){snprintf(path,sizeof(path),"%s/texture_%d_%d.png",dir,size,alpha);f=fopen(path,"wb");assert(f&&tp_png_mode(f,p,size,size,alpha));assert(!fclose(f));}
  free(p);f=tmpfile();assert(f&&tp_project_write(f,&d));tp_doc_free(&d);rewind(f);assert(tp_project_read(f,&loaded,42,"UV"));fclose(f);
  assert(loaded.size==size&&loaded.alpha==0&&!strcmp(loaded.texture_path,"C:\\Texturas\\pintura.png"));assert(loaded.layer[0].rgba[3]==128&&loaded.layer[0].rgba[(n-1)*4+2]==255);
  for(l=1;l<TP_LAYERS;l++)assert(loaded.layer[l].rgba[(n-1)*4+3]==0);
  /* Actual brush at every size: verify a stroke and eraser on the UV canvas. */
  {TPDoc before={0};TPView v={0};TPMesh mesh={0};TPBrush brush={12,1,0,1,{0,255,0}};float*mask=calloc(n,sizeof(float));size_t mid=((size_t)size/2*size+size/2)*4;
   assert(mask&&tp_doc_clone(&before,&loaded));assert(!before.alpha&&!strcmp(before.texture_path,loaded.texture_path));
   assert(tp_view_resize(&v,64,64));v.uv_mode=1;
   assert(tp_stamp(&mesh,&v,&loaded,&before,mask,&brush,32,32));assert(loaded.layer[0].rgba[mid+1]==255&&loaded.layer[0].rgba[mid+3]==255);
   tp_doc_free(&before);assert(tp_doc_clone(&before,&loaded));memset(mask,0,n*sizeof(float));brush.erase=1;
   assert(tp_stamp(&mesh,&v,&loaded,&before,mask,&brush,32,32));assert(loaded.layer[0].rgba[mid+3]==0);
   tp_doc_free(&before);free(mask);tp_view_free(&v);
  }
  tp_doc_free(&loaded);printf("PASS: %d RGB/RGBA PNG, project metadata/layers round-trip, brush and eraser.\n",size);fflush(stdout);
 }
 /* Backward compatibility with a genuine v1 file written by the previous binary. */
 if(argc>2){TPDoc old={0};FILE*f=fopen(argv[2],"rb");assert(f);/* Hash and UV provided by fixture header. */
  unsigned char b[280];uint64_t hash=0;int k;assert(fread(b,1,280,f)==280);for(k=0;k<8;k++)hash|=(uint64_t)b[12+k]<<(8*k);rewind(f);
  assert(tp_project_read(f,&old,hash,(char*)b+24));assert(old.alpha==1&&!old.texture_path[0]);tp_doc_free(&old);fclose(f);
 }
 return 0;
}
