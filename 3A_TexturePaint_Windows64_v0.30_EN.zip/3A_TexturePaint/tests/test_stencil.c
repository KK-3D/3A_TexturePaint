#include "../src/tp_core.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
static int rounded(double x){return (int)(x*255+.5);}
int main(void){unsigned char image[16]={255,0,0,255,0,255,0,128,0,0,255,0,255,255,255,255};TPStencil s;double c[4];TPMesh m={0};TPDoc d={0},before={0};TPView v={0};TPBrush b={180,1,0,.8,{0,0,0}};TPRect rect={0};float*mask;unsigned char*once;int i,j,x,y;size_t n;double xy[4][2]={{20,180},{180,180},{180,20},{20,20}};int ids[2][3]={{0,1,2},{0,2,3}};
 assert(tp_stencil_place(image,2,2,400,200,.5,.5,1,&s));assert(s.left==150&&s.top==50&&s.display_width==100&&s.display_height==100);assert(tp_stencil_sample(&s,175,75,c)&&c[0]==1&&c[3]==1);assert(tp_stencil_sample(&s,225,75,c)&&c[1]==1&&fabs(c[3]-128/255.0)<1e-12);assert(!tp_stencil_sample(&s,175,125,c));assert(!tp_stencil_sample(&s,149,75,c)&&!tp_stencil_sample(&s,250,75,c));
 /* Forward display transform and inverse sampling agree under rotation. */
 {double point[2];s.rotation_cos=0;s.rotation_sin=1;tp_stencil_point(&s,-25,-25,point);
 assert(point[0]==225&&point[1]==75);assert(tp_stencil_sample(&s,point[0],point[1],c)&&c[0]==1&&c[3]==1);
 s.rotation_cos=cos(.73);s.rotation_sin=sin(.73);tp_stencil_point(&s,25,-25,point);
 assert(tp_stencil_sample(&s,point[0],point[1],c)&&fabs(c[1]-1)<1e-12);
 s.rotation_cos=1;s.rotation_sin=0;}
 /* Transparent blue must not bleed into the interpolated red. */
 assert(tp_stencil_sample(&s,175,100,c)&&c[0]==1&&c[1]==0&&c[2]==0&&fabs(c[3]-.5)<1e-12);
 assert(tp_stencil_place(image,200,100,400,200,.25,.75,2,&s));assert(s.display_width==400&&s.display_height==200&&s.left==-100&&s.top==50);assert(!tp_stencil_place(image,2,2,0,200,.5,.5,1,&s));
 assert(tp_doc_init(&d,512,1,"UV"));d.active=2;assert(tp_doc_clone(&before,&d));n=(size_t)512*512;mask=calloc(n,sizeof(float));once=malloc(n*4);assert(mask&&once);m.count=4;m.tri=calloc(4,sizeof(TPTriangle));assert(m.tri);assert(tp_view_resize(&v,200,200));v.project_count=4;v.projected=calloc(12,sizeof(TPProjected));assert(v.projected);
 for(i=0;i<4;i++)for(j=0;j<3;j++){int k=ids[i%2][j];TPVertex*p=&m.tri[i].v[j];TPProjected*q=&v.projected[i*3+j];p->uv[0]=(xy[k][0]-20)/160*.5+(i<2?0:.5);p->uv[1]=1-(xy[k][1]-20)/160;q->x=xy[k][0];q->y=xy[k][1];q->w=1;q->z=i<2?-2:2;}
 assert(tp_render_projected(&v,&m,&d,NULL));s=(TPStencil){image,2,2,20,20,160,160,0,1};assert(tp_stamp_stencil(&m,&v,&d,&before,mask,&b,100,100,&rect,&s));assert(rect.valid);
 for(y=0;y<512;y++)for(x=0;x<512;x++){size_t at=((size_t)y*512+x)*4;unsigned char*p=d.layer[2].rgba+at;if(x>=256){assert(p[3]==0);continue;}if(tp_stencil_sample(&s,20+(x+.5)/256*160,20+(y+.5)/512*160,c)){assert(abs(p[3]-rounded(c[3]*b.strength))<=1);if(p[3])for(j=0;j<3;j++)assert(abs(p[j]-rounded(c[j]))<=1);}else assert(p[3]==0);}
 memcpy(once,d.layer[2].rgba,n*4);tp_stamp_stencil(&m,&v,&d,&before,mask,&b,100,100,&rect,&s);assert(!memcmp(once,d.layer[2].rgba,n*4));
 /* A smaller display clips transfer even when the brush covers the mesh. */
 memset(d.layer[2].rgba,0,n*4);memset(mask,0,n*sizeof(float));s.left=s.top=60;s.display_width=s.display_height=80;assert(tp_stamp_stencil(&m,&v,&d,&before,mask,&b,100,100,&rect,&s));for(y=0;y<512;y++)for(x=0;x<256;x++){double sx=20+(x+.5)/256*160,sy=20+(y+.5)/512*160;if(sx<60||sx>=140||sy<60||sy>=140)assert(d.layer[2].rgba[((size_t)y*512+x)*4+3]==0);}
 assert(!memcmp(d.layer[0].rgba,before.layer[0].rgba,n*4));free(once);free(mask);free(m.tri);tp_doc_free(&d);tp_doc_free(&before);tp_view_free(&v);puts("PASS: stencil layout/aspect, image orientation, premultiplied sampling, source alpha and strength, projection, occlusion, active layer, display clipping and stroke coverage.");return 0;
}
