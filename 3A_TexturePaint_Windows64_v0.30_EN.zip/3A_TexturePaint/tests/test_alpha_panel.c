/* Production embedded Numeric gallery with mocked Windows file/codec APIs. */
#include <lwserver.h>
#include <lwxpanel.h>
#include <lwhost.h>
#include "../src/tp_core.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <wchar.h>
#include <math.h>
#include <stdint.h>
typedef unsigned UINT;typedef unsigned DWORD;typedef void*HMODULE;typedef void*HANDLE;typedef const wchar_t*LPCWSTR;
#define MAX_PATH 260
#define CP_UTF8 65001
#define GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS 1
#define GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT 2
#define AFUNC_OK 0
#define CSIDL_LOCAL_APPDATA 0
#define SHGFP_TYPE_CURRENT 0
#define FAILED(x) ((x)<0)
#define ERROR_ALREADY_EXISTS 183
#define ERROR_FILE_NOT_FOUND 2
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)
#define FILE_ATTRIBUTE_DIRECTORY 16
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define ID_ALPHA_SELECT 123
#define ID_ALPHA_SCROLL 124
#define _stricmp strcasecmp
typedef struct {wchar_t cFileName[260];DWORD dwFileAttributes;} WIN32_FIND_DATAW;
typedef struct {GlobalFunc*global;LWXPanelFuncs*xp;int alpha_gallery_value,alpha_gallery_w,alpha_gallery_h,alpha_scroll_target,busy,painting,pending,adjusting,queued_action;char alpha_directory[1024];} Tool;
static struct {TPAlpha mask;unsigned char*data;int cursor_valid;char name[128];} brush_alpha;
static int decodes,fail_decode,draws,request_result=1,file_count=8,file_index,bad_directory;
static Tool*live;
static int GetModuleHandleExW(int flags,LPCWSTR addr,HMODULE*out){(void)flags;(void)addr;*out=(void*)1;return 1;}
static int GetModuleFileNameW(HMODULE m,wchar_t*out,int n){(void)m;(void)n;wcscpy(out,L"C:/plugin/3A_TexturePaint.p");out[2]=out[9]=92;return 1;}
static int WideCharToMultiByte(int cp,int f,const wchar_t*in,int len,char*out,int n,void*a,void*b){(void)cp;(void)f;(void)len;(void)a;(void)b;return wcstombs(out,in,(size_t)n)<(size_t)n;}
static int SHGetFolderPathW(void*a,int b,void*c,int d,wchar_t*out){(void)a;(void)b;(void)c;(void)d;wcscpy(out,L"/tmp");return 0;}
static int CreateDirectoryW(const wchar_t*p,void*x){(void)p;(void)x;return 1;}
static DWORD GetLastError(void){return ERROR_FILE_NOT_FOUND;}
static FILE*_wfopen(const wchar_t*p,const wchar_t*m){(void)p;(void)m;return NULL;}
static DWORD GetFileAttributesW(const wchar_t*p){(void)p;return bad_directory?INVALID_FILE_ATTRIBUTES:FILE_ATTRIBUTE_DIRECTORY;}
static void file_data(WIN32_FIND_DATAW*d){swprintf(d->cFileName,260,L"alpha%d.png",file_index);d->dwFileAttributes=0;}
static HANDLE FindFirstFileW(const wchar_t*p,WIN32_FIND_DATAW*d){(void)p;file_index=0;if(!file_count)return INVALID_HANDLE_VALUE;file_data(d);return (void*)1;}
static int FindNextFileW(HANDLE h,WIN32_FIND_DATAW*d){(void)h;if(++file_index>=file_count)return 0;file_data(d);return 1;}
static void FindClose(HANDLE h){(void)h;}
static int to_wide(const char*in,wchar_t*out){mbstowcs(out,in,MAX_PATH);return 1;}
static int image_dimensions(const wchar_t*p,UINT*w,UINT*h){(void)p;*w=4;*h=2;return 1;}
static int decode_image_rect(const wchar_t*p,int w,int h,unsigned char*out){int i;(void)p;decodes++;if(fail_decode)return 0;for(i=0;i<w*h;i++){out[4*i]=255;out[4*i+1]=out[4*i+2]=0;out[4*i+3]=128;}return 1;}
static void request_ui(Tool*t){(void)t;}
static void status(Tool*t,const char*s){(void)t;(void)s;}
static Tool*find_panel(LWXPanelID p){return p==(void*)1?live:NULL;}
static int is_live(void*t){return t==live;}
static void box(LWXPDrAreaID p,int r,int g,int b,int x,int y,int w,int h){(void)p;assert(x>=0&&y>=0&&x+w<=384&&y+h<=256);assert(w>0&&h>0);if(r==255&&g==140&&b==20)assert(w==1||h==1);else assert(r==g&&g==b);draws++;}
static int requester(int version,LWFileReqLocal*r){(void)version;r->result=request_result;strcpy(r->fullName,"custom.png");return AFUNC_OK;}
static void*global(const char*name,int mode){(void)name;(void)mode;return (void*)requester;}
#include "../src/brush_alpha.inc"
int main(void){LWXPDrawFuncs draw={0};LWXPanelFuncs xp={0};Tool t={0};unsigned char*old;int i,drag[4];live=&t;t.global=global;t.xp=&xp;t.alpha_gallery_w=384;t.alpha_gallery_h=256;xp.drawf=&draw;draw.drawRGBBox=box;
 assert(TP_THUMB_SIDE==551);
 default_alpha_directory();strcpy(t.alpha_directory,alpha_catalog.directory);file_count=11;refresh_alpha_catalog(&t);assert(alpha_catalog.count==11&&alpha_count(&t)==12);assert(!strcmp(alpha_name(&t,1),"alpha0.png"));
 assert(!strcmp(alpha_sizes[0],"Small")&&!strcmp(alpha_sizes[2],"Large"));
 for(i=0;i<3;i++){alpha_size=i;alpha_catalog.scroll=0;load_alpha_page(&t);
 assert(alpha_catalog.cell-8==(int)(2*(fmin((256.0*8/9)/alpha_columns(),128.0/alpha_rows())-8)));
 draws=0;alpha_gallery_draw((void*)1,0,(void*)1,384,256);assert(draws<384*256/3);
 t.queued_action=ID_ALPHA_SCROLL;alpha_gallery_click((void*)1,0,10,10,NULL,1);assert(alpha_catalog.selected==1&&t.queued_action==ID_ALPHA_SELECT);use_alpha_preset(&t);assert(brush_alpha.data);
 /* Drag the right rail to its bottom: last row must be reachable. */
 t.queued_action=0;drag[0]=drag[2]=378;drag[1]=10;drag[3]=255;alpha_gallery_click((void*)1,0,378,10,drag,1);assert(t.queued_action==ID_ALPHA_SCROLL&&t.alpha_scroll_target==alpha_catalog.max_scroll);
 alpha_catalog.scroll=t.alpha_scroll_target;load_alpha_page(&t);alpha_gallery_draw((void*)1,0,(void*)1,384,256);
 {int last=10,x=(last%alpha_catalog.cols)*alpha_catalog.cell+10,y=(last/alpha_catalog.cols)*alpha_catalog.cell-alpha_catalog.scroll+10;if(y<0)y=1;
 t.queued_action=0;alpha_gallery_click((void*)1,0,x,y,NULL,1);assert(alpha_catalog.selected==11&&t.queued_action==ID_ALPHA_SELECT);}
 t.queued_action=0;drag[1]=255;drag[3]=0;alpha_gallery_click((void*)1,0,378,255,drag,1);assert(t.alpha_scroll_target==0);
 }
 /* Resize while a click is pending: retain selection, update layout and load it. */
 t.queued_action=ID_ALPHA_SELECT;alpha_catalog.selected=1;t.alpha_gallery_w=300;
 alpha_gallery_draw((void*)1,0,(void*)1,384,256);
 assert(t.queued_action==ID_ALPHA_SELECT&&t.alpha_gallery_w==384);
 use_alpha_preset(&t);assert(alpha_catalog.thumb[0]);t.queued_action=0;
 /* Bilinear preview sampling preserves a smooth grey ramp at larger sizes. */
 {unsigned char*gradient=malloc(TP_THUMB_SIDE*TP_THUMB_SIDE);
 for(int y=0;y<TP_THUMB_SIDE;y++)for(int x=0;x<TP_THUMB_SIDE;x++)gradient[y*TP_THUMB_SIDE+x]=(unsigned char)(x*255/(TP_THUMB_SIDE-1));
 assert(alpha_thumb_value(gradient,128,128,256)>=127&&alpha_thumb_value(gradient,128,128,256)<=128);
 assert(alpha_thumb_value(gradient,256,256,512)>=127&&alpha_thumb_value(gradient,256,256,512)<=128);
 assert(alpha_thumb_value(gradient,0,0,512)==0);
 assert(alpha_thumb_value(gradient,550,550,551)==255);
 free(gradient);}
 /* Cache hits: moving within and revisiting cached rows decodes nothing. */
 {int before=decodes;alpha_catalog.scroll=0;load_alpha_page(&t);before=decodes;load_alpha_page(&t);assert(decodes==before);alpha_catalog.scroll=1;load_alpha_page(&t);assert(decodes==before);alpha_catalog.scroll=alpha_catalog.max_scroll;load_alpha_page(&t);before=decodes;alpha_catalog.scroll=0;load_alpha_page(&t);assert(decodes==before);}
 /* More than cache capacity: reuse/eviction must remain bounded and safe. */
 file_count=130;refresh_alpha_catalog(&t);{int k;for(k=0;k<130;k+=3){alpha_catalog.scroll=k*alpha_catalog.cell;load_alpha_page(&t);}alpha_catalog.scroll=0;load_alpha_page(&t);assert(alpha_catalog.thumb[0]);}
 file_count=11;refresh_alpha_catalog(&t);
 old=brush_alpha.data;fail_decode=1;select_brush_alpha(&t,"bad.png");assert(brush_alpha.data==old);fail_decode=0;
 bad_directory=1;refresh_alpha_catalog(&t);assert(alpha_catalog.count==11);bad_directory=0;file_count=0;refresh_alpha_catalog(&t);assert(alpha_catalog.max_scroll==0&&!alpha_catalog.thumb[0]);
 import_brush_alpha(&t);assert(!strcmp(brush_alpha.name,"custom.png"));request_result=0;old=brush_alpha.data;import_brush_alpha(&t);assert(old==brush_alpha.data);
 free_alpha_catalog();free(brush_alpha.data);puts("PASS: doubled gallery sizes, all scroll endpoints, post-scroll hit testing, empty directory and failed decode preservation.");return 0;
}
