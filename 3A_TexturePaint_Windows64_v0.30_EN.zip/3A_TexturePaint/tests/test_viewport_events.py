"""Exercise production cursor and painting event routing with a mocked Modeler host."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
src+='\n'+(Path(__file__).resolve().parents[1]/'src/stamp.inc').read_text()+'\n'+(Path(__file__).resolve().parents[1]/'src/stamp_controls.inc').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
typedef void* LWInstance;
#define LVVIEWT_TOP 1
#define LVVIEWT_PERSPECTIVE 7
#define LVVIEWT_UV 11
#define LWTOOLF_ALT 64
#define LWTOOLF_CTRL 32
#define LWTOOLF_SHIFT 128
#define LWTOOLF_ALT_BUTTON 8
#define LWT_TEST_UPDATE 1
#define LWT_TEST_NOTHING 0
#define LWT_EVENT_DROP 0
#define LWT_EVENT_RESET 1
#define LWT_EVENT_DEACTIVATE 4
#define LWT_EVENT_EXTERNAL_ACTION 3
typedef struct {int canundo;} Session;
typedef struct {int viewNumber,flags,dx;double posRaw[3];} LWToolEvent;
typedef struct {int numViewports;int(*type)(int);int(*hoverIndex)(double*);int(*project)(int,double*,double*,double*,double*);void(*rect)(int,int*,int*,int*,int*);} VP;
typedef struct {Session*s;VP*vp;int stamp_show;double stamp_x,stamp_y,stamp_scale,stamp_rotation,ink_start_scale,ink_start_rotation,ink_center[2],ink_start_distance,ink_start_angle,ink_start_x,ink_start_y,ink_pointer[2];int line_mode,mode,adjusting,adjust_dx,ui_pending,cursor_view,dirty,painting,pending,busy,queued_action,frameview,cache_valid,nav_suspended,released,update;double radius,strength,adjust_radius,adjust_strength,cursor_xy[2],mouse[2],start_mouse[2],last[2];} Tool;
static struct {unsigned char*rgba;int width,height;} stamp_asset;
static int hover=0,viewtype=1,saves,stamps,frameok=1;static double pointer[2]={20,30},painted[2],prior[2];
static int type(int n){return n==3?11:viewtype;}
static int hoverIndex(double*out){memcpy(out,pointer,sizeof(pointer));return hover;}
static int project(int n,double*p,double*x,double*y,double*z){(void)n;*x=p[0];*y=p[1];*z=0;return 1;}
static void rect(int n,int*l,int*top,int*w,int*h){*l=n*200;*top=0;*w=*h=200;}
static void finish_stroke(Tool*t){(void)t;saves++;}
static int autosave(Tool*t){(void)t;saves++;return 1;}
static void undo_action(Tool*t,int redo){(void)t;(void)redo;}
static void sync_ui(Tool*t){(void)t;}
static void request_ui(Tool*t){t->dirty=1;t->ui_pending=1;}
static void status(Tool*t,const char*s){(void)s;request_ui(t);}
static int matches(Tool*t){(void)t;return 1;}
static int native_frame(Tool*t,int n){if(!frameok)return 0;t->frameview=n;return 1;}
static void stamp_to(Tool*t,double x,double y){stamps++;memcpy(prior,t->last,sizeof(prior));painted[0]=x;painted[1]=y;t->last[0]=x;t->last[1]=y;}
static void redraw_line(Tool*t){if(!t->pending)stamp_to(t,t->mouse[0],t->mouse[1]);}
static void cancel_line(Tool*t){t->line_mode=t->painting=t->pending=0;t->update=LWT_TEST_NOTHING;}
''' 
tail=r'''
int main(void){VP vp={4,type,hoverIndex,project,rect};Tool t={0};LWToolEvent e={0};t.vp=&vp;t.cursor_view=-1;
 track(&t,&e);assert(t.cursor_view==0&&t.cursor_xy[0]==20&&t.dirty);
 assert(down(&t,&e));assert(t.pending&&t.frameview==0);t.pending=0;memcpy(t.last,t.mouse,sizeof(t.last));
 pointer[0]=60;pointer[1]=70;t.dirty=0;move(&t,&e);assert(stamps==1&&t.cursor_xy[0]==painted[0]&&t.cursor_xy[1]==painted[1]&&t.dirty);assert(prior[0]==20);
 /* Modeler may keep the mouse-down event viewport while hover has changed. */
 hover=1;pointer[0]=15;pointer[1]=25;move(&t,&e);assert(t.frameview==1&&t.cursor_view==1&&painted[0]==15&&prior[0]==15&&prior[1]==25);
 hover=-1;move(&t,&e);assert(stamps==2&&t.cursor_view==-1&&t.nav_suspended);
 hover=1;pointer[0]=150;move(&t,&e);assert(stamps==3&&prior[0]==150);
 hover=3;pointer[0]=45;move(&t,&e);assert(t.frameview==3&&t.cursor_view==3&&prior[0]==45);
 frameok=0;hover=2;move(&t,&e);assert(stamps==4&&t.nav_suspended);frameok=1;pointer[0]=65;move(&t,&e);assert(stamps==5&&prior[0]==65);
 e.flags=LWTOOLF_ALT;move(&t,&e);assert(!t.painting&&saves==1);assert(!down(&t,&e));e.flags=0;
 pointer[0]=201;assert(!down(&t,&e));pointer[0]=10;assert(down(&t,&e));hover=0;pointer[0]=90;move(&t,&e);assert(t.pending&&t.frameview==0&&t.start_mouse[0]==90);up(&t,&e);assert(t.released&&saves==1);
 vp.hoverIndex=NULL;e.viewNumber=2;e.posRaw[0]=30;e.posRaw[1]=40;track(&t,&e);assert(t.cursor_view==2&&t.cursor_xy[1]==40);
 /* RMB never starts a paint stroke, mesh edit, Undo checkpoint or save. */
 t.painting=t.pending=t.released=t.update=0;t.radius=30;t.strength=.25;vp.hoverIndex=hoverIndex;hover=0;pointer[0]=50;pointer[1]=50;e.flags=LWTOOLF_ALT_BUTTON;e.dx=10;
 {int old_stamps=stamps,old_saves=saves;assert(down(&t,&e)&&t.adjusting==1&&!t.painting&&!t.pending&&!t.update);pointer[0]=130;pointer[1]=100;hover=2;e.dx=50;move(&t,&e);assert(t.cursor_view==0&&t.cursor_xy[0]==50&&t.cursor_xy[1]==50);hover=-1;track(&t,&e);assert(t.cursor_view==0&&t.cursor_xy[0]==50);assert(t.radius==50&&t.strength==.25&&t.ui_pending);e.dx=70;up(&t,&e);assert(!t.adjusting&&t.radius==60&&stamps==old_stamps&&saves==old_saves);
 hover=0;pointer[0]=50;pointer[1]=50;track(&t,&e);e.flags=LWTOOLF_ALT_BUTTON|LWTOOLF_SHIFT;e.dx=0;assert(down(&t,&e)&&t.adjusting==2);pointer[0]=170;pointer[1]=120;hover=3;e.dx=100;move(&t,&e);track(&t,&e);assert(t.cursor_view==0&&t.cursor_xy[0]==50&&t.cursor_xy[1]==50);assert(t.strength==.75&&t.radius==60);e.flags=LWTOOLF_ALT_BUTTON;e.dx=1000;move(&t,&e);assert(t.strength==1);e.dx=-1000;move(&t,&e);assert(t.strength==0);up(&t,&e);assert(!t.adjusting&&stamps==old_stamps&&saves==old_saves);
 track(&t,&e);assert(t.cursor_view==3&&t.cursor_xy[0]==170&&t.cursor_xy[1]==120);e.dx=0;assert(down(&t,&e));e.dx=1000;move(&t,&e);assert(t.radius==180);e.dx=-1000;move(&t,&e);assert(t.radius==1);up(&t,&e);assert(stamps==old_stamps&&saves==old_saves);e.flags=LWTOOLF_ALT_BUTTON|LWTOOLF_ALT;assert(!down(&t,&e));e.flags=LWTOOLF_ALT_BUTTON|LWTOOLF_CTRL;assert(!down(&t,&e));}
 e.flags=LWTOOLF_ALT_BUTTON;e.dx=0;t.radius=50;assert(down(&t,&e));e.dx=30;move(&t,&e);assert(t.radius==65);event(&t,LWT_EVENT_RESET);assert(t.radius==50&&!t.adjusting);
 t.mode=TP_MODE_INK;stamp_asset.rgba=NULL;e.flags=0;assert(!down(&t,&e)&&!t.painting);t.mode=0;
 /* Actual Ink controls consume LMB without painting or saves. */
 {unsigned char source[4]={255,0,0,255};int old_saves=saves,old_stamps=stamps;
 stamp_asset.rgba=source;stamp_asset.width=stamp_asset.height=1;t.mode=TP_MODE_INK;t.stamp_show=1;
 t.stamp_x=t.stamp_y=.5;t.stamp_scale=1;t.stamp_rotation=0;hover=0;
 pointer[0]=100;pointer[1]=50;e.flags=0;assert(down(&t,&e)&&t.adjusting==3&&!t.painting&&!t.pending);
 pointer[1]=-1;move(&t,&e);assert(t.stamp_scale==1); /* outside viewport ignored */
 pointer[1]=25;move(&t,&e);assert(fabs(t.stamp_scale-1.5)<1e-9);up(&t,&e);assert(!t.adjusting);
 t.stamp_scale=1;pointer[0]=150;pointer[1]=100;assert(down(&t,&e)&&t.adjusting==4);
 pointer[0]=100;pointer[1]=50;move(&t,&e);assert(fabs(t.stamp_rotation+90)<1e-9);
 event(&t,LWT_EVENT_RESET);assert(t.stamp_rotation==0&&!t.adjusting);
 pointer[0]=150;pointer[1]=100;assert(down(&t,&e));pointer[0]=100;pointer[1]=150;up(&t,&e);assert(fabs(t.stamp_rotation-90)<1e-9&&!t.adjusting);
 pointer[0]=100;pointer[1]=100;assert(down(&t,&e)&&t.adjusting==5);
 pointer[0]=140;pointer[1]=130;move(&t,&e);assert(fabs(t.stamp_x-.7)<1e-9&&fabs(t.stamp_y-.65)<1e-9);
 event(&t,LWT_EVENT_RESET);assert(t.stamp_x==.5&&t.stamp_y==.5&&!t.adjusting);
 pointer[0]=100;pointer[1]=100;assert(down(&t,&e));pointer[0]=60;pointer[1]=80;up(&t,&e);
 assert(fabs(t.stamp_x-.3)<1e-9&&fabs(t.stamp_y-.4)<1e-9&&!t.adjusting);
 assert(saves==old_saves&&stamps==old_stamps);
 t.stamp_show=0;pointer[0]=100;pointer[1]=50;assert(down(&t,&e)&&t.painting&&t.pending);t.painting=t.pending=0;
 }
 t.mode=TP_MODE_FILL;e.flags=0;assert(down(&t,&e)&&t.pending);t.pending=0;
 {int old_stamps=stamps;move(&t,&e);up(&t,&e);assert(stamps==old_stamps&&!t.painting);}
 /* Shift-LMB starts a stroke immediately and updates during the drag. */
 {int old_stamps=stamps,old_saves=saves;
 t.painting=t.pending=t.update=0;t.mode=TP_MODE_PAINT;e.flags=LWTOOLF_SHIFT;hover=0;
 pointer[0]=80;pointer[1]=80;assert(down(&t,&e)&&t.line_mode&&t.pending&&t.update==LWT_TEST_UPDATE);
 t.pending=0; /* host build has initialized the stroke */
 pointer[0]=120;pointer[1]=87;move(&t,&e);assert(stamps>old_stamps);assert(fabs(t.mouse[0]-120)<1e-9&&fabs(t.mouse[1]-80)<1e-9);
 pointer[0]=120;pointer[1]=120;move(&t,&e);assert(fabs(t.mouse[0]-120)<1e-9&&fabs(t.mouse[1]-120)<1e-9);
 pointer[0]=20;pointer[1]=85;move(&t,&e);assert(fabs(t.mouse[0]-20)<1e-9&&fabs(t.mouse[1]-80)<1e-9);
 pointer[0]=86;pointer[1]=130;move(&t,&e);assert(fabs(t.mouse[0]-80)<1e-9&&fabs(t.mouse[1]-130)<1e-9);
 hover=1;pointer[0]=150;move(&t,&e);assert(fabs(t.mouse[0]-80)<1e-9&&t.cursor_view==0);hover=0;
 pointer[0]=120;pointer[1]=120;up(&t,&e);assert(!t.line_mode&&!t.pending&&!t.painting&&t.released);
 assert(stamps>old_stamps&&saves==old_saves+1);old_stamps=stamps;t.painting=t.pending=t.update=0;
 pointer[0]=80;pointer[1]=80;assert(down(&t,&e));event(&t,LWT_EVENT_RESET);assert(!t.line_mode&&!t.painting&&!t.pending&&stamps==old_stamps);
 assert(down(&t,&e));e.flags=0;pointer[0]=120;pointer[1]=87;move(&t,&e);assert(t.mouse[0]==120&&t.mouse[1]==87);
 e.flags=LWTOOLF_CTRL;up(&t,&e);assert(!t.line_mode&&!t.pending&&!t.painting&&stamps==old_stamps);
 }
 puts("PASS: drag cursor/brush agreement, stale event viewport, cross-viewport strokes, no bridge after leaving, UV view, navigation, pending events, RMB radius and Shift+RMB strength (limits, live UI, reset cancellation, zero paint/save side effects).");return 0;}
''' 
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'events.c';out=Path(d)/'events'
    c.write_text('#include "'+str(Path(__file__).resolve().parents[1]/'src/tp_core.h')+'"\n'+head+'\n'.join(function(n) for n in ['bound','paint_view','sample_position','stencil_layout','begin_stamp_control','adjust_stamp','update_cursor','adjust_brush','down','update_line','move','up','track','event'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',str(c),str(Path(__file__).resolve().parents[1]/'src/tp_core.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
