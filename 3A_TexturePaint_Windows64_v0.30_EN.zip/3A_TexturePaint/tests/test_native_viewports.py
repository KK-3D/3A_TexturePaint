"""Test production native_frame with host-style 3D and UV viewport matrices."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include "tp_core.h"
#include <lwviewportinfo.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
typedef struct {TPView cache;TPDoc doc;TPMesh mesh;} Session;
typedef struct {Session*s;LWViewportInfo*vp;int cache_valid,cache_type,frameview;LWDMatrix4 last_mv,last_proj;} Tool;
static int types[4]={1,7,7,11};static int project_calls;
static int type(int n){return types[n];}
static void rect(int n,int*l,int*t,int*w,int*h){*l=n*200;*t=0;*w=*h=200;}
static void identity(LWDMatrix4 m){int j;memset(m,0,sizeof(LWDMatrix4));for(j=0;j<4;j++)m[j][j]=1;}
static int mv(int n,LWDMatrix4 m,LWDMatrix4 inv){(void)inv;identity(m);if(n==1){m[0][0]=m[1][1]=0;m[1][0]=-1;m[0][1]=1;}if(n==2)m[3][2]=-3;return 1;}
static int proj(int n,LWDMatrix4 m,LWDMatrix4 inv){(void)inv;identity(m);if(n==2){m[2][2]=-1;m[3][2]=-1;m[2][3]=-1;m[3][3]=0;}if(n==3){m[0][0]=m[1][1]=2;m[3][0]=m[3][1]=-1;}return 1;}
static int project(int n,LWDVector point,double*x,double*y,double*z){LWDMatrix4 a,b;double in[4]={point[0],point[1],point[2],1},eye[4]={0},clip[4]={0};int k,j;mv(n,a,NULL);proj(n,b,NULL);for(j=0;j<4;j++)for(k=0;k<4;k++)eye[j]+=a[k][j]*in[k];for(j=0;j<4;j++)for(k=0;k<4;k++)clip[j]+=b[k][j]*eye[k];*x=(clip[0]/clip[3]+1)*100;*y=(1-clip[1]/clip[3])*100;*z=(clip[2]/clip[3]+1)/2;project_calls++;return 1;}
''' 
tail=r'''
int main(void){Session s={0};Tool t={0};LWViewportInfo vp={0};TPDoc before={0};TPBrush brush={12,1,0,1,{255,0,0}};float*coverage;int n,j;double uv[3][2]={{0,0},{1,0},{0,1}};vp.numViewports=4;vp.type=type;vp.rect=rect;vp.modelview=mv;vp.projection=proj;vp.project=project;t.s=&s;t.vp=&vp;s.mesh.count=1;s.mesh.tri=calloc(1,sizeof(TPTriangle));assert(s.mesh.tri);for(j=0;j<3;j++){s.mesh.tri[0].v[j].uv[0]=uv[j][0];s.mesh.tri[0].v[j].uv[1]=uv[j][1];s.mesh.tri[0].v[j].p[0]=uv[j][0]*1.5-.75;s.mesh.tri[0].v[j].p[1]=uv[j][1]*1.5-.75;}assert(tp_doc_init(&s.doc,512,1,"UV"));assert(tp_doc_clone(&before,&s.doc));coverage=calloc(512*512,sizeof(float));assert(coverage);
 for(n=0;n<4;n++){double x=0,y=0;size_t at=(size_t)341*512+170;memset(coverage,0,512*512*sizeof(float));memset(s.doc.layer[0].rgba,0,512*512*4);assert(native_frame(&t,n));for(j=0;j<3;j++){x+=s.cache.projected[j].x/3;y+=s.cache.projected[j].y/3;}assert(tp_stamp(&s.mesh,&s.cache,&s.doc,&before,coverage,&brush,x,y));assert(s.doc.layer[0].rgba[at*4+3]>0);assert(t.frameview==n&&t.cache_type==types[n]);}
 assert(s.cache.projected[0].x==0&&s.cache.projected[0].y==200);j=project_calls;assert(native_frame(&t,3)&&project_calls==j);types[3]=1;assert(native_frame(&t,3)&&project_calls>j);assert(s.cache.projected[0].x!=0);
 assert(!native_frame(&t,-1)&&!native_frame(&t,4));free(coverage);free(s.mesh.tri);tp_view_free(&s.cache);tp_doc_free(&s.doc);tp_doc_free(&before);puts("PASS: production viewport projection and painting in orthographic, rotated, perspective and native UV views; cache refresh after view type changes.");return 0;}
''' 
root=Path(__file__).resolve().parents[1]
sdk=os.environ.get('LWSDK_INCLUDE','/tmp/lwsdk/include')
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'frame.c';out=Path(d)/'frame'
    c.write_text(head+'\n'.join(function(n) for n in ['paint_view','native_frame'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+sdk,'-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
