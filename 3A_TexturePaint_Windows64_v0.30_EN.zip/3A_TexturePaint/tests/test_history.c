#include "../src/tp_history.h"
#include <assert.h>
#include <string.h>
int main(void){
 TPDoc d={0},b={0};TPHistory h={0};int i;assert(tp_doc_init(&d,512,123,"UV"));
 for(i=1;i<=40;i++){tp_doc_free(&b);assert(tp_doc_clone(&b,&d));d.layer[2].rgba[0]=(unsigned char)i;d.layer[2].rgba[3]=255;d.layer[2].opacity=i/40.;assert(tp_history_commit(&h,&b,&d,1u<<2,32)==1);}
 assert(h.count==32&&h.cursor==32);
 for(i=39;i>=8;i--){assert(tp_history_step(&h,&d,0));assert(d.layer[2].rgba[0]==i);}
 assert(!tp_history_step(&h,&d,0));
 for(i=9;i<=40;i++){assert(tp_history_step(&h,&d,1));assert(d.layer[2].rgba[0]==i);assert(d.layer[2].opacity==i/40.);}
 assert(!tp_history_step(&h,&d,1));
 assert(tp_history_step(&h,&d,0));assert(tp_history_step(&h,&d,0));
 /* No-op preserves Redo; a new edit discards the redo branch. */
 assert(tp_history_commit(&h,&d,&d,255,32)==0&&h.cursor==30&&h.count==32);
 tp_doc_free(&b);assert(tp_doc_clone(&b,&d));strcpy(d.layer[0].name,"Renamed");assert(tp_history_commit(&h,&b,&d,0,32)==1&&h.cursor==31&&h.count==31);
 assert(tp_history_step(&h,&d,0)&&strcmp(d.layer[0].name,"Renamed"));assert(tp_history_step(&h,&d,1)&&!strcmp(d.layer[0].name,"Renamed"));
 tp_history_limit(&h,3);assert(h.count==3&&h.cursor==3);
 /* Truncated/corrupt entry is rejected before touching document pixels. */
 rewind(h.entry[2]);fputc(0,h.entry[2]);fputc(0,h.entry[2]);fflush(h.entry[2]);
 assert(!tp_history_step(&h,&d,0)&&h.cursor==3&&d.layer[2].rgba[0]==38);
 tp_history_free(&h);tp_doc_free(&d);tp_doc_free(&b);
 puts("PASS: 32-step Undo/Redo, limit trimming, metadata, branch replacement, no-op and corrupt-history protection.");
 return 0;
}
