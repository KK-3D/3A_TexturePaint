#include "../src/tp_core.c"
#include <assert.h>
#include <stdio.h>
int main(void){TPView v={0};TPSpatialIter it;size_t id,n=0;const int side=1000;
 v.project_count=2000000;v.projected=calloc(v.project_count*3,sizeof(TPProjected));assert(v.projected);
 for(size_t i=0;i<v.project_count;i++)for(int j=0;j<3;j++){TPProjected*q=&v.projected[i*3+j];q->x=(i/2)%side+(j==1);q->y=(i/2)/side+(j==2);q->z=1;q->w=1;}
 spatial_build(&v);assert(v.spatial_count);spatial_begin(&it,500,500,3);
 unsigned char*seen=calloc(v.project_count,1);assert(seen);
 while(spatial_next(&v,&it,&id)){assert(id<v.project_count);assert(!seen[id]);seen[id]=1;n++;}
 for(size_t i=0;i<v.project_count;i++){TPProjected*q=v.projected+i*3;if(q->x<=503&&q->x+1>=497&&q->y<=503&&q->y+1>=497)assert(seen[i]);}
 printf("2,000,000 triangles: %zu candidates for a radius-3 query\n",n);assert(n<1000);free(seen);
 /* Exercise actual rendering and texture painting on the dense geometry. */
 {TPMesh m={0};TPDoc d={0},before={0};TPBrush brush={12,1,0,1,{255,0,0}};TPRect dirty={0};
 m.count=m.capacity=v.project_count;m.tri=calloc(m.count,sizeof(TPTriangle));assert(m.tri);
 for(size_t i=0;i<m.count;i++)for(int j=0;j<3;j++){m.tri[i].v[j].uv[0]=v.projected[i*3+j].x/side;m.tri[i].v[j].uv[1]=1-v.projected[i*3+j].y/side;}
 assert(tp_view_resize(&v,1000,1000));assert(tp_doc_init(&d,512,1,"UV"));assert(tp_doc_clone(&before,&d));
 float*mask=calloc(512*512,sizeof(float));assert(mask);assert(tp_render_projected(&v,&m,&d,NULL));
 assert(tp_stamp_masked(&m,&v,&d,&before,mask,&brush,500,500,&dirty,NULL,NULL));
 free(mask);free(m.tri);tp_doc_free(&d);tp_doc_free(&before);puts("PASS: render and paint on 2,000,000 triangles.");}
 /* Identical centroids must terminate; non-finite projections are excluded. */
 v.project_count=10000;for(size_t i=0;i<v.project_count*3;i++){v.projected[i].x=1;v.projected[i].y=1;}
 v.projected[0].x=NAN;v.projected[3].y=INFINITY;spatial_build(&v);n=0;spatial_begin(&it,1,1,1);
 while(spatial_next(&v,&it,&id)){assert(id>=2);n++;}assert(n==9998);
 tp_view_free(&v);puts("PASS: dense index, complete candidate coverage, duplicate centroids, invalid projections.");return 0;
}
