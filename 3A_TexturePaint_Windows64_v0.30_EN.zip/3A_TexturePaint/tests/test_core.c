#include "../src/tp_core.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static TPTriangle triangle(double ax,double ay,double bx,double by,double cx,double cy,double z,double au,double av,double bu,double bv,double cu,double cv){TPTriangle t={{{{ax,ay,z},{au,av}},{{bx,by,z},{bu,bv}},{{cx,cy,z},{cu,cv}}}};return t;}
static size_t count_region(const TPDoc*d,int l,double u0,double u1,double v0,double v1){int x,y;size_t n=0;for(y=0;y<d->size;y++)for(x=0;x<d->size;x++){double u=(x+.5)/d->size,v=1-(y+.5)/d->size;if(u>u0&&u<u1&&v>v0&&v<v1&&d->layer[l].rgba[((size_t)y*d->size+x)*4+3])n++;}return n;}
static void snapshot(TPDoc*before,const TPDoc*d,float*mask){tp_doc_free(before);assert(tp_doc_clone(before,d));memset(mask,0,(size_t)d->size*d->size*sizeof(float));}
int main(int argc,char**argv){TPMesh mesh={0};TPDoc doc={0},before={0},loaded={0};TPView view={0};TPBrush brush={32,1,0,1,{255,0,0}};float*mask;unsigned char*rgba,*screen;size_t n,i,at=0;FILE*f;uint64_t hash;const char*prefix=argc>1?argv[1]:"/tmp/tpuv";char path[512];
 mesh.count=4;mesh.tri=calloc(mesh.count,sizeof(TPTriangle));strcpy(mesh.uvname,"PaintUV");
 mesh.tri[0]=triangle(-1,-1,1,-1,1,1,0,.05,.05,.45,.05,.45,.45);
 mesh.tri[1]=triangle(-1,-1,1,1,-1,1,0,.55,.55,.95,.95,.55,.95);
 /* A second surface just 0.001 units behind must not be painted. */
 mesh.tri[2]=triangle(-1,-1,1,-1,1,1,-.001,.05,.55,.45,.55,.45,.95);
 mesh.tri[3]=triangle(-1,-1,1,1,-1,1,-.001,.05,.55,.45,.95,.05,.95);
 assert(tp_mesh_finish(&mesh));hash=mesh.hash;assert(tp_mesh_finish(&mesh)&&mesh.hash==hash);
 assert(tp_doc_init(&doc,512,mesh.hash,mesh.uvname));n=(size_t)doc.size*doc.size;mask=calloc(n,sizeof(float));rgba=malloc(n*4);view.distance=3;assert(tp_view_resize(&view,600,500));
 tp_composite(&doc,rgba);assert(tp_render(&view,&mesh,&doc,rgba));snapshot(&before,&doc,mask);
 assert(tp_stamp(&mesh,&view,&doc,&before,mask,&brush,300,250));assert(count_region(&doc,0,0,.5,0,.5)>100);assert(count_region(&doc,0,.5,1,.5,1)>100);assert(count_region(&doc,0,0,.5,.5,1)==0);
 for(i=0;i<n;i++)if(doc.layer[0].rgba[i*4+3]==255){at=i;break;}
 assert(at);
 assert(!tp_stamp(&mesh,&view,&doc,&before,mask,&brush,300,250));
 doc.active=1;brush.color[0]=0;brush.color[2]=255;snapshot(&before,&doc,mask);assert(tp_stamp(&mesh,&view,&doc,&before,mask,&brush,300,250));tp_composite(&doc,rgba);assert(rgba[4*at+2]==255&&rgba[4*at]==0);
 brush.erase=1;brush.strength=.5;snapshot(&before,&doc,mask);assert(tp_stamp(&mesh,&view,&doc,&before,mask,&brush,300,250));tp_composite(&doc,rgba);assert(abs(rgba[4*at]-127)<=1&&abs(rgba[4*at+2]-128)<=1&&rgba[4*at+3]==255);
 doc.layer[1].visible=0;tp_composite(&doc,rgba);assert(rgba[at*4]==255&&rgba[at*4+2]==0);doc.layer[1].visible=1;doc.layer[1].opacity=.25;tp_composite(&doc,rgba);assert(abs(rgba[at*4+2]-32)<=1);doc.layer[1].opacity=1;
 {TPLayer tmp=doc.layer[0];doc.layer[0]=doc.layer[1];doc.layer[1]=tmp;tp_composite(&doc,rgba);assert(rgba[at*4]==255&&rgba[at*4+2]==0);tmp=doc.layer[0];doc.layer[0]=doc.layer[1];doc.layer[1]=tmp;}
 strcpy(doc.layer[1].name,"Azul - camada superior");f=tmpfile();assert(f&&tp_project_write(f,&doc));rewind(f);assert(tp_project_read(f,&loaded,mesh.hash,mesh.uvname));assert(loaded.active==doc.active&&!strcmp(loaded.layer[1].name,doc.layer[1].name));for(i=0;i<TP_LAYERS;i++)assert(!memcmp(doc.layer[i].rgba,loaded.layer[i].rgba,n*4));tp_doc_free(&loaded);rewind(f);assert(!tp_project_read(f,&loaded,mesh.hash+1,mesh.uvname));rewind(f);assert(!tp_project_read(f,&loaded,mesh.hash,"WrongUV"));fseek(f,0,SEEK_END);fputc(1,f);rewind(f);assert(!tp_project_read(f,&loaded,mesh.hash,mesh.uvname));fclose(f);
 f=tmpfile();assert(f);fwrite("TPUV0001",1,8,f);rewind(f);assert(!tp_project_read(f,&loaded,mesh.hash,mesh.uvname));fclose(f);
 /* Image-space brush also paints outside UV islands. */
 view.uv_mode=1;assert(tp_render(&view,&mesh,&doc,rgba));doc.active=2;brush.erase=0;brush.strength=1;brush.hard=0;brush.color[0]=0;brush.color[1]=255;brush.color[2]=0;snapshot(&before,&doc,mask);assert(tp_stamp(&mesh,&view,&doc,&before,mask,&brush,400,350));assert(count_region(&doc,2,.5,1,0,.5)>0);
 /* Outside canvas and unhit areas do not modify pixels. */
 assert(!tp_stamp(&mesh,&view,&doc,&before,mask,&brush,-1000,-1000));
 view.uv_mode=0;view.yaw=.3;view.pitch=.2;tp_composite(&doc,rgba);assert(tp_render(&view,&mesh,&doc,rgba));
 snprintf(path,sizeof(path),"%s_texture.png",prefix);f=fopen(path,"wb");assert(f&&tp_png(f,rgba,doc.size,doc.size));fclose(f);
 snprintf(path,sizeof(path),"%s_layers.tpaint",prefix);f=fopen(path,"wb");assert(f&&tp_project_write(f,&doc));fclose(f);
 screen=malloc((size_t)view.w*view.h*4);for(i=0;i<(size_t)view.w*view.h;i++){uint32_t c=view.bgra[i];screen[i*4]=(unsigned char)(c>>16);screen[i*4+1]=(unsigned char)(c>>8);screen[i*4+2]=(unsigned char)c;screen[i*4+3]=255;}
 snprintf(path,sizeof(path),"%s_render.png",prefix);f=fopen(path,"wb");assert(f&&tp_png(f,screen,view.w,view.h));fclose(f);free(screen);
 /* Reject malformed UVs and unsupported dimensions. */
 assert(!tp_doc_init(&loaded,123,0,"UV"));mesh.tri[0].v[0].uv[0]=2;assert(!tp_mesh_finish(&mesh));mesh.tri[0].v[0].uv[0]=NAN;assert(!tp_mesh_finish(&mesh));
 free(mask);free(rgba);free(mesh.tri);tp_doc_free(&doc);tp_doc_free(&before);tp_view_free(&view);
 puts("PASS: UV seam brush, thin-surface occlusion, per-stroke coverage, RGBA layers, eraser, visibility, opacity, order, project round-trip/rejection, 2D brush, PNG and invalid UVs.");return 0;
}
