"""Exercise the production texture import workflow with mocked host/Windows image services."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include "tp_core.h"
#include "tp_history.h"
#include <lwserver.h>
#include <lwhost.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <wchar.h>
#include <stdio.h>
#define MAX_PATH 260
#define INVALID_FILE_ATTRIBUTES (~0u)
#define _stricmp strcasecmp
typedef unsigned UINT;
typedef unsigned long long ULONGLONG;
typedef struct {TPDoc doc,undo;TPHistory history;TPMesh mesh;TPView cache;unsigned char*composite,*preview_rgb;float*coverage;char object[1024],layer_key[256],project[1024],png[1024],import_path[1024],open_path[1024];int valid,canundo,canredo,modified,image_modified,preview_size;unsigned undo_dirty;TPRect coverage_rect;ULONGLONG last_save;} Session;
typedef struct {Session*s;GlobalFunc*global;LWMessageFuncs*messages;int resolution,cache_valid,alpha;} Tool;
static int auto_save_image=1,accept=1,probe_ok=1,decode_ok=1,paths_ok=1,fail_write=0,writes=0,images=0,projects=0,refreshes=0,request_result=1,request_error=0,request_available=1,match=1,confirms=0;static UINT width=512,height=512;static char last_status[512];
static ULONGLONG GetTickCount64(void){return 100;}
static int matches(Tool*t){(void)t;return match;}
static void status(Tool*t,const char*s){(void)t;snprintf(last_status,sizeof(last_status),"%s",s);}
static void sync_ui(Tool*t){(void)t;}
static void composite(Tool*t){tp_composite(&t->s->doc,t->s->composite);}
static int to_wide(const char*p,wchar_t*out){return mbstowcs(out,p,MAX_PATH)<MAX_PATH;}
static unsigned GetFileAttributesW(const wchar_t*p){(void)p;return INVALID_FILE_ATTRIBUTES;}
static int default_paths(Session*s){strcpy(s->project,"C:\\work\\new.tpaint");strcpy(s->png,"C:\\work\\new.png");return paths_ok;}
static int image_dimensions(const wchar_t*p,UINT*w,UINT*h){(void)p;*w=width;*h=height;return probe_ok;}
static int decode_image(const wchar_t*p,int size,unsigned char*out){size_t i;(void)p;if(!decode_ok)return 0;for(i=0;i<(size_t)size*size;i++){out[i*4]=(unsigned char)(i%256);out[i*4+1]=30;out[i*4+2]=90;out[i*4+3]=i%2?128:255;}return 1;}
static int atomic_file(Session*s,const char*name,int project){(void)s;assert(strcmp(name,"C:\\source.png"));writes++;if(project)projects++;else images++;return !fail_write||writes!=fail_write;}
static int refresh_image(Tool*t){(void)t;refreshes++;return 1;}
static int yesno(const char*a,const char*b,const char*c){assert(a&&b&&c);confirms++;return accept;}
static int request(int version,LWFileReqLocal*r){assert(version==LWFILEREQ_VERSION&&r->reqType==FREQ_LOAD&&!strcmp(r->fileType,"Images"));strcpy(r->fullName,"C:\\source.png");r->result=request_result;return request_error;}
static void* global(const char*name,int mode){(void)mode;assert(!strcmp(name,LWFILEACTIVATEFUNC_GLOBAL));return request_available?(void*)request:NULL;}
'''
tail=r'''
static void initial(Session*s){memset(s,0,sizeof(*s));assert(tp_doc_init(&s->doc,512,123,"UV"));assert(texture_buffers(s,512));s->mesh.tri=calloc(1,sizeof(TPTriangle));assert(s->mesh.tri);s->mesh.count=1;s->mesh.hash=123;strcpy(s->mesh.uvname,"UV");strcpy(s->object,"object");strcpy(s->layer_key,"1");strcpy(s->project,"C:\\work\\old.tpaint");strcpy(s->doc.texture_path,"C:\\source.png");s->valid=1;s->modified=s->image_modified=1;s->doc.layer[0].rgba[0]=77;}
int main(void){Session s={0};LWMessageFuncs msg={0};Tool t={0};unsigned char*original;TPTriangle*mesh;msg.yesNo=yesno;t.s=&s;t.global=global;t.messages=&msg;initial(&s);original=s.doc.layer[0].rgba;mesh=s.mesh.tri;
 assert(import_texture_size(512,512,3)==512);assert(import_texture_size(8192,8192,0)==8192);assert(import_texture_size(2048,2048,3)==2048);assert(import_texture_size(1500,1000,2)==4096);assert(import_texture_size(1500,1000,8)==0);
 accept=0;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes);accept=1;probe_ok=0;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes);probe_ok=1;
 decode_ok=0;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes&&s.mesh.tri==mesh);decode_ok=1;
 paths_ok=0;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes);paths_ok=1;
 fail_write=1;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&s.doc.layer[0].rgba[0]==77&&s.mesh.tri==mesh);writes=images=projects=0;fail_write=3;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&s.mesh.tri==mesh);writes=images=projects=0;fail_write=0;
 auto_save_image=0;choose_texture_image(&t);assert(s.doc.size==512&&s.doc.active==1&&s.doc.alpha==1);assert(s.mesh.tri==mesh&&s.valid&&s.image_modified&&!s.modified);assert(!strcmp(s.doc.layer[0].name,"Imported Image")&&!strcmp(s.doc.layer[1].name,"Paint"));assert(s.doc.layer[0].rgba[7]==128&&s.doc.layer[1].rgba[7]==0);assert(s.composite[7]==128);assert(!strcmp(s.doc.texture_path,"C:\\work\\new.png"));assert(projects==2&&images==0&&refreshes==0);free_session(&s);
 initial(&s);auto_save_image=1;writes=images=projects=0;choose_texture_image(&t);assert(projects==2&&images==1&&refreshes==1&&!s.image_modified);free_session(&s);
 initial(&s);original=s.doc.layer[0].rgba;writes=images=projects=0;request_result=0;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes);request_result=1;request_error=1;choose_texture_image(&t);assert(s.doc.layer[0].rgba==original&&!writes);request_error=0;request_available=0;choose_texture_image(&t);assert(!writes);request_available=1;match=0;choose_texture_image(&t);assert(!writes);match=1;
 width=640;height=480;accept=0;confirms=0;choose_texture_image(&t);assert(confirms==1&&!writes);accept=1;t.resolution=0;choose_texture_image(&t);assert(s.doc.size==1024&&confirms==3);free_session(&s);
 puts("PASS: native requester cancel/error, source preservation, native size and explicit resampling, imported RGBA base/empty paint layer, mesh ownership, failure rollback and manual/auto PNG policy.");return 0;}
'''

root=Path(__file__).resolve().parents[1]
sdk=os.environ.get('LWSDK_INCLUDE','/tmp/lwsdk/include')
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'import.c';out=Path(d)/'import'
    c.write_text(head+'\n'.join(function(n) for n in ['free_session','texture_buffers'])+'\n'+(root/'src/import.inc').read_text()+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+sdk,'-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),str(root/'src/tp_history.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
