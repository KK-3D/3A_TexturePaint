"""Exercise native stamp asset loading and layout with mocked Windows image services."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include "tp_core.h"
#include <lwserver.h>
#include <lwhost.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#define MAX_PATH 260
typedef unsigned UINT;
typedef struct {GlobalFunc*global;int mode,stamp_show;double stamp_x,stamp_y,stamp_scale,stamp_rotation;} Tool;
typedef struct {unsigned char*rgba,*display_rgba;int width,height;char path[1024],info[128];} StampAsset;
static StampAsset stamp_asset;
static UINT width=4,height=2;static int probe=1,decode=1,request_result=1;static char message[512];
static int to_wide(const char*p,wchar_t*out){return mbstowcs(out,p,MAX_PATH)<MAX_PATH;}
static void status(Tool*t,const char*s){(void)t;snprintf(message,sizeof(message),"%s",s);}
static int image_dimensions(const wchar_t*p,UINT*w,UINT*h){(void)p;*w=width;*h=height;return probe;}
static int decode_image_rect(const wchar_t*p,int w,int h,unsigned char*out){size_t i;(void)p;if(!decode)return 0;for(i=0;i<(size_t)w*h;i++){out[i*4]=200;out[i*4+1]=80;out[i*4+2]=20;out[i*4+3]=128;}return 1;}
static int request(int version,LWFileReqLocal*r){assert(version==LWFILEREQ_VERSION&&r->reqType==FREQ_LOAD);strcpy(r->fullName,"C:\\stamp.png");r->result=request_result;return AFUNC_OK;}
static void* global(const char*name,int mode){(void)mode;assert(!strcmp(name,LWFILEACTIVATEFUNC_GLOBAL));return (void*)request;}
'''
tail=r'''
int main(void){Tool t={0};TPStencil layout;unsigned char*old;t.global=global;choose_stamp_image(&t);assert(stamp_asset.width==4&&stamp_asset.height==2&&t.mode==TP_MODE_INK&&t.stamp_show);assert(stamp_asset.rgba[0]==200&&stamp_asset.rgba[3]==128&&stamp_asset.display_rgba[0]==100&&stamp_asset.display_rgba[1]==40);assert(t.stamp_x==.5&&t.stamp_y==.5&&t.stamp_scale==1);assert(stencil_layout(&t,400,200,&layout)&&layout.display_width==200&&layout.display_height==100);old=stamp_asset.rgba;
 decode=0;load_stamp_image(&t,"C:\\bad.png");assert(stamp_asset.rgba==old);decode=1;probe=0;load_stamp_image(&t,"C:\\bad.png");assert(stamp_asset.rgba==old);probe=1;request_result=0;choose_stamp_image(&t);assert(stamp_asset.rgba==old);request_result=-1;choose_stamp_image(&t);assert(stamp_asset.rgba==old);
 width=4096;height=1024;load_stamp_image(&t,"C:\\large.png");assert(stamp_asset.width==2048&&stamp_asset.height==512&&strstr(stamp_asset.info,"resized"));free(stamp_asset.rgba);free(stamp_asset.display_rgba);puts("PASS: native stamp import, premultiplied preview, aspect-preserving size cap, default placement, Ink activation and old-stamp preservation on cancel/decode failure.");return 0;}
'''

root=Path(__file__).resolve().parents[1]
sdk=os.environ.get('LWSDK_INCLUDE','/tmp/lwsdk/include')
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'loader.c';out=Path(d)/'loader'
    c.write_text(head+(root/'src/stamp.inc').read_text()+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+sdk,'-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
