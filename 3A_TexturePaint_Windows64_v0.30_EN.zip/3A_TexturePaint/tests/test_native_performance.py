"""Exercise production Undo, preview composition and save timing with a mocked host."""
from pathlib import Path
import re, subprocess, tempfile, os
src=(Path(__file__).resolve().parents[1]/'src/native.c').read_text()
def function(name):
    match=re.search(r'^static [^\n;]*?\b'+name+r'\([^\n]*?\)\{',src,re.M);assert match,name
    start=match.start();i=match.end();depth=1;quote=None;escape=False
    while depth:
        c=src[i];i+=1
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
    return src[start:i]
head=r'''
#include "tp_core.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned long long ULONGLONG;
typedef struct {TPDoc doc,undo;unsigned undo_dirty;int history_pending,canundo,canredo,modified,image_modified,preview_size;unsigned char*composite,*preview_rgb;ULONGLONG last_save;} Session;
typedef struct {Session*s;int fast_preview,save_timing,dirty;} Tool;
static int auto_save_image=1;static ULONGLONG now;static int saves;
static ULONGLONG GetTickCount64(void){return now;}
static void status(Tool*t,const char*s){(void)t;(void)s;}
static int commit_history(Tool*t){t->s->history_pending=0;return 1;}
static int autosave(Tool*t){saves++;t->s->modified=0;t->s->last_save=now;return 1;}
'''
tail=r'''
static void compare(Tool*t){size_t n=(size_t)t->s->doc.size*t->s->doc.size;unsigned char*full=malloc(n*4);int x,y,k,size=t->s->doc.size,p=t->s->preview_size;assert(full);tp_composite(&t->s->doc,full);assert(!memcmp(full,t->s->composite,n*4));for(y=0;y<p;y++)for(x=0;x<p;x++){int sx=(int)(((double)x+.5)*size/p),sy=(int)(((double)y+.5)*size/p);size_t i=((size_t)sy*size+sx)*4,j=((size_t)y*p+x)*3;double a=full[i+3]/255.0;for(k=0;k<3;k++)assert(t->s->preview_rgb[j+k]==(unsigned char)(full[i+k]*a+255*(1-a)+.5));}free(full);}
int main(void){Session s={0};Tool t={&s,1,0,0};TPRect r={0};size_t n,i;int l;assert(tp_doc_init(&s.doc,2048,1,"UV"));n=(size_t)s.doc.size*s.doc.size;s.composite=malloc(n*4);s.preview_rgb=malloc(n*3);assert(s.composite&&s.preview_rgb);
 assert(checkpoint(&t));assert(!s.undo_dirty);s.doc.layer[2].rgba[3]=200;s.undo_dirty|=1u<<2;s.doc.active=2;assert(checkpoint(&t));assert(s.undo.layer[2].rgba[3]==200&&s.undo.active==2);s.doc.layer[2].rgba[3]=50;s.undo_dirty|=1u<<2;s.doc.layer[5].rgba[7]=70;s.undo_dirty|=1u<<5;assert(checkpoint(&t));for(l=0;l<8;l++)assert(!memcmp(s.doc.layer[l].rgba,s.undo.layer[l].rgba,n*4));
 s.doc.layer[1].opacity=.3;strcpy(s.doc.layer[1].name,"Renamed");s.undo_dirty=255;assert(checkpoint(&t));assert(s.undo.layer[1].opacity==.3&&!strcmp(s.undo.layer[1].name,"Renamed"));
 composite_region(&t,NULL);assert(s.preview_size==1024);compare(&t);
 for(i=100;i<110;i++){size_t at=(i*2048+i)*4;s.doc.layer[2].rgba[at]=220;s.doc.layer[2].rgba[at+3]=125;tp_rect_add(&r,(int)i,(int)i);}composite_region(&t,&r);compare(&t);
 t.fast_preview=0;composite_region(&t,NULL);assert(s.preview_size==2048);compare(&t);t.fast_preview=1;composite_region(&t,NULL);assert(s.preview_size==1024);compare(&t);
 now=100;s.modified=1;finish_stroke(&t);assert(saves==1&&!s.modified);t.save_timing=1;now=5000;s.modified=1;finish_stroke(&t);assert(saves==1&&s.modified);now=30100;finish_stroke(&t);assert(saves==2&&!s.modified);t.save_timing=0;now=30101;s.modified=1;finish_stroke(&t);assert(saves==3);
 free(s.composite);free(s.preview_rgb);tp_doc_free(&s.doc);tp_doc_free(&s.undo);puts("PASS: selective Undo snapshots, incremental/full preview equivalence, preview-size switching and save timing.");return 0;}
'''
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
    c=Path(d)/'perf.c';out=Path(d)/'perf';c.write_text(head+'\n'.join(function(n) for n in ['checkpoint','composite_region','finish_stroke'])+tail)
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(root/'src'),str(c),str(root/'src/tp_core.c'),'-lm','-o',str(out)],check=True)
    subprocess.run([str(out)],check=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
