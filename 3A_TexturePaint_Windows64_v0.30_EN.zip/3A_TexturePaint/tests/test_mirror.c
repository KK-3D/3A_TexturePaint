#include "../src/tp_core.h"
#include "../src/tp_history.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static unsigned count_tile(const TPDoc*d,int tile){unsigned count=0;int x,y;for(y=(1-tile/4)*256;y<(2-tile/4)*256;y++)for(x=(tile%4)*128;x<(tile%4+1)*128;x++)if(d->layer[0].rgba[((size_t)y*512+x)*4+3])count++;return count;}
int main(void){TPMesh mesh={0};TPMirror mirror={0};TPDoc doc={0},before={0};TPView view={0};TPRect dirty={0};TPBrush brush={10,1,0,.5,{255,40,10}};float*coverage=calloc(512*512,sizeof(float));
 const double points[3][3]={{1,1,1},{2,1,1},{1,2,1.5}};
 mesh.count=mesh.capacity=8;mesh.tri=calloc(8,sizeof(TPTriangle));
 for(int a=0;a<8;a++)for(int j=0;j<3;j++){TPVertex*v=&mesh.tri[a].v[j];for(int k=0;k<3;k++)v->p[k]=(a&(1<<k))?-points[j][k]:points[j][k];v->uv[0]=(a%4+.1+(j==1?.8:0))/4;v->uv[1]=(a/4+.1+(j==2?.8:0))/2;}
 /* Reversed vertex order is still a geometric match. */
 {TPVertex swap=mesh.tri[3].v[0];mesh.tri[3].v[0]=mesh.tri[3].v[2];mesh.tri[3].v[2]=swap;}
 assert(tp_mesh_finish(&mesh));assert(tp_doc_init(&doc,512,mesh.hash,"UV"));assert(tp_doc_clone(&before,&doc));assert(tp_view_resize(&view,100,100));view.project_count=8;view.projected=calloc(24,sizeof(TPProjected));
 for(int a=0;a<8;a++)for(int j=0;j<3;j++){TPProjected*q=&view.projected[a*3+j];q->x=(a?2000:10)+(j==1?80:0);q->y=10+(j==2?80:0);q->w=q->z=1;}
 assert(tp_render_projected(&view,&mesh,&doc,NULL));
 for(unsigned axes=0;axes<8;axes++){
  memset(doc.layer[0].rgba,0,512*512*4);memset(coverage,0,512*512*sizeof(float));memset(&dirty,0,sizeof(dirty));
  assert(tp_mirror_prepare(&mirror,&mesh,axes));
  for(unsigned a=1;a<8;a++)assert((mirror.faces[a]!=NULL)==((a&axes)==a));
  assert(tp_stamp_mirror(&mesh,&view,&doc,&before,coverage,&brush,25,25,&dirty,NULL,NULL,&mirror));
  for(unsigned a=0;a<8;a++)assert((count_tile(&doc,(int)a)>0)==((a&axes)==a));
  for(size_t i=0;i<512*512;i++)assert(doc.layer[0].rgba[i*4+3]<=128);
  assert(!tp_stamp_mirror(&mesh,&view,&doc,&before,coverage,&brush,25,25,&dirty,NULL,NULL,&mirror));
 }
 /* Original and all reflected islands commit and undo together. */
 {TPHistory history={0};assert(tp_history_commit(&history,&before,&doc,1,32));assert(tp_history_step(&history,&doc,0));for(int i=0;i<8;i++)assert(!count_tile(&doc,i));assert(tp_history_step(&history,&doc,1));for(int i=0;i<8;i++)assert(count_tile(&doc,i)>0);tp_history_free(&history);}
 /* Cache reuse, then invalidate on mesh change; no nearest unrelated face. */
 {TPMirrorFace*cached=mirror.faces[1];assert(tp_mirror_prepare(&mirror,&mesh,7)&&mirror.faces[1]==cached);}
 mesh.tri[7].v[0].p[0]-=.1;assert(tp_mesh_finish(&mesh));assert(tp_mirror_prepare(&mirror,&mesh,7));assert(mirror.faces[7][7].source==UINT32_MAX);
 assert(tp_mirror_prepare(&mirror,&mesh,0));for(int a=1;a<8;a++)assert(!mirror.faces[a]);
 tp_mirror_free(&mirror);tp_view_free(&view);tp_doc_free(&doc);tp_doc_free(&before);free(mesh.tri);free(coverage);
 puts("PASS: X/Y/Z and all combinations, separate UV islands, hidden mirrored faces, strength cap, no repeated accumulation, cache invalidation and unmatched geometry.");
}
