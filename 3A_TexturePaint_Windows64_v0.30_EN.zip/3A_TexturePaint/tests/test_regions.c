#include "../src/tp_core.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(void){int size;
 for(size=2048;size<=8192;size*=2){TPDoc d={0},before={0};TPView view={0};TPMesh mesh={0};TPBrush brush={14,0,0,.7,{20,180,90}};TPRect rect={0};size_t n=(size_t)size*size,i;unsigned char*a,*b;float*mask;clock_t start;double full,partial;int pass;
 assert(tp_doc_init(&d,size,1,"UV"));a=malloc(n*4);b=malloc(n*4);mask=calloc(n,sizeof(float));assert(a&&b&&mask);assert(tp_view_resize(&view,1024,1024));view.uv_mode=1;
 for(i=0;i<n;i+=7919){d.layer[0].rgba[i*4]=150;d.layer[0].rgba[i*4+3]=90;d.layer[3].rgba[i*4+2]=240;d.layer[3].rgba[i*4+3]=125;}d.layer[3].opacity=.42;
 assert(tp_doc_clone(&before,&d));tp_composite(&d,a);
 for(pass=0;pass<4;pass++){double x=pass==2?52:pass==3?972:512+pass*13;brush.erase=pass==1;memset(&rect,0,sizeof(rect));
 assert(tp_stamp_region(&mesh,&view,&d,&before,mask,&brush,x,512,&rect));assert(rect.valid&&rect.x0>=0&&rect.y0>=0&&rect.x1<size&&rect.y1<size);
 tp_composite_region(&d,a,&rect);tp_composite(&d,b);assert(!memcmp(a,b,n*4));
 }
 rect=(TPRect){size/2,size/2,size/2+127,size/2+127,1};start=clock();tp_composite(&d,b);full=(double)(clock()-start)/CLOCKS_PER_SEC;
 start=clock();for(pass=0;pass<100;pass++)tp_composite_region(&d,a,&rect);partial=(double)(clock()-start)/CLOCKS_PER_SEC/100;
 assert(!memcmp(a,b,n*4));printf("%d: full composition %.3f ms; 128x128 region %.3f ms; %.1fx component speedup\n",size,1000*full,1000*partial,full/partial);fflush(stdout);
 free(a);free(b);free(mask);tp_doc_free(&d);tp_doc_free(&before);tp_view_free(&view);
 }
 puts("PASS: incremental composition is byte-identical to full composition at 2K/4K/8K (paint, eraser, edges, layers).");return 0;
}
