#include <lwimage.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#define TP_MODE_INK 3
typedef struct {LWImageList*images;int image_count,project_image;char**image_names,**image_paths;LWImageID*image_ids;int mode,stamp_show;double stamp_x,stamp_y,stamp_scale,stamp_rotation;} Tool;
static struct{unsigned char*rgba,*display_rgba;int width,height;char path[1024],info[128];}stamp_asset;
static int count=3,reads,refreshes,bad_size;
static LWImageID first(void){return count?(void*)1:NULL;}
static LWImageID next(LWImageID id){return (size_t)id<(size_t)count?(void*)((size_t)id+1):NULL;}
static const char*filename(LWImageID id,int frame){(void)frame;return id==(void*)1?"a.exr":id==(void*)2?"b.tga":NULL;}
static const char*name(LWImageID id){return id==(void*)1?"Image A":id==(void*)2?"Image B":"Generated Image";}
static int is_live(Tool*t){return t!=NULL;}
static void request_ui(Tool*t){(void)t;refreshes++;}
static void status(Tool*t,const char*s){(void)t;(void)s;}
static double bound(double x){return !isfinite(x)?0:x<0?0:x>1?1:x;}
static void size(LWImageID id,int*w,int*h){(void)id;*w=bad_size?0:4;*h=2;}
static void rgb(LWImageID id,int x,int y,float*out){assert(id&&x>=0&&x<4&&y>=0&&y<2);out[0]=1;out[1]=.5;out[2]=0;reads++;}
static int has_alpha(LWImageID id){return id==(void*)3;}
static float alpha(LWImageID id,int x,int y){(void)id;(void)x;(void)y;return .5f;}
#include "../src/project_images.inc"
int main(void){LWImageList images={0};Tool t={0};int prior;images.first=first;images.next=next;images.filename=filename;images.name=name;images.size=size;images.RGB=rgb;images.hasAlpha=has_alpha;images.alpha=alpha;t.images=&images;
 refresh_project_images(&t);assert(project_image_count(&t)==4&&!strcmp(project_image_name(&t,3),"Generated Image"));prior=refreshes;
 refresh_project_images(&t);assert(refreshes==prior);
 t.project_image=3;use_project_image(&t);assert(reads==8&&stamp_asset.rgba[3]==128&&stamp_asset.display_rgba[0]==128&&t.mode==3);
 t.project_image=1;use_project_image(&t);assert(reads==16&&stamp_asset.rgba[3]==255); /* host reads EXR, no WIC restriction */
 bad_size=1;use_project_image(&t);assert(reads==16&&stamp_asset.rgba[3]==255);bad_size=0;
 t.project_image=3;count=2;use_project_image(&t);assert(reads==16&&t.image_count==2&&t.project_image==0);
 t.project_image=2;refresh_project_images(&t);assert(t.project_image==2);
 count=0;refresh_project_images(&t);assert(project_image_count(&t)==1);free_project_images(&t);free(stamp_asset.rgba);free(stamp_asset.display_rgba);
 puts("PASS: all Image Editor entries including generated images, host pixels/alpha, EXR/TGA, deletion safety, stable selection and empty list.");return 0;}
