/* Exercise the production dispatcher without a Modeler test()/idle callback. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
typedef void* HWND;typedef void* HMODULE;typedef const wchar_t* LPCWSTR;
typedef unsigned UINT;typedef unsigned short ATOM;typedef uintptr_t WPARAM;typedef intptr_t LPARAM;typedef intptr_t LRESULT;
#define CALLBACK
#define WM_APP 0x8000
#define HWND_MESSAGE ((HWND)(intptr_t)-3)
#define GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS 1
#define GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT 2
enum {ID_ALPHA_SELECT=1,ID_ALPHA_SCROLL,ID_ALPHA_SIZE,ID_ALPHA_REFRESH,ID_ALPHA_REMOVE};
typedef struct Tool {struct Tool*next;void*panel;int busy,ui_depth,ui_refreshing,painting,pending,adjusting,queued_action;} Tool;
typedef struct {HMODULE hInstance;LRESULT(*lpfnWndProc)(HWND,UINT,WPARAM,LPARAM);const wchar_t*lpszClassName;} WNDCLASSW;
static Tool*live_tools;static int posts,runs,refreshes,registered,destroyed,fail_create,last_action;
static int PostMessageW(HWND w,UINT m,WPARAM p,LPARAM l){assert(w&&m==WM_APP+0x3A&&!p&&!l);posts++;return 1;}
static LRESULT DefWindowProcW(HWND w,UINT m,WPARAM p,LPARAM l){(void)w;(void)m;(void)p;(void)l;return 17;}
static int GetModuleHandleExW(int flags,LPCWSTR p,HMODULE*out){assert(flags==3&&p);*out=(void*)2;return 1;}
static ATOM RegisterClassW(const WNDCLASSW*c){assert(c->hInstance==(void*)2&&c->lpfnWndProc&&c->lpszClassName);registered++;return 1;}
static int UnregisterClassW(const wchar_t*n,HMODULE m){assert(n&&m==(void*)2);registered--;return 1;}
static HWND CreateWindowExW(int ex,const wchar_t*c,const wchar_t*n,int style,int x,int y,int w,int h,HWND parent,void*menu,HMODULE m,void*data){assert(!ex&&c&&n&&!style&&!x&&!y&&!w&&!h&&parent==HWND_MESSAGE&&!menu&&m==(void*)2&&!data);return fail_create?NULL:(void*)3;}
static int DestroyWindow(HWND w){assert(w==(void*)3);destroyed++;return 1;}
static int is_live(Tool*t){Tool*p;for(p=live_tools;p;p=p->next)if(p==t)return 1;return 0;}
static void run_action(Tool*t,int id){assert(t->busy&&!t->queued_action);runs++;last_action=id;}
static void flush_ui(Tool*t){assert(!t->busy);refreshes++;}
#include "../src/alpha_dispatch.inc"
int main(void){Tool t={0};t.panel=(void*)1;live_tools=&t;
 alpha_dispatch_start();alpha_dispatch_start();assert(registered==1);
 t.queued_action=ID_ALPHA_SCROLL;alpha_dispatch_wake(&t);alpha_dispatch_wake(&t);assert(posts==1);
 /* A click supersedes the pending scroll; one posted event uses latest action. */
 t.queued_action=ID_ALPHA_SELECT;alpha_dispatch_wake(&t);
 alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==1&&refreshes==1&&last_action==ID_ALPHA_SELECT&&!t.queued_action&&!alpha_dispatch_posted);
 alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==1);
 for(int i=ID_ALPHA_SELECT;i<=ID_ALPHA_REMOVE;i++){t.queued_action=i;alpha_dispatch_wake(&t);alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(last_action==i&&!t.queued_action);}
 {int before=runs;int*guards[]={&t.busy,&t.ui_depth,&t.ui_refreshing,&t.painting,&t.pending,&t.adjusting};
 for(unsigned i=0;i<sizeof(guards)/sizeof(*guards);i++){t.queued_action=ID_ALPHA_SCROLL;*guards[i]=1;alpha_dispatch_wake(&t);alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==before&&t.queued_action==ID_ALPHA_SCROLL);*guards[i]=0;}
 t.panel=NULL;alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==before);t.panel=(void*)1;
 t.queued_action=99;alpha_dispatch_wake(&t);alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==before&&t.queued_action==99);
 live_tools=NULL;alpha_dispatch_proc(alpha_dispatch_window,TP_ALPHA_MESSAGE,0,0);assert(runs==before);}
 assert(alpha_dispatch_proc(alpha_dispatch_window,0,0,0)==17);
 alpha_dispatch_stop();alpha_dispatch_stop();assert(!registered&&destroyed==1&&!alpha_dispatch_window);
 fail_create=1;alpha_dispatch_start();assert(!registered&&!alpha_dispatch_window);alpha_dispatch_stop();
 puts("PASS: gallery actions execute without tool test(), coalesce, respect callback/gesture guards, ignore stale instances and clean up dispatcher.");
}
