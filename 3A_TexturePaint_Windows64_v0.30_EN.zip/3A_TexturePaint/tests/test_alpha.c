#include "../src/tp_core.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
int main(void){unsigned char mask_image[4]={255,0,255,0},grey[1]={128};TPAlpha alpha={mask_image,2,2,0};TPDoc d={0},before={0};TPView v={0};TPMesh m={0};TPBrush b={30,1,0,1,{255,0,0}};TPRect r={0};float*coverage;int x,y;size_t n;
 assert(tp_alpha_sample(&alpha,-.5,0)==1&&tp_alpha_sample(&alpha,.5,0)==0);alpha.invert=1;assert(tp_alpha_sample(&alpha,-.5,0)==0&&tp_alpha_sample(&alpha,.5,0)==1);alpha.invert=0;
 assert(tp_doc_init(&d,512,1,"UV"));assert(tp_doc_clone(&before,&d));n=(size_t)512*512;coverage=calloc(n,sizeof(float));assert(coverage);v.w=v.h=200;v.uv_mode=1;
 assert(tp_stamp_masked(&m,&v,&d,&before,coverage,&b,100,100,&r,NULL,&alpha));
 for(y=0;y<512;y++)for(x=0;x<512;x++){double sx=10+(x+.5)/512*180,sy=10+(y+.5)/512*180;unsigned char*q=d.layer[0].rgba+((size_t)y*512+x)*4;
 if(hypot(sx-100,sy-100)>=30)assert(q[3]==0);else{int a=(int)(255*tp_alpha_sample(&alpha,(sx-100)/30,(sy-100)/30)+.5);assert(abs(q[3]-a)<=1);if(q[3])assert(q[0]==255&&q[1]==0&&q[2]==0);}}
 /* Grey attenuates strength; disabling alpha restores normal brush. */
 memset(coverage,0,n*sizeof(float));memset(d.layer[0].rgba,0,n*4);alpha.gray=grey;alpha.width=alpha.height=1;b.strength=.5;
 assert(tp_stamp_masked(&m,&v,&d,&before,coverage,&b,100,100,&r,NULL,&alpha));assert(d.layer[0].rgba[((size_t)256*512+256)*4+3]==64);
 memset(coverage,0,n*sizeof(float));assert(tp_stamp_masked(&m,&v,&d,&before,coverage,&b,100,100,&r,NULL,NULL));assert(d.layer[0].rgba[((size_t)256*512+256)*4+3]==128);
 /* Eraser also obeys alpha. */
 tp_doc_free(&before);assert(tp_doc_clone(&before,&d));memset(coverage,0,n*sizeof(float));b.erase=1;b.strength=1;alpha.gray=mask_image;alpha.width=alpha.height=2;
 assert(tp_stamp_masked(&m,&v,&d,&before,coverage,&b,100,100,&r,NULL,&alpha));assert(d.layer[0].rgba[((size_t)256*512+213)*4+3]<2);assert(d.layer[0].rgba[((size_t)256*512+299)*4+3]>125);
 {double start[2]={100,100},end[2]={180,170},out[2];tp_line_endpoint(start,end,1,out);assert(fabs(out[0]-175)<1e-9&&fabs(out[1]-175)<1e-9);end[0]=30;end[1]=105;tp_line_endpoint(start,end,1,out);assert(fabs(out[0]-30)<1e-9&&fabs(out[1]-100)<1e-9);}
 free(coverage);tp_doc_free(&d);tp_doc_free(&before);puts("PASS: black/white/grey masks, invert, alpha removal, strength multiplication, eraser, bounds and snapped line geometry.");return 0;
}
